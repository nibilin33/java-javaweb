package com.etc.data;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.Move;
import com.etc.entity.Rule;
import com.etc.gui.LoginFrame;

public class ServerEatChess extends BasicMsg{
	private ChessBoard board;
	private ChessMan man;
    private String num;
    private Rule rule;
    private Move move;
	public ServerEatChess(ChessBoard board, ChessMan man,String num,Rule rule,Move move) {
		super();
		this.board = board;
		this.man = man;
		this.num=num;
		this.rule=rule;
		this.move=move;
	}

	public ChessBoard getBoard() {
		return board;
	}

	public void setBoard(ChessBoard board) {
		this.board = board;
	}

	public ChessMan getMan() {
		return man;
	}

	public void setMan(ChessMan man) {
		this.man = man;
	}
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
	
		LoginFrame.getClient().getCheessmap().tomove(rule,move,board,man);
		
	}

}
