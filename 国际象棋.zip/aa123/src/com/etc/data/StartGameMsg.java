package com.etc.data;

import java.net.Socket;

import com.etc.gui.LoginFrame;
import com.etc.gui.ServerRoom;

public class StartGameMsg extends BasicMsg{
   private int roomid;
   private Socket client;

	public StartGameMsg(int roomid, Socket client) {
	super();
	this.roomid = roomid;
	this.client = client;
}

	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		if(ServerRoom.getMyservice().getRoom().get(roomid).getGamestate()>1){
			System.out.println("kaijulalalalalal");
			ServerStartGameMsg game=new ServerStartGameMsg();
			ServerRoom.getMyservice().sendRoomMsg(game, roomid);
		 // LoginFrame.getClient().getIchessroom().timeshow();
		}
		
	}

	public int getRoomid() {
		return roomid;
	}

	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

	public Socket getClient() {
		return client;
	}

	public void setClient(Socket client) {
		this.client = client;
	}

}
