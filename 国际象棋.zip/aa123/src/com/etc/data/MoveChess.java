package com.etc.data;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.Move;
import com.etc.entity.Room;
import com.etc.entity.Rule;
import com.etc.gui.ServerRoom;

public class MoveChess extends BasicMsg{
	
	public MoveChess(String target, int roomid,ChessBoard chessboard,ChessMan chessman) {
		super();
	
		this.roomid = roomid;
		this.target=target;
		this.chessboard=chessboard;
		this.chessman=chessman;
	}

	public int getRoomid() {
		return roomid;
	}
	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}
	private int roomid;
	private String target;
	private ChessBoard chessboard;
	private ChessMan chessman;
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		ServerRoom.getMyservice().movechess(target,roomid,chessboard,chessman);
		Room rm=ServerRoom.getMyservice().getRoom().get(roomid);
		ChessBoard ch=rm.getChessboard();
		ChessMan cm=rm.getChessman();
		Move mv=rm.getMove();
		Rule rl=mv.getRule();
		ServerEatChess sec=new ServerEatChess(ch,cm,target,rl,mv);
     	ServerRoom.getMyservice().sendRoomMsg(sec, roomid);
		
	}

}
