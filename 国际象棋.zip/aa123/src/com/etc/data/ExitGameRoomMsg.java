package com.etc.data;

import java.net.Socket;

import com.etc.gui.ServerRoom;
import com.etc.util.JDBC;

public class ExitGameRoomMsg extends BasicMsg{
	private Socket socket;
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		ServerRoom.getMyservice().removeThread(socket);
	}
	public ExitGameRoomMsg(Socket socket) {
		super();
		this.socket = socket;
	}
	public Socket getSocket() {
		return socket;
	}
	public void setSocket(Socket socket) {
		this.socket = socket;
	}
	
     
}
