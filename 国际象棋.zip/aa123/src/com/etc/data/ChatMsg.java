package com.etc.data;

import com.etc.gui.RoomTryTwo;
import com.etc.gui.ServerRoom;

public class ChatMsg extends BasicMsg{
	private String text;
    private int roomid;


	public ChatMsg(String text, int roomid) {
		super();
		this.text = text;
		this.roomid = roomid;
	}


	public String getText() {
		return text;
	}


	public void setText(String text) {
		this.text = text;
	}


	public int getRoomid() {
		return roomid;
	}


	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}


	@Override//�ͻ��˸�������������Ϣ����������ͻ�����Ӧ����
	public void doBiz() {
		// TODO Auto-generated method stub
		ServerRchat sr=new ServerRchat(text);
		ServerRoom.getMyservice().sendRoomMsg(sr,roomid);
		
	}
	
}
