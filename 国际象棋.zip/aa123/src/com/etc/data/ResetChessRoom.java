package com.etc.data;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.gui.ServerRoom;

public class ResetChessRoom extends BasicMsg{
private int roomid;
private ChessBoard board;
private ChessMan man;
@Override
public void doBiz() {
	// TODO Auto-generated method stub
	  ServerRoom.getMyservice().getRoom().get(roomid).setChessboard(board);
	  ServerRoom.getMyservice().getRoom().get(roomid).setChessman(man);
	    
}
public ResetChessRoom(int roomid, ChessBoard board, ChessMan man) {
	super();
	this.roomid = roomid;
	this.board = board;
	this.man = man;
}

}
