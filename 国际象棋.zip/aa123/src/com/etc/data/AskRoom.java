package com.etc.data;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import com.etc.entity.Room;
import com.etc.gui.ServerRoom;
import com.etc.util.Log;

public class AskRoom extends BasicMsg{
  private int roomid;
  private boolean iswatch;
  private Socket socket;
public AskRoom(int roomid, boolean iswatch, Socket socket) {
	super();
	this.roomid = roomid;
	this.iswatch = iswatch;
	this.socket = socket;
}

public boolean isIswatch() {
	return iswatch;
}

public void setIswatch(boolean iswatch) {
	this.iswatch = iswatch;
}

public Socket getSocket() {
	return socket;
}

public void setSocket(Socket socket) {
	this.socket = socket;
}

@Override
public void doBiz() {//���󷿼俪����������
	// TODO Auto-generated method stub
//	ObjectInputStream ot;
		
		//ot = new ObjectInputStream(ac.getInputStream());
	//	ServerRoom.getMyservice().sendwatch(roomid);
	
}

public int getRoomid() {
	return roomid;
}

public AskRoom(int roomid) {
	super();
	this.roomid = roomid;
}

public void setRoomid(int roomid) {
	this.roomid = roomid;
}
  
}
