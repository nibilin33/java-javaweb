package com.etc.data;

import java.awt.List;
import java.util.ArrayList;

import com.etc.entity.Room;
import com.etc.gui.LoginFrame;

public class ServerRexitRoom extends BasicMsg{
  private ArrayList<Room>room;
	public ServerRexitRoom(ArrayList<Room> room) {
	super();
	this.room = room;
}
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIgameroom().showRoomList(room);
	}

}
