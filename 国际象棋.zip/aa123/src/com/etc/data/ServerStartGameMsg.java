package com.etc.data;

import com.etc.gui.LoginFrame;

public class ServerStartGameMsg extends BasicMsg{
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIchessroom().timeshow();
	}

}
