package com.etc.data;

import com.etc.gui.LoginFrame;

public class ServerRClientMul extends BasicMsg{
	private String name;
	public ServerRClientMul(String name) {
		super();
		this.name = name;
	}
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIgameroom().showTalkList(name);
	}
	

}
