package com.etc.data;

import com.etc.gui.LoginFrame;
import com.etc.util.JDBC;

public class ServerRwin extends BasicMsg{
   private String color;
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIchessroom().winshow(color);
		JDBC jdbc=new JDBC();
		jdbc.getconnection();
	}
	public ServerRwin(String color) {
		super();
		this.color = color;
	}

}
