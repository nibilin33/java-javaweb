package com.etc.data;

import java.util.List;

import com.etc.gui.LoginFrame;

//����˷������û��б�֪ͨ����
public class ServerUserListMsg extends BasicMsg {
	private List<String> userList;
	
	public List<String> getUserList() {
		return userList;
	}
	public void setUserList(List<String> userList) {
		this.userList = userList;
	}
	public ServerUserListMsg(List<String> userList) {
		super();
		this.userList = userList;
	}

	@Override
	public void doBiz() {
		//����û��б�����ʾ
	LoginFrame.getClient().getIgameroom().showUserList(userList);
		
	}
}
