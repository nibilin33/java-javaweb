package com.etc.data;

import com.etc.gui.LoginFrame;
import com.etc.gui.ServerRoom;

public class BroadCastMsg extends BasicMsg{//�ͻ�Ⱥ��
  private String text;
public BroadCastMsg(String text) {
	super();
	this.text = text;
}

public String getText() {
	return text;
}

public void setText(String text) {
	this.text = text;
}

@Override//����ӵ���Ϣ�Ķ���
public void doBiz() {
	// TODO Auto-generated method stub
//	ServerRchat sr=new ServerRchat(text);//�ͻ��˽��յ��ķ�����Ϣ
//	ServerRoom.getMyservice().sendToClientMul(sr);
	//ServerRoom.getMyservice().sendToClientMul(msg)
      ServerRClientMul sr=new ServerRClientMul(text);
      ServerRoom.getMyservice().sendToClientMul(sr);
}
  
}
