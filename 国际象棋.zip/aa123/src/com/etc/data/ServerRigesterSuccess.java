package com.etc.data;

import com.etc.gui.LoginFrame;

public class ServerRigesterSuccess extends BasicMsg{
	private String username;

	public ServerRigesterSuccess(String username) {
		super();
		this.username = username;
	}

	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		
     	LoginFrame.getClient().getIregister().showSregister();
		
	}
	

}
