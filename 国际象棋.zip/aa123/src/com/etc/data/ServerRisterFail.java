package com.etc.data;

import com.etc.gui.LoginFrame;

public class ServerRisterFail extends BasicMsg{

	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIregister().showFregister();
		LoginFrame.getClient().closeConnect();
	}//�첽������

}
