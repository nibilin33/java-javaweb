package com.etc.data;

import com.etc.gui.LoginFrame;

public class ServerWinGame extends BasicMsg{
    private String color;
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public ServerWinGame(String color) {
		super();
		this.color = color;
	}
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIchessroom().winshow(color);
	}

}
