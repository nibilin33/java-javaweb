package com.etc.data;
import com.etc.gui.LoginFrame;



//��¼����ɹ��ı���  �����������ͻ���
public class ServerLoginSucMsg extends BasicMsg{
	
	private String username;
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	public ServerLoginSucMsg(String username) {
		super();
		this.username = username;
	}
	
	@Override
	public void doBiz() {
		LoginFrame.getClient().getInlogin().informSuc(username);
		//LoginFrame.getClient().closeConnect();
	}
}
