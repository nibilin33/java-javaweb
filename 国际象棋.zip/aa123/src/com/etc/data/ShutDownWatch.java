package com.etc.data;

import java.io.IOException;
import java.net.Socket;

import com.etc.gui.ServerRoom;

public class ShutDownWatch extends BasicMsg{
   private Socket shut;
	public ShutDownWatch(Socket shut) {
	super();
	this.shut = shut;
}
	@Override
	public void doBiz(){
		// TODO Auto-generated method stub
		ServerRoom.getMyservice().removeWatch(shut);
	}
	//private Socket socket;
}
