package com.etc.data;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.gui.LoginFrame;

public class ServerRask extends BasicMsg{//��������ͻ��˷��͹ۿ���ͬ�����
	public ServerRask(ChessBoard board, ChessMan man) {
		super();
		this.board = board;
		this.man = man;
	}
	public ChessBoard getBoard() {
		return board;
	}
	public void setBoard(ChessBoard board) {
		this.board = board;
	}
	public ChessMan getMan() {
		return man;
	}
	public void setMan(ChessMan man) {
		this.man = man;
	}
	private ChessBoard board;
	private ChessMan man;
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIwatch().repaiting(board, man);
	}

}
