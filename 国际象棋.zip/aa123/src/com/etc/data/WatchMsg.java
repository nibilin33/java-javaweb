package com.etc.data;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.Room;
import com.etc.gui.ServerRoom;
import com.net.Serverman;

public class WatchMsg extends BasicMsg{
	private int roomid;
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		Room room=ServerRoom.getMyservice().getRoom().get(roomid);
		ChessBoard board=room.getChessboard();
		ChessMan man=room.getChessman();
		ServerOpenWatch watch=new ServerOpenWatch(board, man,roomid);
		ServerRoom.getMyservice().sendMsg(watch, this.client);
	}
	public WatchMsg(int roomid) {
		super();
		this.roomid = roomid;
	}
	public int getRoomid() {
		return roomid;
	}
	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

}
