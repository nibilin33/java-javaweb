package com.etc.data;

import com.etc.gui.LoginFrame;

public class ServerRbroad extends BasicMsg{//�ͻ��˽��յ��������Ϣ
	private String text;
    
	public ServerRbroad(String text) {
		super();
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public void doBiz() {
		// TODO Auto-generated method stub��ù㲥��Ϣ����ʾ
		LoginFrame.getClient().getIgameroom().showBroadInfo(text);
		
	}

}
