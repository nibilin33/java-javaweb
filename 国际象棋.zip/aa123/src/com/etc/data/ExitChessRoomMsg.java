package com.etc.data;

import java.util.ArrayList;

import com.etc.entity.Room;
import com.etc.gui.ServerRoom;
import com.etc.util.JDBC;

public class ExitChessRoomMsg extends BasicMsg{//�ͻ���������������˳��������Ϣ
    private int roomid;
    private String username;

    public int getRoomid() {
	      return roomid;
              }

   public ExitChessRoomMsg(int roomid, String username) {
		super();
		this.roomid = roomid;
		this.username = username;
	}

public void setRoomid(int roomid) {
	this.roomid = roomid;
    }

@Override//���������տͻ�����Ϣ���ҵ���Ӧ�����޸ķ�����Ϣ
public void doBiz() {
	// TODO Auto-generated method stub
	Room room=ServerRoom.getMyservice().getRoom().get(roomid);
	if(username.equals(room.getLeft())){
		room.setLeft(null);
	}else if(username.equals(room.getRight())){
	    room.setRight(null);
	}
	JDBC jdbc=new JDBC();
	jdbc.getconnection();
	jdbc.outroom(username);
	int state=room.getGamestate();
	room.setGamestate(state--);

    ServerRoom.getMyservice().changeRoom(room);
	ServerRexitRoom rr=new ServerRexitRoom(ServerRoom.getMyservice().getRoom());
	ServerRoom.getMyservice().sendToClientMul(rr);
    
}
   
}
