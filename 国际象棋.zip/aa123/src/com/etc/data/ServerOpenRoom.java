package com.etc.data;

import com.etc.entity.Room;
import com.etc.gui.LoginFrame;

public class ServerOpenRoom extends BasicMsg{//���������ط�����Ϣ
    private Room room;
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	public ServerOpenRoom(Room room) {
		super();
		this.room = room;
	}
	@Override//�ͻ��˻�÷�����ʼ��
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIgameroom().showChessRoom(room);
	}

}
