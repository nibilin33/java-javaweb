package com.etc.data;

import com.etc.gui.LoginFrame;

public class ServerRchat extends BasicMsg{
   private String text;
  
	public String getText() {
	return text;
}

public void setText(String text) {
	this.text = text;
}

	public ServerRchat(String text) {
	super();
	this.text = text;
}

	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		LoginFrame.getClient().getIchessroom().talkshow(text);
	}
 
}
