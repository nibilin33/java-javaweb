package com.etc.data;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.Move;
import com.etc.entity.Room;
import com.etc.entity.Rule;
import com.etc.entity.User;
import com.etc.gui.ServerRoom;

public class EatChess extends BasicMsg{
	
	private int i ;
	private String[] oldChess;
	private String chessName ; 
	private String num;
	private int roomid;
	private ChessBoard chessboard;
	private ChessMan chessman;
	private User user;
		@Override
		public void doBiz() {
			// TODO Auto-generated method stub
		
			ServerRoom.getMyservice().eatchess(i, oldChess, chessName, num, roomid,chessboard,chessman,user);
			Room rm=ServerRoom.getMyservice().getRoom().get(roomid);
			ChessBoard ch=rm.getChessboard();
			ChessMan cm=rm.getChessman();
			Move mv=rm.getMove();
			Rule rl=mv.getRule();
			ServerEatChess sec=new ServerEatChess(ch,cm,num,rl,mv);
	     	ServerRoom.getMyservice().sendRoomMsg(sec, roomid);
//			ServerEatChess sec=new ServerEatChess(ch,cm,target,rl,mv);
//	     	ServerRoom.getMyservice().sendRoomMsg(se2, roomid);
			
		}

		public EatChess(int i, String[] oldChess, String chessName, String num,int roomid,ChessMan chessman,ChessBoard chessboard,User user) {
			super();
			this.i = i;
			this.oldChess = oldChess;
			this.chessName = chessName;
			this.num = num;
			this.roomid=roomid;
			this.chessboard=chessboard;
			this.chessman=chessman;
			this.user=user;

		}

		public ChessBoard getChessboard() {
			return chessboard;
		}

		public void setChessboard(ChessBoard chessboard) {
			this.chessboard = chessboard;
		}

		public ChessMan getChessman() {
			return chessman;
		}

		public void setChessman(ChessMan chessman) {
			this.chessman = chessman;
		}

		public int getRoomid() {
			return roomid;
		}

		public void setRoomid(int roomid) {
			this.roomid = roomid;
		}

		public int getI() {
			return i;
		}

		public void setI(int i) {
			this.i = i;
		}

		public String[] getOldChess() {
			return oldChess;
		}

		public void setOldChess(String[] oldChess) {
			this.oldChess = oldChess;
		}

		public String getChessName() {
			return chessName;
		}

		public void setChessName(String chessName) {
			this.chessName = chessName;
		}

		public String getNum() {
			return num;
		}

		public void setNum(String num) {
			this.num = num;
		}
	
}
