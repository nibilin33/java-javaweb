package com.etc.data;

import java.util.List;
import com.etc.entity.Room;
import com.etc.gui.LoginFrame;

//����˷����ķ����б�֪ͨ����
public class ServerRoomListMsg extends BasicMsg {
	private List<Room> roomList;

	public ServerRoomListMsg(List<Room> roomList) {
		super();
		this.roomList = roomList;
	}

	public List<Room> getRoomList() {
		return roomList;
	}

	public void setRoomList(List<Room> roomList) {
		this.roomList = roomList;
	}

	@Override
	public void doBiz() {
		// ��÷����б�����ʾ
     	LoginFrame.getClient().getIgameroom().showRoomList(roomList);

	}
}
