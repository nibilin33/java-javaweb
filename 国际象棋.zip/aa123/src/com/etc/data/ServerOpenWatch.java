package com.etc.data;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.gui.LoginFrame;

public class ServerOpenWatch extends BasicMsg{
	private ChessBoard board;
	private ChessMan man;
  private int roomid;
	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		//
		LoginFrame.getClient().getIgameroom().showWatchRoom(board,man,roomid);
		LoginFrame.getClient().getIwatch().watchrun(roomid);
	
	}

	public ServerOpenWatch(ChessBoard board, ChessMan man,int roomid) {
		super();
		this.board = board;
		this.man = man;
		this.roomid=roomid;
	}

	public int getRoomid() {
		return roomid;
	}

	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

	public ChessBoard getBoard() {
		return board;
	}

	public void setBoard(ChessBoard board) {
		this.board = board;
	}

	public ChessMan getMan() {
		return man;
	}

	public void setMan(ChessMan man) {
		this.man = man;
	}

}
