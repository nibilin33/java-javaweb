package com.etc.util;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.swing.ImageIcon;

import com.etc.gui.LoginFrame;

public class Image {
  public ImageIcon getImage1() {
		return image1;
	}
	public ImageIcon getImage2() {
		return image2;
	}
	public ImageIcon getImage3() {
		return image3;
	}
  public ImageIcon image1=new ImageIcon(this.getClass().getResource("/Img/Qe.png"));
  public ImageIcon image2=new ImageIcon(this.getClass().getResource("/Img/Qw.png"));
  public ImageIcon image3=new ImageIcon(this.getClass().getResource("/Img/Qp.png"));
  public ImageIcon getone(){
	  List list = new ArrayList();  
	  list.add(image1);
	  list.add(image2);
	  list.add(image3);
	  Collections.shuffle(list);
	  return (ImageIcon) list.get(0);
  }
}
