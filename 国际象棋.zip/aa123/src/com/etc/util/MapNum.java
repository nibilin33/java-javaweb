package com.etc.util;

import java.awt.Rectangle;
import java.io.Serializable;

public class MapNum extends Rectangle implements Serializable{
/**
 * ���ڼ�¼���̸��ӵı�ţ�����(num,x,y)
 * **/
	private String num ;
	private String chessName ;

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}
	public String getChessName() {
		return chessName;
	}

	public void setChessName(String chessName) {
		this.chessName = chessName;
	}

}
