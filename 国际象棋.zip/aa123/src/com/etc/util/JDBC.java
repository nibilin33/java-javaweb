package com.etc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.etc.entity.User;

public class JDBC {
	public static Connection conn = null;
	public static PreparedStatement ps = null;
	public static ResultSet rs = null;
	public static void getconnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost/123?useUnicode=true&characterEncoding=UTF-8", "root", "123456");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void close() throws SQLException{
		if(rs!=null)
			rs.close();
		if(ps!=null)
			ps.close();
		if(conn!=null)
			conn.close();
	}
	//�û�ע��ǰ����û����Ƿ���ڡ�����
	public User selectUser(String name){
		User usr = null;
		String sql = "select * from user where name = '"+name+"'";
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				usr = new User(rs.getString(1),rs.getString(2),rs.getInt(3));
				if(rs.getInt("login")==1){
					usr.setName("123456789012345678901");
				}else{
					String sql2 = "update user set login = '"+1+"' where name = '"+name+"'";
					ps = conn.prepareStatement(sql2);
					ps.executeUpdate();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return usr;
	}
	//��ȡ�����û�
	public List<User> userList(){
		List <User> list = new ArrayList<User>();
		String sql = "select * from user";
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				User usr = new User(rs.getString(1),rs.getString(2),rs.getInt(3));
				list.add(usr);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		try {
//			close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return list;
	}
	//ע�� 0ʧ�ܣ�������ɹ�,
	public int addUser(User usr){
		int flag = 0;                                                                     //����         ����             ���ڷ���
		String sql = "insert into user values('"+usr.getName()+"','"+usr.getPassword()+"','"+0+"','"+0+"','"+0+"')";
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			flag = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		try {
//			close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return flag;
	}
	//�޸ķ���---
	public void addScore(User usr){
		String sql = "update user set score = '"+usr.getScore()+"' where name = '"+usr.getName()+"'";
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		try {
//			close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	
	public List<User> getUserList(List<String> name){
		List<User> list = new ArrayList<User>();
		getconnection();
		for(int i=0;i<name.size();i++){
			String sql = "select * from user where name = " +name.get(i);
			try {
				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				if(rs.next()){
					User u = new User(rs.getString(1), rs.getString(2),rs.getInt(3));
					list.add(u);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list ;
	}
	
	
	//�˳�����
	public void logout(String name){
		String sql = "update user set login = '"+0+"' where name = '"+name+"'";
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//�Ƿ��ڷ���   0 ����   1��
	public int  isinroom(String name){
		int flag = 0;
		String sql = "select * from user where name = '"+name+"'";
	//	System.out.println(888888);
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if(rs.next()){
				flag = rs.getInt("inroom");
			}
		//	System.out.println(flag);
			if(flag==0){
				String sql2 = "update user set inroom = '"+1+"' where name = '"+name+"'";
				ps = conn.prepareStatement(sql2);
				ps.executeUpdate();
		
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		try {
//		close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return flag;
	}
	//�˳�����
	public void outroom(String name){
		String sql = "update user set inroom = '"+0+"' where name = '"+name+"'";
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		try {
//			//close();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	//��ȡ��������
	public int getNumber(int roomId){
		int number = 0 ; 
		String sql = "select * from roomInfo";
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) == roomId)
					number = rs.getInt(2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return number;
	}
	//���ӿ�������
	public void addNumber(int roomId){
		String sql = "update roominfo set number = number+1 where roomid = "+roomId;
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//��տ�������
	public void clearNumber(int roomId){
		String sql = "update roominfo set number = 0 where roomid = "+roomId;
		getconnection();
		try {
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
