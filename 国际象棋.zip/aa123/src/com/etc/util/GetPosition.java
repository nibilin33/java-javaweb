package com.etc.util;

import com.etc.entity.ChessBoard;


public class GetPosition {
	
	public static String getPosition(int x , int y){//����->����
		String pos = null;
		if(x/75==0){
			switch(y/75){
			case 0 :pos = "a1";break;
			case 1 :pos = "b1";break;
			case 2 :pos = "c1";break;
			case 3 :pos = "d1";break;
			case 4 :pos = "e1";break;
			case 5 :pos = "f1";break;
			case 6 :pos = "g1";break;
			case 7 :pos = "h1";break;
			}
		} else
		if(x/75==1){
			switch(y/75){
			case 0 :pos = "a2";break;
			case 1 :pos = "b2";break;
			case 2 :pos = "c2";break;
			case 3 :pos = "d2";break;
			case 4 :pos = "e2";break;
			case 5 :pos = "f2";break;
			case 6 :pos = "g2";break;
			case 7 :pos = "h2";break;
			}
		} else
		if(x/75==2){
			System.out.println("����");
			switch(y/75){
			case 0 :pos = "a3";break;
			case 1 :pos = "b3";break;
			case 2 :pos = "c3";break;
			case 3 :pos = "d3";break;
			case 4 :pos = "e3";break;
			case 5 :pos = "f3";break;
			case 6 :pos = "g3";break;
			case 7 :pos = "h3";break;
			}
		} else
		if(x/75==3){
			switch(y/75){
			case 0 :pos = "a4";break;
			case 1 :pos = "b4";break;
			case 2 :pos = "c4";break;
			case 3 :pos = "d4";break;
			case 4 :pos = "e4";break;
			case 5 :pos = "f4";break;
			case 6 :pos = "g4";break;
			case 7 :pos = "h4";break;
			}
		}
		else
			if(x/75==4){
				switch(y/75){
				case 0 :pos = "a5";break;
				case 1 :pos = "b5";break;
				case 2 :pos = "c5";break;
				case 3 :pos = "d5";break;
				case 4 :pos = "e5";break;
				case 5 :pos = "f5";break;
				case 6 :pos = "g5";break;
				case 7 :pos = "h5";break;
				}
			}
			else
				if(x/75==5){
					System.out.println("����");
					switch(y/75){
					case 0 :pos = "a6";break;
					case 1 :pos = "b6";break;
					case 2 :pos = "c6";break;
					case 3 :pos = "d6";break;
					case 4 :pos = "e6";break;
					case 5 :pos = "f6";break;
					case 6 :pos = "g6";break;
					case 7 :pos = "h6";break;
					}
				}
				else
					if(x/75==6){
						switch(y/75){
						case 0 :pos = "a7";break;
						case 1 :pos = "b7";break;
						case 2 :pos = "c7";break;
						case 3 :pos = "d7";break;
						case 4 :pos = "e7";break;
						case 5 :pos = "f7";break;
						case 6 :pos = "g7";break;
						case 7 :pos = "h7";break;
						}
					}
					else
						if(x/75==7){
							System.out.println("����");
							switch(y/75){
							case 0 :pos = "a8";break;
							case 1 :pos = "b8";break;
							case 2 :pos = "c8";break;
							case 3 :pos = "d8";break;
							case 4 :pos = "e8";break;
							case 5 :pos = "f8";break;
							case 6 :pos = "g8";break;
							case 7 :pos = "h8";break;
							}
						}
		return pos;
	}
	
	public static String getCoordinate(String num){//����->���Ͻ�����
		int x = 0;
		int y = 0;
		for(int i=0;i<ChessBoard.NumToCoor.size();i++){
			if(ChessBoard.NumToCoor.get(i).getNum().equals(num)){
				x=(int)ChessBoard.NumToCoor.get(i).getX();
				y=(int)ChessBoard.NumToCoor.get(i).getY();
				break;
			}
				
		}
		return ""+x+","+y;
	}

	public static String getNum(int id ){//id:1~64->����//��������idҪ+1
		return (id%8==0)? ""+(char)(id/8+96)+8 :""+(char)(id/8+97)+(id%8);
	}
	
	public static int getId(String num){//����->id:0~63
		return ((int)num.charAt(0)-97)*8+((int)num.charAt(1)-48-1);
	}
		
	public static void main(String []args){
//		System.out.println(getId("a1"));
//		System.out.println(getId("d8"));
//		System.out.println(getId("a4"));
		char c = 'a';
		System.out.println((char)(c+1));
	}
}

