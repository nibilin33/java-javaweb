package com.etc.util;

import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JTextField;

public class Jtextfield extends JTextField {
    private ImageIcon icon;

    public Jtextfield() {
        //��ȡ��ǰ·���µ�ͼƬ
        icon = new ImageIcon(getClass().getResource("./user.png"));
        Insets insets = new Insets(0, 20, 0, 0);
        //�����ı���������20
        this.setMargin(insets);
    }
    
    public void paintComponent(Graphics g) {
        Insets insets = getInsets();
        super.paintComponent(g);
        int iconWidth = icon.getIconWidth();
        int iconHeight = icon.getIconHeight();
        int Height = this.getHeight();
        //���ı����л���֮ǰͼƬ
        icon.paintIcon(this, g, (insets.left - iconWidth)/2, (Height - iconHeight) / 2);
    }

}
