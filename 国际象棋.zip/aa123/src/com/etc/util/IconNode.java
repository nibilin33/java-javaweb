package com.etc.util;

import javax.swing.Icon;
import javax.swing.tree.DefaultMutableTreeNode;

public class IconNode extends DefaultMutableTreeNode { 
	    private Icon icon; 
	    private String txt; 
	 
	    //ֻ�����ı��Ľڵ㹹��
	    public IconNode(String txt){
	        super();
	        this.txt=txt;
	    } 
	    public IconNode(Icon icon){
	        super();
	        this.icon=icon;
	    } 
	 
	    //�����ı���ͼƬ�Ľڵ㹹��
	    public IconNode(Icon icon,String txt){
	        super();
	        this.icon = icon; 
	        this.txt = txt;
	    }
		public void expandRow(int i) {
	        // TODO Auto-generated method stub
	         
	    }
		public Icon getIcon() {
			return icon;
		}
		public void setIcon(Icon icon) {
			this.icon = icon;
		}
		public String getTxt() {
			return txt;
		}
		public void setTxt(String txt) {
			this.txt = txt;
		}

}
