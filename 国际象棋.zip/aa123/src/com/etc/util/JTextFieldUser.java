package com.etc.util;

import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JTextField;

public class JTextFieldUser  extends JTextField {
	private ImageIcon icon;

    public JTextFieldUser() {
        //��ȡ��ǰ·���µ�ͼƬ
    	java.net.URL url = JTextFieldPassword.class.getResource("/Img/person.jpg");
		icon = new ImageIcon(url);
		//�����ı���������20   
        Insets insets = new Insets(0, 40, 0, 0);
        this.setMargin(insets);
    }
    
    @Override
    public void paintComponent(Graphics g) {
        Insets insets = getInsets();
        super.paintComponent(g);
        int iconWidth = icon.getIconWidth();
        int iconHeight = icon.getIconHeight();
        int Height = this.getHeight();
        //���ı����л���֮ǰͼƬ
        icon.paintIcon(this, g, (insets.left - iconWidth)/2, (Height - iconHeight) / 2);
    }
}
