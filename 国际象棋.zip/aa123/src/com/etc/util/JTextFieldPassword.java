package com.etc.util;

import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JPasswordField;

public class JTextFieldPassword extends JPasswordField {
	private ImageIcon icon ;
	public JTextFieldPassword(){
		java.net.URL url = JTextFieldPassword.class.getResource("/Img/suo.png");
		icon = new ImageIcon(url);
		//�����ı���������20
		Insets insets = new Insets(0, 40, 0, 0);
		this.setMargin(insets);
	}
	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		Insets insets = getInsets();
		super.paintComponent(g);
		int iconWidth = icon.getIconWidth();
		int iconHeight = icon.getIconHeight();
		int Height = this.getHeight();
		icon.paintIcon(this, g, (insets.left-iconWidth)/2, (Height - iconHeight) / 2);
	}
}
