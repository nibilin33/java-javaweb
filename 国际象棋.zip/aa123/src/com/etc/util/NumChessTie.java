package com.etc.util;

import java.io.Serializable;

public class NumChessTie implements Serializable{
	private String num ;
	private String chessName ;
	
	
	
	public NumChessTie(String num, String chessName) {
		super();
		this.num = num;
		this.chessName = chessName;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}
	public String getChessName() {
		return chessName;
	}

	public void setChessName(String chessName) {
		this.chessName = chessName;
	}

}
