package com.etc.util;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

public class IconNodeRenderer extends DefaultTreeCellRenderer//�̳и��� 
{ 
//��д�÷���
    public Component getTreeCellRendererComponent(JTree tree, Object value,boolean sel, boolean expanded, boolean leaf, int row,boolean hasFocus)
    { 
        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf,row, hasFocus); //���ø���ĸ÷��� 
        Icon icon = ((IconNode) value).getIcon();//�ӽڵ��ȡͼƬ
        String txt=((IconNode) value).getTxt(); //�ӽڵ��ȡ�ı�
        this.setIcon(icon);//����ͼƬ
        this.setText(txt);//�����ı�
        return this;
    }
}
