package com.etc.util;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class MyJpanel extends JPanel {
	private String url;
	public MyJpanel(String url){
		this.url = url;
	}
	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		java.net.URL url2 = MyJpanel.class.getResource("/Img/"+url);
		ImageIcon icon = new ImageIcon(url2);
		g.drawImage(icon.getImage(), 0, 0, icon.getIconWidth(),
				icon.getIconHeight(), null);
	}
}
