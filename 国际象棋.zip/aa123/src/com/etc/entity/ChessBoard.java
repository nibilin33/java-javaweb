package com.etc.entity;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.etc.util.GetPosition;
import com.etc.util.MapNum;

public class ChessBoard implements Serializable{
	private int x = -1 ;//����ѡ�е�x����
	private int y = -1;//����ѡ�е�y����
	public static  List<MapNum> NumToCoor = new ArrayList<MapNum>();//��¼�����������Ӧ������(����->��ʼ����)
	private List<String> filledNum = new ArrayList<String>();//��¼Ҫ����ɫ������
	private String dangerNum = new String();//��¼Ҫ����ɫ�����ţ���Σ�գ�
	private String transNumL = new String();//��¼Ҫ�����ɫ�����ţ�������λ��
	private String transNumR = new String();//��¼Ҫ�����ɫ�����ţ��ҳ�����λ��
	int f = -1;
	private boolean isMyTurn = true;//Ĭ���ֵ��Լ�����
	
	private boolean whiteTurn = false ;//�ֵ��׷�����
	private boolean blackTurn = true ;//�ֵ��ڷ�����
//	private boolean whitestart = false;//û�е����ʼ
//	private boolean blackstart = false;
	private boolean start = false;
	private boolean gameOver = false;
	 private boolean isWin = false;//Ӯ���¼�����
	 
	 public void resetAllBoolena(){
		 isMyTurn = true;//Ĭ���ֵ��Լ�����
			
		whiteTurn = false ;//�ֵ��׷�����
		blackTurn = true ;//�ֵ��ڷ�����
//		whitestart = false;//û�е����ʼ
//		blackstart = false;
		start = false;
		gameOver = false;
		isWin = false;//Ӯ���¼�����
	 }
	 
		public boolean isWin() {
			return isWin;
		}

		public void setWin(boolean isWin) {
			this.isWin = isWin;
		}
	public boolean isgameOver() {
		return gameOver;
	}


	public void setgameOver(boolean state) {
		this.gameOver = state;
	}



	
//	public boolean isWhitestart() {
//		return whitestart;
//	}
//
//	public void setWhitestart(boolean whitestart) {
//		this.whitestart = whitestart;
//	}
//
//	public boolean isBlackstart() {
//		return blackstart;
//	}
//
//	public void setBlackstart(boolean blackstart) {
//		this.blackstart = blackstart;
//	}

	public boolean isStart() {
		return start;
	}

	public void setStart(boolean start) {
		this.start = start;
	}

	public boolean isMyTurn() {
		return isMyTurn;
	}

	public void setMyTurn(boolean isMyTurn) {
		this.isMyTurn = isMyTurn;
	}

	public void paintChessBoard(Graphics g){//���ƣ���䣩����
		//���
		
				g.setColor(Color.gray);
				for(int i=0;i<600;){
					for(int j=0;j<600;){	
						if(i%2 == 0 &&  j%2 == 0){
							g.fillRect(j, i, 75, 75);
						}
						if(i%2 != 0 &&  j%2 != 0)
						{
							g.fillRect(j, i, 75, 75);
						}
						j+=75;				
					}
					i+=75;			
				}
			Graphics2D g2d = (Graphics2D) g;
			BasicStroke stroke=new BasicStroke(8,BasicStroke.CAP_ROUND,BasicStroke.JOIN_MITER);//���ƴ�����
			g2d.setStroke(stroke);
           
			if(x!=-1 && y!=-1){
				System.out.println("board�������ߵ�����:"+getFilledNum().size());
				for(int j=0;j<getFilledNum().size();j++)
					System.out.println("board�������ߵ�����:"+getFilledNum().get(j));

				Color color = new Color(255, 204, 102);
				g2d.setColor(color);
				String num = new GetPosition().getPosition(x, y);//�����ѡ����
				
				for(int i = 0;i<64;i++){
					MapNum mp = NumToCoor.get(i);//������������			
					if(mp.getNum().equals(num)){//�ҵ�ƥ�����������
						int oldX = (int)mp.getX();
						int oldY = (int)mp.getY();
						g2d.drawLine(oldX+5, oldY+5, oldX+25, oldY+5);
						g2d.drawLine(oldX+5, oldY+5, oldX+5, oldY+25);
						
						g2d.drawLine(oldX+50, oldY+70, oldX+70, oldY+70);
						g2d.drawLine(oldX+70, oldY+50, oldX+70, oldY+70);
						break;
					}
				}
				x=-1;
				y=-1;
			}
			
			//����ѡ����(��ɫ)
			for(int j=0;j<getFilledNum().size();j++)
				System.out.println("board�������ߵ�����:"+getFilledNum().get(j));

			Color color = new Color(80, 201, 101);
			g2d.setColor(color);
				for(int i=0;i<filledNum.size();i++){
					String []coor = GetPosition.getCoordinate(filledNum.get(i)).split(",");
					int x = Integer.parseInt(coor[0]);
					int y = Integer.parseInt(coor[1]);
					
					g2d.drawLine(x+5, y+5, x+25, y+5);
					g2d.drawLine(x+5, y+5, x+5, y+25);
					
					g2d.drawLine(x+50, y+70, x+70, y+70);
					g2d.drawLine(x+70, y+50, x+70, y+70);

				}
				
				//���Σ������(��ɫ)
				if(!dangerNum.equals("")){
					color = new Color(72, 7, 15);
					g2d.setColor(color);
					String []coor = GetPosition.getCoordinate(dangerNum).split(",");
					int x = Integer.parseInt(coor[0]);
					int y = Integer.parseInt(coor[1]);
					g2d.drawLine(x+50, y+5, x+70, y+5);
					g2d.drawLine(x+70, y+5, x+70, y+25);
					
					System.out.println("dangerNum=="+dangerNum+"  f="+f);
					//g2d.drawLine(x+50, y+70, x+70, y+70);
				//	g2d.drawLine(x+70, y+50, x+70, y+70);
				}
				
				//������λ����ɫ
				if(!transNumL.equals("")){
					color = new Color(51, 153, 255);
					g2d.setColor(color);
					String []coor = GetPosition.getCoordinate(transNumL).split(",");
					int x = Integer.parseInt(coor[0]);
					int y = Integer.parseInt(coor[1]);
					g2d.drawLine(x+5, y+5, x+25, y+5);
					g2d.drawLine(x+5, y+5, x+5, y+25);
					
					g2d.drawLine(x+50, y+70, x+70, y+70);
					g2d.drawLine(x+70, y+50, x+70, y+70);
				}
				if(!transNumR.equals("")){
					color = new Color(51, 153, 255);
					g2d.setColor(color);
					String []coor = GetPosition.getCoordinate(transNumR).split(",");
					int x = Integer.parseInt(coor[0]);
					int y = Integer.parseInt(coor[1]);
					g2d.drawLine(x+5, y+5, x+25, y+5);
					g2d.drawLine(x+5, y+5, x+5, y+25);
					
					g2d.drawLine(x+50, y+70, x+70, y+70);
					g2d.drawLine(x+70, y+50, x+70, y+70);
				}
            
				
	}

	@Override
	public String toString() {
		return "ChessBoard [dangerNum=" + dangerNum + ", f=" + f
				+ ", filledNum=" + filledNum + ", transNumL=" + transNumL
				+ ", transNumR=" + transNumR + ", x=" + x + ", y=" + y + "]";
	}

	public void setMapNum(){//��ʼ�������������Ӧ������()
		for(int i=0;i<600;){//��������
			for(int j=0;j<600;){	
					MapNum mp = new MapNum(); 
					mp.setLocation(j, i);
					NumToCoor.add(mp);
					j+=75;
			}
			i+=75;
		}		
		int m=97;
		int n=1;
		for(int i = 0 ;i<64; i++){//�������
			((MapNum) NumToCoor.get(i)).setNum(""+(char)m+n);
			n++;
			if(n==9){
				n=1;
				m++;
			}
		}
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

	public List<String> getFilledNum() {
		return filledNum;
	}

	public void setFilledNum(List<String> filledNum) {
		this.filledNum = filledNum;
	}
	
	public void addFilledNum(String num) {
		this.filledNum.add(num);
	}

	public String getDangerNum() {
		return dangerNum;
	}

	public void setDangerNum(String dangerNum, int f) {
		this.dangerNum = dangerNum;
		this.f = f;
	}

	public String getTransNumL() {
		return transNumL;
	}

	public void setTransNumL(String transNumL) {
		this.transNumL = transNumL;
	}

	public String getTransNumR() {
		return transNumR;
	}

	public void setTransNumR(String transNumR) {
		this.transNumR = transNumR;
	}

	public void setTransNum(String transNum) {
		this.transNumL = transNum;
		this.transNumR = transNum;
	}
	public boolean isWhiteTurn() {
		return whiteTurn;
	}

	public void setWhiteTurn(boolean whiteTurn) {
		this.whiteTurn = whiteTurn;
	}

	public boolean isBlackTurn() {
		return blackTurn;
	}

	public void setBlackTurn(boolean blackTurn) {
		this.blackTurn = blackTurn;
	}

}
