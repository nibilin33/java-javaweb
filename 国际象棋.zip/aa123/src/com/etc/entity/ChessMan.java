package com.etc.entity;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JPanel;

import com.etc.util.GetPosition;
import com.etc.util.NumChessTie;
public class ChessMan implements Serializable{
	
	private String[] select = null;//���ӱ��������
	private String [] chessManName = null ;//{"��","��","��","��","��","��"};
	private List<NumChessTie> tie = new ArrayList<NumChessTie>() ;//��¼������������Ӧ�����ţ�����->���ţ�
	private int oldX ;
	private int oldY ;
	private int newX ;
	private int newY ;
	private String color = null;
	private boolean firstPaint = true;//�״λ�������
//	public  ChessMan(){
//		market = -1;
//	}
//	
	public void paintFirstChesstMan(Graphics g, PaintCheeteMap fcm){
		Image img = null;
		String coorS = null;
		String []coor = null;
		
		for(int i=0;i<tie.size();i++){//�Ȼ����˱����������
			NumChessTie tieOne = tie.get(i);
			String name = tieOne.getChessName();
			//�Ȼ���һ��
			if(name.startsWith("w")){
				if(name.startsWith("w��"))
				img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
			coorS = GetPosition.getCoordinate(tieOne.getNum());
			coor= coorS.split(",");
			//System.out.println("name="+name + " coor=" + coorS);
			g.drawImage(img, Integer.parseInt(coor[0])+20, Integer.parseInt(coor[1])+5, 35, 65, (ImageObserver) fcm);
			}
			else {
			if(name.startsWith("b")){
				 if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png"); 
				 if(name.startsWith("b��"))
					 img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");			
				coorS = GetPosition.getCoordinate(tieOne.getNum());
				coor= coorS.split(",");
			//	System.out.println("name="+name + " coor=" + coorS);
				g.drawImage(img, Integer.parseInt(coor[0])+20, Integer.parseInt(coor[1])+5, 35, 65, (ImageObserver) fcm);
			}
			}
		}
	}
	public void paintFirstChesstMan(Graphics g, JPanel fcm){
		Image img = null;
		String coorS = null;
		String []coor = null;
		
		for(int i=0;i<tie.size();i++){//�Ȼ����˱����������
			NumChessTie tieOne = tie.get(i);
			String name = tieOne.getChessName();
			//�Ȼ���һ��
			if(name.startsWith("w")){
				if(name.startsWith("w��"))
				img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				else if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
				if(name.startsWith("w��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/w��.png");
			coorS = GetPosition.getCoordinate(tieOne.getNum());
			coor= coorS.split(",");
			//System.out.println("name="+name + " coor=" + coorS);
			g.drawImage(img, Integer.parseInt(coor[0])+20, Integer.parseInt(coor[1])+5, 35, 65, (ImageObserver) fcm);
			}
			else {
			if(name.startsWith("b")){
				 if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");
				else if(name.startsWith("b��"))
					img = Toolkit.getDefaultToolkit().getImage("picture/b��.png"); 
				 if(name.startsWith("b��"))
					 img = Toolkit.getDefaultToolkit().getImage("picture/b��.png");			
				coorS = GetPosition.getCoordinate(tieOne.getNum());
				coor= coorS.split(",");
			//	System.out.println("name="+name + " coor=" + coorS);
				g.drawImage(img, Integer.parseInt(coor[0])+20, Integer.parseInt(coor[1])+5, 35, 65, (ImageObserver) fcm);
			}
			}
		}
	}
	public void paintChesstMan(Graphics g, PaintCheeteMap fcm){
		
	}
	
	public String[] getSelect() {
		return select;
	}
	public void setSelect(String[] select) {
		this.select = select;
	}
	public String[] getChessManName() {
		return chessManName;
	}
	public void setChessManName(String[] chessManName) {
		this.chessManName = chessManName;
	}

	public List<NumChessTie> getTie() {
		return tie;
	}
	
	@Override
	public String toString() {
		return "ChessMan [chessManName=" + Arrays.toString(chessManName)
				+ ", color=" + color + ", firstPaint=" + firstPaint + ", newX="
				+ newX + ", newY=" + newY + ", oldX=" + oldX + ", oldY=" + oldY
				+ ", select=" + Arrays.toString(select) + ", tie=" + tie + "]";
	}
	public void setTie(String name  , String newNum){
		for(int i=0;i<tie.size();i++){
			if(tie.get(i).getChessName().equals(name)){
				tie.get(i).setNum(newNum);
				break;
			}
		}
	}
	
	public void setTie(){//��ʼ������������Ӧ�����ţ�����->���ţ�
		tie.add(new NumChessTie("a1", "w��l"));
		tie.add(new NumChessTie("a8", "w��r"));
		tie.add(new NumChessTie("a2", "w��l"));
		tie.add(new NumChessTie("a7", "w��r"));
		tie.add(new NumChessTie("a3", "w��l"));
		tie.add(new NumChessTie("a6", "w��r"));
		tie.add(new NumChessTie("a4", "w��"));
		tie.add(new NumChessTie("a5", "w��"));
		for(int i = 1;i<=8;i++){
			tie.add(new NumChessTie("b"+i, "w��"+i));		
		}
		tie.add(new NumChessTie("h1", "b��l"));
		tie.add(new NumChessTie("h8", "b��r"));
		tie.add(new NumChessTie("h2", "b��l"));
		tie.add(new NumChessTie("h7", "b��r"));
		tie.add(new NumChessTie("h3", "b��l"));
		tie.add(new NumChessTie("h6", "b��r"));
		tie.add(new NumChessTie("h4", "b��"));
		tie.add(new NumChessTie("h5", "b��"));
		
		for(int i = 1;i<=8;i++){
			tie.add(new NumChessTie("g"+i,"b��"+i));
		}

	}	


	public int getOldX() {
		return oldX;
	}


	public void setOldX(int oldX) {
		this.oldX = oldX;
	}


	public int getOldY() {
		return oldY;
	}


	public void setOldY(int oldY) {
		this.oldY = oldY;
	}


	public int getNewX() {
		return newX;
	}


	public void setNewX(int newX) {
		this.newX = newX;
	}


	public int getNewY() {
		return newY;
	}


	public void setNewY(int newY) {
		this.newY = newY;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	

	
	
	
}
