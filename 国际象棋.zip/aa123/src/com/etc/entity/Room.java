package com.etc.entity;

import java.io.Serializable;
import java.util.ArrayList;

public class Room implements Serializable{
	private int id;
	private String left;
	private String right;
	private int gamestate;//0 1 2
	private ChessBoard chessboard=new ChessBoard();
	private Rule rule;
	private Move move;
	private GoMethod gomethod;
	public Rule getRule() {
		return rule;
	}
	public void setRule(Rule rule) {
		this.rule = rule;
	}
	public Move getMove() {
		return move;
	}
	public void setMove(Move move) {
		this.move = move;
	}
	public GoMethod getGomethod() {
		return gomethod;
	}
	public void setGomethod(GoMethod gomethod) {
		this.gomethod = gomethod;
	}
	public ChessBoard getChessboard() {
		return chessboard;
	} 
	public ChessMan getChessman() {
		return chessman;
	}
	public void setChessboard(ChessBoard chessboard) {
		this.chessboard = chessboard;
	}
	public void setChessman(ChessMan chessman) {
		this.chessman = chessman;
	}
	private ChessMan chessman=new ChessMan();
	public Room(){}
	public Room(int id, String left, String right, int gamestate) {
		super();
		this.id = id;
		this.left = left;
		this.right = right;
		this.gamestate = gamestate;
		chessman.setTie();
		chessboard.setMapNum();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLeft() {
		return left;
	}
	public void setLeft(String left) {
		this.left = left;
	}
	public String getRight() {
		return right;
	}
	public void setRight(String right) {
		this.right = right;
	}
	public int getGamestate() {
		return gamestate;
	}
	public void setGamestate(int gamestate) {
		this.gamestate = gamestate;
	}
	

   
}
