package com.etc.gui;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;

import javax.print.DocFlavor.URL;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.UIManager;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.skin.EmeraldDuskSkin;
import org.jvnet.substance.theme.SubstanceTerracottaTheme;
import org.jvnet.substance.watermark.SubstanceBubblesWatermark;

import com.etc.data.RegisterMsg;
import com.etc.util.JTextFieldPassword;
import com.etc.util.JTextFieldUser;
import com.etc.util.MyJpanel;
import com.net.Client;

import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.Socket;

public class RegFrame extends JFrame implements Iregister{
	private JTextFieldUser accountF;
	private JTextFieldPassword passwordF1;
	private JTextFieldPassword passwordF2;
	private MyJpanel contentPane;
	private static  Client client ;
	private LoginFrame lf;
	
	
	
	public LoginFrame getLf() {
		return lf;
	}

	public void setLf(LoginFrame lf) {
		this.lf = lf;
	}

	public static  Client getClient() {
		return client;
	}
	
	public RegFrame(){
		setTitle("ע��");
		setBounds(400,200,400,300);
		setVisible(true);
		java.net.URL url=LoginFrame.class.getResource("/Img/1.jpg");
		Image icon=Toolkit.getDefaultToolkit().getImage(url);
		setIconImage(icon);
		

		contentPane = new MyJpanel("regback3.jpg");
		getContentPane().add(contentPane, BorderLayout.CENTER);
		contentPane.setLayout(null);
		
		java.net.URL url1 = RegFrame.class.getResource("/Img/regi.png");
		ImageIcon icon1 = new ImageIcon(url1);
		JButton regist = new JButton("");
		regist.setIcon(icon1);
		regist.setContentAreaFilled(false);
		regist.setBorderPainted(false);
		regist.setMargin(new Insets(0,0,0,0));
		regist.setBorder(BorderFactory.createRaisedBevelBorder());
		regist.setBounds(74, 219, 90, 33);
		contentPane.add(regist);
		
		java.net.URL url2 = RegFrame.class.getResource("/Img/ret.png");
		ImageIcon icon2 = new ImageIcon(url2);
		JButton rten = new JButton("");
		rten.setIcon(icon2);
		rten.setContentAreaFilled(false);
		rten.setBorderPainted(false);
		rten.setMargin(new Insets(0,0,0,0));
		rten.setBorder(BorderFactory.createRaisedBevelBorder());
		rten.setBounds(203, 219, 90, 33);
		contentPane.add(rten);
		
		accountF = new JTextFieldUser();
		accountF.setBounds(86, 58, 193, 26);
		contentPane.add(accountF);
		accountF.setColumns(10);
		
		passwordF1 = new JTextFieldPassword();
		passwordF1.setBounds(86, 112, 193, 26);
		contentPane.add(passwordF1);
		
		passwordF2 = new JTextFieldPassword();
		passwordF2.setBounds(86, 156, 193, 26);
		contentPane.add(passwordF2);
		
		

		
		client = LoginFrame.getClient();

		
		regist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(isfill()&&istheSame()&&!isover()){
					String account = accountF.getText().trim();
					String psd = new String( passwordF1.getPassword()).trim();
					
					if(client.connect()){
						RegisterMsg msg = new RegisterMsg(account,psd);
						client.setIregister(RegFrame.this);
						client.sendMsg(msg);
					}
				}
			}
		});

		
		//���ص������
		rten.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lf.setVisible(true);
				dispose();
			}
		});
	}
	public boolean istheSame(){
		String psd1 = new String( passwordF1.getPassword()).trim();
		String psd2 = new String( passwordF2.getPassword()).trim();
		if(psd1.equals(psd2)==false){
			JOptionPane.showMessageDialog(this, "�������벻һ��!");
			return false;
		}
		return true;
	}
	public boolean isfill(){
		String account = accountF.getText().trim();
		String psd1 = new String( passwordF1.getPassword()).trim();
		String psd2 = new String( passwordF2.getPassword()).trim();
		if(account.equals(null)||account.equals("")){
			JOptionPane.showMessageDialog(this, "�������˺�!");
			return false;
		}
		if(psd1.equals(null)||psd1.equals("")){
			JOptionPane.showMessageDialog(this, "����������!");
			return false;
		}
		if(psd2.equals(null)||psd2.equals("")){
			JOptionPane.showMessageDialog(this, "������ȷ������!");
			return false;
		}
		return true;
	}
	public boolean isover(){
		String account = accountF.getText().trim();
		String psd1 = new String( passwordF1.getPassword()).trim();
		if(account.length()>20){
			JOptionPane.showMessageDialog(this, "�˺ų��Ȳ��ó���20!");
			return true;
		}
		if(psd1.length()>20){
			JOptionPane.showMessageDialog(this, "���볤�Ȳ��ó���20!");
			return true;
		}
		return false;
	}
	@Override
	public void showSregister() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(this, "ע��ɹ���");
		setVisible(false);
	}
	@Override
	public void showFregister() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(this, "�û����Ѵ��ڣ�");
	}
}
