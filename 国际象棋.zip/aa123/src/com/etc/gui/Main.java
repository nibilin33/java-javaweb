package com.etc.gui;

import com.net.Client;

public class Main {
	private static Client client;
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
