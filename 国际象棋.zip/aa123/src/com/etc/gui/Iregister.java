package com.etc.gui;

public interface Iregister {
  void showSregister();
  void showFregister();
}
