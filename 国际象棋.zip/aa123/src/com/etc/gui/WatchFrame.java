/*
 * WatchFrame.java
 *
 * Created on __DATE__, __TIME__
 */

package com.etc.gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.theme.SubstanceTerracottaTheme;

import com.etc.data.AskMiddleMan;
import com.etc.data.AskRoom;
import com.etc.data.BasicMsg;
import com.etc.data.ExitChessRoomMsg;
import com.etc.data.ExitGameRoomMsg;
import com.etc.data.ShutDownWatch;
import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.PaintCheeteMap;
import com.etc.entity.Room;
import com.etc.util.JDBC;
import com.net.Client;

/**
 *
 * @author  __USER__
 */
public class WatchFrame extends JFrame implements Iwatch,WindowListener,ActionListener{
	private JPanel contentPane;
	private ChessMan man = new ChessMan();
	private ChessBoard board = new ChessBoard();
	private int roomid;
	private boolean towatch=true;
	JDialog jd;
    public cheeseMap getCheesemap() {
		return cheesemap;
	}

	public void setCheesemap(cheeseMap cheesemap) {
		this.cheesemap = cheesemap;
	}

	private cheeseMap cheesemap;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		
//		try {
//			  try {
//		            UIManager.setLookAndFeel(new SubstanceLookAndFeel());
//		            JFrame.setDefaultLookAndFeelDecorated(true);
//		            JDialog.setDefaultLookAndFeelDecorated(true);
//		            SubstanceLookAndFeel.setCurrentTheme(new SubstanceTerracottaTheme());
//		          SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());
//		          SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());
//		          SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());
//		        } catch (Exception e) {
//		            System.err.println("Something went wrong!");
//		        }
//			} catch (Exception e) {
//			e.printStackTrace();
//			}
//		
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					WatchFrame frame = new WatchFrame();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public WatchFrame() {
		LoginFrame.getClient().setIwatch(this);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 620, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		board.setMapNum();//���������������Ӧ������(����->����)		
		man.setTie();//��ʼ������������Ӧ�����ţ�����->���ţ�//���ϱ仯
		man.setColor("black");//������ɫ����ɫΪ���ӣ�
	    cheesemap = new cheeseMap(man , board);
		cheesemap.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 204, 102), new Color(255, 204, 102), new Color(255, 204, 102), new Color(255, 204, 102)));
		cheesemap.setBounds(5 , 5, 600, 600);
		cheesemap.setBackground(Color.white);
		contentPane.add(cheesemap);
		cheesemap.setEnabled(false);
		   
		    //�����������������ص���Ϣ�߳�
//		             	AskRoom ask=new AskRoom(roomid,true,LoginFrame.getClient().getWatch());
//						ObjectOutputStream os;
//						try {
//							os = new ObjectOutputStream(LoginFrame.getClient().getWatch().getOutputStream());
//							os.writeObject(ask);
//						} catch (IOException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
			    		//msg.setClient(this.socket);
			    	AskMiddleMan milde=new AskMiddleMan(roomid);
			    	LoginFrame.getClient().sendMsg(milde);
	    		System.out.println("��������");
		    	
	    //   LoginFrame.getClient().sendMsg(ask);
	    		
	}
	class cheeseMap extends JPanel{
		private ChessMan man = null;
		private ChessBoard board = null;
	
		public ChessMan getMan() {
			return man;
		}

		public void setMan(ChessMan man) {
			this.man = man;
		}

		public ChessBoard getBoard() {
			return board;
		}

		public void setBoard(ChessBoard board) {
			this.board = board;
		}

		public cheeseMap(final ChessMan man, final ChessBoard board){
			this.man = man;
			this.board = board;
		}
		
		@Override
		
		public void paint(Graphics g) {
			// TODO Auto-generated method stub
			super.paint(g);
			// TODO Auto-generated method stub
			// ��������
			board.paintChessBoard(g);

			// ��������
			man.paintFirstChesstMan(g, this);

		}
	}
	@Override
	public void watchrun(final int roomid) {
		// TODO Auto-generated method stub
	   this.roomid=roomid;
	 

	}

	@Override
	public void repaiting(ChessBoard board, ChessMan man) {
		// TODO Auto-generated method stub
		cheesemap.board=board;
		cheesemap.man=man;
		cheesemap.repaint();
		System.out.println("�ػ氡����");
	}

	@Override
	protected void processWindowEvent(WindowEvent e) {
		// TODO Auto-generated method stub
		if(e.getID() == WindowEvent.WINDOW_CLOSED){
			System.out.println("aaaaaaaaaaaaaaa");
			ShutDownWatch shut=new ShutDownWatch(LoginFrame.getClient().getWatch());
			LoginFrame.getClient().sendMsg(shut);
			ExitChessRoomMsg exit=new ExitChessRoomMsg(roomid,LoginFrame.getUser().getName());
			LoginFrame.getClient().sendMsg(exit);
			try {
				LoginFrame.getClient().getWatch().close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			WatchFrame.this.dispose();
//			jd = new JDialog(WatchFrame.this , true);
//			jd.setAlwaysOnTop(true);
//			jd.setResizable(false);
//			jd.setTitle("ȷ��Ҫ �˳� ��");
//			jd.setBounds(WatchFrame.this.getX()+200, WatchFrame.this.getY()+200, 200, 70);
//			jd.getContentPane().setLayout(null);
//			
//			JButton btCancel = new JButton("ȡ��");
//			btCancel.setBounds(110, 10, 70, 23);
//			jd.getContentPane().add(btCancel);
//			btCancel.addActionListener(this);
//
//			JButton btYes = new JButton("ȷ��");
//			btYes.setBounds(20, 10, 70, 23);
//			jd.getContentPane().add(btYes);
//			btYes.addActionListener(this);
//			jd.setVisible(true);
//			ShutDownWatch shut=new ShutDownWatch(LoginFrame.getClient().getWatch());
//			LoginFrame.getClient().sendMsg(shut);
		
		}else{
			super.processWindowEvent(e);
		}
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		if(e.getActionCommand().equals("ȷ��")){
//			ShutDownWatch shut=new ShutDownWatch(LoginFrame.getClient().getWatch());
//			LoginFrame.getClient().sendMsg(shut);
//			ExitChessRoomMsg exit=new ExitChessRoomMsg(roomid,LoginFrame.getUser().getName());
//			LoginFrame.getClient().sendMsg(exit);
//			try {
//				LoginFrame.getClient().getWatch().close();
//			} catch (IOException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		   jd.dispose();
//		  WatchFrame.this.dispose();
//		}else if( e.getActionCommand().equals("ȡ��"))
//			jd.dispose();
//	}
//	@Override
//	public void windowClosing(WindowEvent e) {
//		// TODO Auto-generated method stub
//		if(e.getID() == 201){
//		System.out.println("keke");
//		jd = new JDialog(WatchFrame.this , true);
//		jd.setAlwaysOnTop(true);
//		jd.setResizable(false);
//		jd.setTitle("ȷ��Ҫ �˳� ��");
//		jd.setBounds(WatchFrame.this.getX()+200, WatchFrame.this.getY()+200, 200, 70);
//		jd.getContentPane().setLayout(null);
//		
//		JButton btCancel = new JButton("ȡ��");
//		btCancel.setBounds(110, 10, 70, 23);
//		jd.getContentPane().add(btCancel);
//		btCancel.addActionListener(this);
//
//		JButton btYes = new JButton("ȷ��");
//		btYes.setBounds(20, 10, 70, 23);
//		jd.getContentPane().add(btYes);
//		btYes.addActionListener(this);
//		jd.setVisible(true);
//
//	}else{
//		super.processWindowEvent(e);
//	}
//	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}