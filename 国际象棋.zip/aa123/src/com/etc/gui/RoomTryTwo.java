package com.etc.gui;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.theme.SubstanceTerracottaTheme;

import com.etc.data.ChatMsg;
import com.etc.data.ExitChessRoomMsg;
import com.etc.data.RequestLoseMsg;
import com.etc.data.ResetChessRoom;
import com.etc.data.StartGameMsg;
import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.PaintCheeteMap;
import com.etc.entity.Room;
import com.etc.util.JDBC;
import com.etc.util.MyJpanel;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RoomTryTwo extends JFrame implements IChessRoom , ActionListener {
	static{
		try {
            UIManager.setLookAndFeel(new SubstanceLookAndFeel());
            JFrame.setDefaultLookAndFeelDecorated(true);
            JDialog.setDefaultLookAndFeelDecorated(true);
            SubstanceLookAndFeel.setCurrentTheme(new SubstanceTerracottaTheme());
          SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());
          SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());
          SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());
        } catch (Exception e) {
            System.err.println("Something went wrong!");
        }
	}

	private JPanel contentPane;			
	public static int roomid;
	private ChessMan man = new ChessMan();
	private PaintCheeteMap cheeseMap;
	JDialog jd = null;
	JTextArea textArea,textArea_1;
	private Room room=new Room();
	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	JDBC jdbc = new JDBC(); 
	public PaintCheeteMap getCheeseMap() {
		return cheeseMap;
	}

	public void setCheeseMap(PaintCheeteMap cheeseMap) {
		this.cheeseMap = cheeseMap;
	}

	public ChessMan getMan() {
		return man;
	}

	public void setMan(ChessMan man) {
		this.man = man;
	}

	public ChessBoard getBoard() {
		return board;
	}

	public void setBoard(ChessBoard board) {
		this.board = board;
	}

	private ChessBoard board = new ChessBoard();
	//testDanger t = new testDanger();
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		try {
//			  try {
//		            UIManager.setLookAndFeel(new SubstanceLookAndFeel());
//		            JFrame.setDefaultLookAndFeelDecorated(true);
//		            JDialog.setDefaultLookAndFeelDecorated(true);
//		            SubstanceLookAndFeel.setCurrentTheme(new SubstanceTerracottaTheme());
//		          SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());
//		          SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());
//		          SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());
//		        } catch (Exception e) {
//		            System.err.println("Something went wrong!");
//		        }
//			} catch (Exception e) {
//			e.printStackTrace();
//			}
//		
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//				//	RoomTryTwo frame = new RoomTryTwo("white");
//					RoomTryTwo frame = new RoomTryTwo("black");
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//		
//	}

	/**
	 * Create the frame.
	 */
	public RoomTryTwo(String color,Room room) {
        roomid=room.getId();
        setRoom(room);
	    LoginFrame.getClient().setIchessroom(this);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 886, 653);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.roomid=roomid;
		
		
		board.setMapNum();//���������������Ӧ������(����->����)		
		man.setTie();//��ʼ������������Ӧ�����ţ�����->���ţ�//���ϱ仯
		man.setColor(color);//������ɫ����ɫΪ���ӣ�
		
//		if(man.getColor().startsWith("b"))
//			board.setStart(false);
//		else
//			board.setStart(true);
		
		cheeseMap = new PaintCheeteMap(man , board);
		LoginFrame.getClient().setCheessmap(cheeseMap);
		cheeseMap.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 204, 102), new Color(255, 204, 102), new Color(255, 204, 102), new Color(255, 204, 102)));
		cheeseMap.setBounds(5 , 5, 600, 600);
		cheeseMap.setBackground(Color.white);
		contentPane.add(cheeseMap);
		
		JPanel rightPan =  new MyJpanel("hallback2_1.jpg");

		rightPan.setBounds(615, 5, 247, 610);
		rightPan.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 204, 102), new Color(255, 204, 102), new Color(255, 204, 102), new Color(255, 204, 102)));
		contentPane.add(rightPan);
		rightPan.setLayout(null);
		
		JButton actionBut = new JButton("����");
		actionBut.addActionListener(this);
		actionBut.setBounds(10, 10, 147, 48);
		rightPan.add(actionBut);
		
		JButton getOutBut = new JButton("����");
		getOutBut.setBounds(167, 10, 70, 48);
		rightPan.add(getOutBut);
		getOutBut.addActionListener(this);
		
		JPanel bpan = new JPanel();
		bpan.setOpaque(false);
		bpan.setBounds(10, 90, 100, 150);
		rightPan.add(bpan);
		bpan.setLayout(null);		
		ImageIcon image = new ImageIcon("picture/��.png");
		image.setImage(image.getImage().getScaledInstance(40,70,Image.SCALE_DEFAULT));			
		JLabel bpic = new JLabel("");
		bpic.setBounds(0, 0, 100, 100);
		bpan.add(bpic);
		bpic.setIcon(image);
		
		JLabel bUserName = new JLabel(room.getLeft());
		
		
		bUserName.setFont(new Font("��Բ", Font.BOLD, 16));
		bUserName.setForeground(new Color(255, 204, 51));
		bUserName.setBounds(10, 110, 68, 30);
		bpan.add(bUserName);
		
		JPanel wpan = new JPanel();
		wpan.setOpaque(false);
		wpan.setBounds(137, 90, 100, 150);
		rightPan.add(wpan);
		wpan.setLayout(null);
		image = new ImageIcon("picture/��.png");
		image.setImage(image.getImage().getScaledInstance(40,68,Image.SCALE_DEFAULT));
		JLabel wpic = new JLabel("");
		wpic.setBounds(0, 0, 100, 100);
		wpan.add(wpic);
		wpic.setIcon(image);
		
		JLabel wUserName = new JLabel(room.getRight());
		wUserName.setFont(new Font("��Բ", Font.BOLD, 16));
		wUserName.setForeground(new Color(255, 204, 51));
		wUserName.setBounds(10, 110, 68, 30);
		wpan.add(wUserName);
		
		textArea = new JTextArea();
		textArea.setBounds(10, 291, 227, 225);
		rightPan.add(textArea);
		

		JButton btSentMsg = new JButton("����");
		btSentMsg.setBounds(198, 526, 39, 24);
		btSentMsg.addActionListener(this);
		rightPan.add(btSentMsg);
		
		textArea_1 = new JTextArea();
		textArea_1.setForeground(Color.GRAY);
		textArea_1.setText("\u8BF7\u8F93\u5165\u4FE1\u606F");
		textArea_1.setBounds(10, 525, 178, 24);
		rightPan.add(textArea_1);
		setVisible(true);
		
		

	}

	@Override
	public void exitshow() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void loseshow() {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void peaceshow() {//����
		// TODO Auto-generated method stub
		
	}

	@Override
	public void talkshow(String text) {
		// TODO Auto-generated method stub
	     textArea.setText(text+"\n");
	}

	@Override
	public void timeshow() {
		// TODO Auto-generated method stub
		System.out.println("��rrrrrrrrrrrrrrrrrrrrr");
		 board.setStart(true);
		 cheeseMap.setBoard(board);
		cheeseMap.repaint();
	}

	@Override
	public void winshow(String color) {
		// TODO Auto-generated method stub
		jd = new JDialog(RoomTryTwo.this , true);
		jd.setAlwaysOnTop(true);
		jd.setResizable(false);
		System.out.println("room_isMin:"+board.isWin()+"��ǰ��Ӫ"+man.getColor());
		if(board.isWin())
			jd.setTitle(color+"��Ӯ�ˣ�");
		else
			jd.setTitle(color+"�����ˣ�");
		jd.setBounds(RoomTryTwo.this.getX()+200, RoomTryTwo.this.getY()+200, 200, 70);
		jd.getContentPane().setLayout(null);
		
		JButton btCancel = new JButton("�˳�����");
		btCancel.setBounds(110, 10, 70, 23);
		jd.getContentPane().add(btCancel);
		btCancel.addActionListener(this);

		JButton btYes = new JButton("���ڷ���");
		btYes.setBounds(20, 10, 70, 23);
		jd.getContentPane().add(btYes);
		btYes.addActionListener(this);
		jd.setVisible(true);
		jdbc.clearNumber(RoomTryTwo.roomid);


	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("����")){
			
			jdbc.addNumber(RoomTryTwo.roomid);
//			if(jdbc.getNumber(RoomTryTwo.roomid) >1){
//				System.out.println("room_setstart");
//				 board.setStart(true);
//			}
//			  

		   
			//�ͻ����Ϳ��ֱ���
//			StartGameMsg startgame=new StartGameMsg(roomid,LoginFrame.getClient().getSocket());
//			LoginFrame.getClient().sendMsg(startgame);
		
		}else
			if(e.getActionCommand().equals("����")){
				System.out.println("����");
			
				jd = new JDialog(RoomTryTwo.this ,true);
				jd.setAlwaysOnTop(true);
				jd.setResizable(false);
				jd.setTitle("ȷ��Ҫ "+e.getActionCommand()+" ��");
				jd.setBounds(RoomTryTwo.this.getX()+200, RoomTryTwo.this.getY()+200, 200, 70);
				jd.getContentPane().setLayout(null);
				
				JButton btCancel = new JButton("ȡ��");
				btCancel.setBounds(110, 10, 70, 23);
				jd.getContentPane().add(btCancel);
				btCancel.addActionListener(this);

				JButton btYes = new JButton("ȷ��");
				btYes.setBounds(20, 10, 70, 23);
				jd.getContentPane().add(btYes);
				btYes.addActionListener(this);
				jd.setVisible(true);
			}
			else{
				if(e.getActionCommand().equals("ȷ��")){
					//�������䱨�ģ��޸�score���޸�room״̬
					
					if(board.isgameOver()){//��Ϸ����֮ǰ��x�޸ıȷ֣���Ϸ����֮���x�����޸ıȷ�
						 RequestLoseMsg lose=new RequestLoseMsg(LoginFrame.getUser(),RoomTryTwo.roomid);
						 LoginFrame.getClient().sendMsg(lose);
					}else{
						     //�޸ķ���״̬
						ExitChessRoomMsg exit=new ExitChessRoomMsg(roomid, LoginFrame.getUser().getName());
						LoginFrame.getClient().sendMsg(exit);
					 
					}
					if(!board.isStart()){//��Ϸ��ʼ���뿪���䣬��Ϊ��
						ExitChessRoomMsg exit=new ExitChessRoomMsg(roomid, LoginFrame.getUser().getName());
						LoginFrame.getClient().sendMsg(exit);
					}
					jdbc.clearNumber(RoomTryTwo.roomid);
					RoomTryTwo.this.dispose();
					 jd.dispose();
				}else if(e.getActionCommand().equals("ȡ��")){
					jd.dispose();
				}
			}
	
			 if(e.getActionCommand().equals("���ڷ���")){
					System.out.println("���ڷ���");
					//���ģ���ʼ������
					man.setTie();
					board.resetAllBoolena();
			        
					ResetChessRoom re=new ResetChessRoom(roomid, board, man);
					LoginFrame.getClient().sendMsg(re);
					jd.dispose();
					
				}else if(e.getActionCommand().equals("�˳�����")){
					//�޸ķ���״̬
					ExitChessRoomMsg exit=new ExitChessRoomMsg(roomid,LoginFrame.getUser().getName());
					LoginFrame.getClient().sendMsg(exit);
					jd.dispose();
					RoomTryTwo.this.dispose();
				
				}
			 if(e.getActionCommand().equals("����")){
				 ChatMsg chat=new ChatMsg(textArea_1.getText(),roomid);
				 LoginFrame.getClient().sendMsg(chat);
				 textArea_1.setText("");
			 }
		

	}


	@Override
	protected void processWindowEvent(WindowEvent e) {
		System.out.println("e.id:"+e.getID());
		// TODO Auto-generated method stub
		if(e.getID() == 201){
			System.out.println("keke");
			jd = new JDialog(RoomTryTwo.this , true);
			jd.setAlwaysOnTop(true);
			jd.setResizable(false);
			jd.setTitle("ȷ��Ҫ �˳� ��");
			jd.setBounds(RoomTryTwo.this.getX()+200, RoomTryTwo.this.getY()+200, 200, 70);
			jd.getContentPane().setLayout(null);
			
			JButton btCancel = new JButton("ȡ��");
			btCancel.setBounds(110, 10, 70, 23);
			jd.getContentPane().add(btCancel);
			btCancel.addActionListener(this);

			JButton btYes = new JButton("ȷ��");
			btYes.setBounds(20, 10, 70, 23);
			jd.getContentPane().add(btYes);
			btYes.addActionListener(this);
			jd.setVisible(true);

		}else{
			super.processWindowEvent(e);
		}
		
	}

}
