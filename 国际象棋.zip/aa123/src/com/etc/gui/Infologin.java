package com.etc.gui;

public interface Infologin {
void informSuc(String username);//�ɹ�
void informFail();//ʧ��
void exist();
}
