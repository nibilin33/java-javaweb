package com.etc.gui;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.border.StandardBorderPainter;
import org.jvnet.substance.button.ClassicButtonShaper;
import org.jvnet.substance.painter.StandardGradientPainter;
import org.jvnet.substance.theme.SubstanceTerracottaTheme;
import org.jvnet.substance.watermark.SubstanceBubblesWatermark;

import com.etc.data.ClientLoginMsg;
import com.etc.entity.User;
import com.etc.util.JTextFieldPassword;
import com.etc.util.JTextFieldUser;
import com.etc.util.MyJpanel;
import com.net.Client;

public class LoginFrame extends JFrame implements Infologin{
	private JTextField accountF;
	private JPasswordField passwordF;
	private HallFrame hall;
	private static Client client;
	private static User user;
	private MyJpanel conter ;
	RegFrame reg ;
	
	public static User getUser() {
		return user;
	}
	public static void setUser(User user) {
		LoginFrame.user = user;
	}
	public static Client getClient() {
		return client;
	}
	public static void setClient(Client client) {
		LoginFrame.client = client;
	}
	
	
	public LoginFrame(){
	
		setVisible(true);
		setResizable(false);
		setBounds(400,200,400,300);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		

		java.net.URL url=LoginFrame.class.getResource("/Img/1.jpg");
		Image icon=Toolkit.getDefaultToolkit().getImage(url);
		setIconImage(icon);
		
		
		client=new Client(this);
		client.setInlogin(this);
		
		JPanel northP = new JPanel();
		northP.setBackground(Color.black);
		getContentPane().add(northP, BorderLayout.SOUTH);
		
		java.net.URL url2=LoginFrame.class.getResource("/Img/lo.png");
		ImageIcon icon2 = new ImageIcon(url2);
		JLabel loginB = new JLabel();
		loginB.setCursor(new Cursor(Cursor.HAND_CURSOR));
		loginB.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				String account = accountF.getText().trim();
				String psd = new String (passwordF.getPassword()).trim();
				if(account.equals(null)||account.equals("")){
					JOptionPane.showMessageDialog(LoginFrame.this, "�������˺�!");
					return;
				}
				if(psd.equals(null)||psd.equals("")){
					JOptionPane.showMessageDialog(LoginFrame.this, "����������!");
					return;
				}
				
				if(client.connect()){
					ClientLoginMsg msg = new ClientLoginMsg(account,psd);
					//����Ϣ���͸�������
					 client.sendMsg(msg);
				
				}else{
					JOptionPane.showMessageDialog(null, "����������ʧ��");
				}
			};
		});
		loginB.setIcon(icon2);
		northP.add(loginB);
		
		java.net.URL url3=LoginFrame.class.getResource("/Img/regi.png");
		ImageIcon icon3 = new ImageIcon(url3);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		northP.add(horizontalStrut);
		
		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		northP.add(horizontalStrut_1);
		JLabel registB = new JLabel();
		registB.setIcon(icon3);
		registB.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		
		//ע��
		registB.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
				reg = new RegFrame();
				setVisible(false);
				reg.setVisible(true);
					
			}
		});
		northP.add(registB);
		
		
	

		conter = new MyJpanel("back_4.jpg");
		getContentPane().add(conter, BorderLayout.CENTER);
		conter.setLayout(null);
		
		accountF = new JTextFieldUser();
		accountF.setOpaque(false);
		accountF.setFont(new Font("����", Font.BOLD, 16));
		accountF.setBounds(97, 77, 211, 29);
		conter.add(accountF);
		accountF.setColumns(10);
		
		passwordF = new JTextFieldPassword();
		passwordF.setBounds(97, 135, 211, 29);
		passwordF.setForeground(Color.white);
		passwordF.setOpaque(false);
		conter.add(passwordF);
		
		client=new Client(this);
		client.setInlogin(this);
		
	}
	
	public static void main(String[] args) {
		  try {
			UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
          JFrame.setDefaultLookAndFeelDecorated(true);
          JDialog.setDefaultLookAndFeelDecorated(true);
         SubstanceLookAndFeel.setCurrentTheme(new SubstanceTerracottaTheme());
       // SubstanceLookAndFeel.setSkin(new EmeraldDuskSkin());
         
        SubstanceLookAndFeel.setCurrentButtonShaper(new ClassicButtonShaper());
        SubstanceLookAndFeel.setCurrentWatermark(new SubstanceBubblesWatermark());
        SubstanceLookAndFeel.setCurrentBorderPainter(new StandardBorderPainter());
        SubstanceLookAndFeel.setCurrentGradientPainter(new StandardGradientPainter());
       //   SubstanceLookAndFeel.setCurrentTitlePainter(new FlatTitePainter());

	       new  LoginFrame().setVisible(true);  
	}
	@Override
	public void informSuc(String username) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null,username+"��¼�ɹ�");
        this.setVisible(false);
        
        user=new User(username,passwordF.getText(),0);
        //������Ϸ����	
        hall=new HallFrame();
        hall.setVisible(true);
        
	}
	@Override
	public void informFail() {
		// TODO Auto-generated method stub
		 JOptionPane.showMessageDialog(LoginFrame.this, "�û������������!");
	}
	
	@Override
	public void exist() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(LoginFrame.this, "�����ظ���¼!");
	}
}
