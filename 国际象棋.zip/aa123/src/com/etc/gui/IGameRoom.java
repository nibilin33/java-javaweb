package com.etc.gui;

import java.util.List;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.Room;
import com.etc.entity.User;

public interface IGameRoom {
	void showUserList(List<String> userList);
	void showRoomList(List<Room>  roomList);
	void showTalkList(String test);
	void showBroadInfo(String message);
	void showChessRoom(Room room);
	void showWatchRoom(ChessBoard board,ChessMan man,int id);
	//void repaint();
}
