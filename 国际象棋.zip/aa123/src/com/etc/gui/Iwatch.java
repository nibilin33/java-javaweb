package com.etc.gui;

import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;

public interface Iwatch {
   public void watchrun(int id);
   public void repaiting(ChessBoard board,ChessMan man);
}
