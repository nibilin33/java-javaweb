package com.etc.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;

import com.etc.data.BroadCastMsg;
import com.etc.data.ExitGameRoomMsg;
import com.etc.data.OpenRoomMsg;
import com.etc.data.WatchMsg;
import com.etc.data.WatchMsg2;
import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.Room;
import com.etc.entity.User;
import com.etc.util.JDBC;
import com.etc.util.MyJScrollPane;
import com.etc.util.MyJpanel;
import com.net.Client;

public class HallFrame extends JFrame implements IGameRoom{

	private  JTable table;
	private   Vector<Vector<String>> tableV;
	private static Vector<String> tableC;
	private MyJScrollPane scrollPane;

	private JTextArea textArea_1;//��ʾ����
	private List<String> list ;
	private List<Room> rlist;
	private List<User>listuser;
	private MyJpanel center,north,east;
	private MyJpanel[] panel;
	private JPanel  contentJPanel;
	
	
	private User ur;//��������޸�
	private JTextField MessF; //���������
	private WatchFrame watch;
	
	
	public HallFrame(){
		
panel = new MyJpanel[6];
		LoginFrame.getClient().setIgameroom(this);
		setVisible(true);
		setTitle("��Ϸ����");
		setResizable(false);
		setBounds(250, 100, 969, 466);
		java.net.URL url=LoginFrame.class.getResource("/Img/1.jpg");
		Image icon=Toolkit.getDefaultToolkit().getImage(url);
		setIconImage(icon);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		contentJPanel = new JPanel();
		setContentPane(contentJPanel);
		contentJPanel.setLayout(new BorderLayout());
		
		north = new MyJpanel("hallback2_1.jpg");
		north.setOpaque(false);
		getContentPane().add(north, BorderLayout.NORTH);
		east = new MyJpanel("hallback1.png");
		east.setOpaque(false);
		east.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		getContentPane().add(east, BorderLayout.EAST);
		east.setLayout(new BorderLayout(0, 0));
		JLabel title = new JLabel("    ��        ��       ��   ",SwingConstants.CENTER);
		title.setForeground(Color.WHITE);
		title.setFont(new Font("�����п�", Font.BOLD, 23));
		east.add(title,BorderLayout.NORTH);
		
		JPanel east_center = new JPanel();
		east_center.setOpaque(false);
		east.add(east_center, BorderLayout.CENTER);
		east_center.setLayout(null);
		
		scrollPane = new MyJScrollPane("hallback2_1.jpg");
		scrollPane.getViewport().setOpaque(false);
		scrollPane.setBounds(10, 10, 204, 170);
		east_center.add(scrollPane);
		
		
		tableV = new Vector<Vector<String>>();
		tableC = new Vector<String>();
		tableC.add("����");
	  	tableC.add("�ǳ�");
	  	tableC.add("����");
		table = new JTable(tableV,tableC);
		table.setEnabled(false);
		table.setShowVerticalLines(false);
		table.setShowGrid(false);
//		table.setDefaultRenderer(Object.class, new TableCellTextAreaRenderer());
		table .getTableHeader().setReorderingAllowed(false);
	  	table.setPreferredScrollableViewportSize(new Dimension(300, 30));	  	
	  	scrollPane.add(table);
	  	scrollPane.setViewportView(table);
		MyJScrollPane scrollPane_1 = new MyJScrollPane("hallback2_1.jpg");
		scrollPane_1.setBounds(10, 190, 204, 150);
		scrollPane_1.getViewport().setOpaque(false);
		east_center.add(scrollPane_1);
		 
		
		textArea_1 = new JTextArea();

        textArea_1.setForeground(Color.WHITE);
		textArea_1.setFont(new Font("����", Font.PLAIN, 16));
		textArea_1.setEnabled(false);
		textArea_1.setOpaque(false);
		scrollPane_1.setViewportView(textArea_1);
		
    
		
		MessF = new JTextField();
		MessF.setBounds(10, 340, 143, 32);
		east_center.add(MessF);
		MessF.setColumns(10);
		MessF.setOpaque(false);
		MessF.setForeground(Color.WHITE);
		MessF.setFont(new Font("����", Font.PLAIN, 14));

		JLabel sendL = new JLabel();
		URL sendurl = HallFrame.class.getResource("/Img/send_1.jpg");
		ImageIcon sendicon = new ImageIcon(sendurl);
		sendL.setIcon(sendicon);
		sendL.setCursor(new Cursor(Cursor.HAND_CURSOR));
		sendL.setBounds(163, 340, 50, 44);
		east_center.add(sendL);
		
		
		//Ⱥ����Ϣ
		sendL.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
				
				String mess = MessF.getText().trim();
				//�����ݲŷ���
				if(!mess.equals(null)&&!mess.equals("")){
					mess = textArea_1.getText()+ mess;
					BroadCastMsg msg = new BroadCastMsg(mess);
					LoginFrame.getClient().sendMsg(msg);
                    
				}	
				textArea_1.setText("");
			}
		});
		
		
		center = new MyJpanel("hallback2_1.jpg");
		center.setOpaque(false);
		getContentPane().add(center, BorderLayout.CENTER);
		center.setLayout(new GridLayout(2, 3, 5, 5));
//		showRoom();
//		setRank();
		
		
		
	}
	
	//��ʾ�����û�
	public void setRank(){
		int x = 0;
		int rank = 1;
		JDBC jdbc = new JDBC();
		listuser = jdbc.getUserList(list);
		int num = table.getRowCount();
//		for(int y=0;y<num;y++){
//			table.remove(y);
//		}
//		System.out.println(table.getRowCount()+"xxxxxxxxxx");
		DefaultTableModel model=(DefaultTableModel)table.getModel();
		model.setRowCount(0);
		
		for(int i=0;listuser.size()!=0;i++){
			for(int j = 1;j<listuser.size();j++){
				if(listuser.get(x).getScore()<listuser.get(j).getScore())
					x = j ;
			}
			Vector<String> rowV = new Vector<String>();
			rowV.add(""+rank);
			rowV.add(listuser.get(x).getName());
			rowV.add(""+listuser.get(x).getScore());
			tableV.add(rowV);
			listuser.remove(x);
			x = 0;
			rank++;
		}
	//	table.repaint();
	//	table.repaint();
	}

	
	//�������
	public void Log(){
		textArea_1.setText("");
	}
	
	//��ʾ����
	public void showRoom(){
         center.removeAll();
		
		for(int i=0;i<rlist.size();i++){
			Room r = rlist.get(i);
			panel[i] = new MyJpanel("90.png");
			panel[i].setLayout(null);
			panel[i].setOpaque(false);
			panel[i].setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			JLabel jl = new JLabel();
			jl.setBounds(8, 100, 100, 100);
			jl.setFont(new Font("��Բ", Font.BOLD, 16));
			JLabel jr = new JLabel();
			jr.setFont(new Font("��Բ", Font.BOLD, 16));
			jr.setBounds(160,100,100,100);
			panel[i].add(jr);
			panel[i].add(jl);
			if(r.getLeft()!=null)
				jl.setText(r.getLeft());
			if(r.getRight()!=null)
				jr.setText(r.getRight());
		    	center.add(panel[i]);
		}
		HallFrame.this.validate();
		tableAction();
	}
	//��������¼�
	public void tableAction(){
		for(int i=0; i<panel.length;i++){
			final int x = i;
			panel[i].addMouseListener(new MouseListener() {
				
				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					//�˶δ����ɷ�����д
					JDBC jdbc = new JDBC();
					int flag = jdbc.isinroom(LoginFrame.getUser().getName());
					if(flag == 0){
						if(rlist.get(x).getRight()==null||rlist.get(x).getRight()==null){
							OpenRoomMsg or=new OpenRoomMsg(x,LoginFrame.getUser().getName());
							LoginFrame.getClient().sendMsg(or);
						}else{
						//	WatchMsg msg = new 
							WatchMsg2 msg = new WatchMsg2(x,LoginFrame.getUser().getName());
							LoginFrame.getClient().sendMsg(msg);
						}
						
					}else{
						JOptionPane.showMessageDialog(HallFrame.this, "�����ظ����뷿��");
					}
				}

			});
		}
	}
  public void click(){//�뿪����
	 // LoginFrame.getClient().connect();
  }
	@Override
	public void showBroadInfo(String message) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, message);
	}

	@Override
	public void showRoomList(List<Room> roomList) {
		// TODO Auto-generated method stub
//		if(rlist.get(x).getLeft()==null){
//		rlist.get(x).setLeft(ur);
//	       showRoom();
//	
//	}else if(rlist.get(x).getRight()==null){
//		rlist.get(x).setRight(ur);
//	 	   showRoom();
//	}
//	else{
//		int flag = JOptionPane.showConfirmDialog(HallFrame.this, "�����������Ƿ�����ս��");
//		if(flag==JOptionPane.OK_OPTION){
//			
//		}
//	}
		rlist=roomList;
		showRoom();
	}

	@Override
	public void showTalkList(String test) {
		// TODO Auto-generated method stub
		textArea_1.setText(test+"\n");
	}

	@Override
	public void showUserList(List<String> userList) {
		// TODO Auto-generated method stub
		list=userList;
		 setRank();
	}

	@Override
	public void showChessRoom(Room room) {
		// TODO Auto-generated method stub
		//this.setVisible(false);
		String color="";
        	 if(room.getGamestate()==1){
        		 color="black";
        	 }
        	 if(room.getGamestate()==2){
        		 color="white";
        	 }
        	 System.out.println(color);
        RoomTryTwo two=new RoomTryTwo(color,room);
         two.setVisible(true);
        
	}
	
	@Override
	protected void processWindowEvent(WindowEvent e) {
		// TODO Auto-generated method stub
		if(e.getID() == WindowEvent.WINDOW_CLOSED){
			ExitGameRoomMsg msg=new ExitGameRoomMsg(LoginFrame.getClient().getSocket());
			LoginFrame.getClient().sendMsg(msg);
			JDBC jdbc  = new JDBC();
			jdbc.logout(LoginFrame.getUser().getName());
	//		dispose();
		}else{
			super.processWindowEvent(e);
		}
		
	}

	

	@Override
	public void showWatchRoom(ChessBoard board,ChessMan man,int id) {
		// TODO Auto-generated method stub
		//��ʾ�ۿ�ģʽ
//		System.out.println(id);
		watch=new WatchFrame();
		LoginFrame.getClient().watchconnect();//��������
		watch.setVisible(true);
		
         
	}
	
	
	
}
