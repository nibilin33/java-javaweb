package com.net;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.JFrame;
import com.etc.data.BasicMsg;
import com.etc.entity.PaintCheeteMap;
import com.etc.gui.GameInform;
import com.etc.gui.IChessRoom;
import com.etc.gui.IGameRoom;
import com.etc.gui.Infologin;
import com.etc.gui.Iregister;
import com.etc.gui.Iwatch;

public class Client{
	private GameInform popinform;
	private Infologin inlogin;
	private IGameRoom igameroom;
	private JFrame frame;
	private Iregister iregister;
	private IChessRoom ichessroom;
	private PaintCheeteMap cheessmap;
	private Iwatch iwatch;
	public Iwatch getIwatch() {
		return iwatch;
	}
	public void setIwatch(Iwatch iwatch) {
		this.iwatch = iwatch;
	}
	public PaintCheeteMap getCheessmap() {
		return cheessmap;
	}
	public void setCheessmap(PaintCheeteMap cheessmap) {
		this.cheessmap = cheessmap;
	}
	public IChessRoom getIchessroom() {
		return ichessroom;
	}
	public void setIchessroom(IChessRoom ichessroom) {
		this.ichessroom = ichessroom;
	}
	public Iregister getIregister() {
		return iregister;
	}
	public void setIregister(Iregister iregister) {
		this.iregister = iregister;
	}
	private boolean isconnected;
	private Socket socket;
	private Socket watch;
	  public Client(JFrame frame) {
			super();
			this.frame = frame;
		}
	public boolean connect(){
		try {
			socket=new Socket("127.0.0.1",1245);
			isconnected=true;
			new ServerReciveThread(socket).start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
		   isconnected=false;
		}
		
		return isconnected;
	}
   public boolean watchconnect(){
	   try {
			socket=new Socket("127.0.0.1",1222);
			new WatchRecieveThread(socket).start();
			return true;
	   }catch (Exception e) {
		// TODO: handle exception
		   return false;
	}
   }
	public Socket getWatch() {
	return watch;
}
public void setWatch(Socket watch) {
	this.watch = watch;
}
	public boolean closeConnect(){
		try {
			socket.close();
			isconnected=true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			isconnected=false;
		}
		return isconnected;
	}
	// �����ķ��͸�������
    public void sendMsg(BasicMsg msg){
    	if(!this.isconnected){
    		System.out.println(isconnected);
    		//��ӡ����������壬������Ϣʧ�ܣ�����������ʧ��
    		return;
    	}
    	try {
    		ObjectOutputStream os=new ObjectOutputStream(socket.getOutputStream());
    		msg.setClient(this.socket);
    		os.writeObject(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			isconnected=false;
			//��ӡ����������壬������Ϣʧ�ܣ�����������ʧ��
			try {
			//	Log.log(ServerRoom.getLogText(),this.socket.getInetAddress().toString()+"����ʧ��");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
    }
	public IGameRoom getIgameroom() {
		return igameroom;
	}
	public void setIgameroom(IGameRoom igameroom) {
		this.igameroom = igameroom;
	}
    public GameInform getPopinform() {
		return popinform;
	}
	public void setPopinform(GameInform popinform) {
		this.popinform = popinform;
	}
	public Infologin getInlogin() {
		return inlogin;
	}
	public void setInlogin(Infologin inlogin) {
		this.inlogin = inlogin;
	}
	public JFrame getFrame() {
		return frame;
	}
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	public boolean isIsconnected() {
		return isconnected;
	}
	public void setIsconnected(boolean isconnected) {
		this.isconnected = isconnected;
	}
	public Socket getSocket() {
		return socket;
	}
	public void setSocket(Socket socket) {
		this.socket = socket;
	}
	class WatchRecieveThread extends Thread{
		private Socket s;

		public WatchRecieveThread(Socket s) {
			super();
			this.s = s;
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				while(true){
				ObjectInputStream oi=new ObjectInputStream(this.s.getInputStream());
				BasicMsg msg=(BasicMsg)oi.readObject();
     			msg.setClient(this.s);
     			System.out.println("�ͻ��ۿ�"+msg);
				msg.doBiz();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//�������Ͽ����ӣ���ӡ���
			e.printStackTrace();
			}
		}
	}
    class ServerReciveThread extends Thread{
    	private Socket socket;
    	public ServerReciveThread(Socket socket) {
			super();
			this.socket = socket;
		}
		@Override
    	public void run() {//�������Է���������Ϣ
    		// TODO Auto-generated method stub
			try {
				while(true){
				ObjectInputStream oi=new ObjectInputStream(socket.getInputStream());
				BasicMsg msg=(BasicMsg)oi.readObject();
     			msg.setClient(this.socket);
     			System.out.println("�ͻ��˽���"+msg);
				msg.doBiz();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//�������Ͽ����ӣ���ӡ���
			e.printStackTrace();
				
				try {
		//	Log.log(ServerRoom.getLogText(),this.socket.getInetAddress().toString()+"����ʧ��");
				} catch (Exception e1) {
					// TODO Auto-generated catch blockr
					e.printStackTrace();
				  return;
				}
				
			}
    
    	}
    }

}
