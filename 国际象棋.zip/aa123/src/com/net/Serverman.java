package com.net;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

import com.etc.data.BasicMsg;
import com.etc.data.BroadMsg;
import com.etc.data.ServerEatChess;
import com.etc.data.ServerRask;
import com.etc.data.ServerRwin;
import com.etc.data.ServerWinGame;
import com.etc.entity.ChessBoard;
import com.etc.entity.ChessMan;
import com.etc.entity.Move;
import com.etc.entity.Room;
import com.etc.entity.Rule;
import com.etc.entity.User;
import com.etc.gui.ServerRoom;
import com.etc.util.JDBC;
import com.etc.util.Log;
import com.net.Client.WatchRecieveThread;

public class Serverman {
	private ServerRoom seform;
	private boolean isstarted=false;
    private ServerSocket server;
    private ServerSocket watcher;
    public static ArrayList<CWathcThread> getWatch() {
		return watch;
	}
	public static void setWatch(ArrayList<CWathcThread> watch) {
		Serverman.watch = watch;
	}
	private boolean iswatch=false;
    private static ArrayList<ClientThread> pool=new ArrayList<ClientThread>();//�ͻ��̳߳�
    private static ArrayList<WaitForConnectThread> con=new ArrayList<WaitForConnectThread>();//�ȴ��ͻ������̳߳�
    private static ArrayList<Room>room=new ArrayList<Room>();
    private static ArrayList<CWathcThread>watch=new ArrayList<CWathcThread>();
    public  ArrayList<Room> getRoom() {
		return room;
	}
	public static void setRoom(ArrayList<Room> room) {
		Serverman.room = room;
	}
	public Serverman(ServerRoom serverFrame) {
		// TODO Auto-generated constructor stub
    	 seform=serverFrame;
    	 resetRooms();//������������ʼ����������
	}
	public void sendwatch(int roomid){
	
		  Socket ac;
		try {
			ac = ServerRoom.getMyservice().getWatcher().accept();
			CWathcThread t=new CWathcThread(roomid,ac);
			t.start();
			watch.add(t);
			System.out.println("�������ˣ�����");
			new CWriteThread().start();
//			while(){
//				for(CWathcThread c:watch){
//		   ObjectInputStream in=new ObjectInputStream(ac.getInputStream());
//	     	BasicMsg bm=(BasicMsg)in.readObject();
//		    bm.doBiz();
//				}
//			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	

	}
	public void sendRoomMsg(BasicMsg bm,int roomid){
		System.out.println(roomid);
		if(isstarted){
			  for(ClientThread ct:pool){
				  Room rm=room.get(roomid);
				  if(ct.getUsername().equals(rm.getLeft())||ct.getUsername().equals(rm.getRight())){
					 // System.out.println(rm.getGamestate()+"ggggg");
				  try {
					ObjectOutputStream ot=new ObjectOutputStream(ct.getClient().getOutputStream());
					ot.writeObject(bm);	
				} catch (IOException e) {
					// TODO Auto-generated catch block
					//��¼�ĸ�����ʧ��
					e.printStackTrace();
				    Log.log(seform.LogText,ct.getName()+"����ʧ��");
				}
				}
			  }
			  }else{
			  Log.log(seform.LogText,bm+"����ʧ�ܣ��뿪������");
			  }
	}
	public void movechess(String target,int roomid,ChessBoard chessboard,ChessMan chessman){
		//System.out.println(target+"sssssssssss");
		Room rm=room.get(roomid);
		rm.setChessboard(chessboard);
		rm.setChessman(chessman);
		ChessBoard ch=rm.getChessboard();
		ChessMan cm=rm.getChessman();
		Move move=new Move(cm,ch);
		System.out.println("����serMan:"+cm.getSelect().length+",target:"+target);
		move.����(target);
		if(move.getRule().win()){
			ServerWinGame sw=new ServerWinGame(cm.getColor());
			sendRoomMsg(sw, roomid);
		}
		cm.setSelect(null);
		ch=move.getBoard();
	    cm=move.getMan();
	    Move moves=new Move(cm, ch);
		move.changeCamp(cm.getColor());
	    rm.setChessboard(ch);
	    rm.setChessman(cm);	
	    rm.setMove(moves);
	    room.set(roomid, rm);
	}
	public void eatchess(int i , String[] oldChess, String chessName , String num,int roomid,ChessBoard chessboard,ChessMan man,User user){
		Room rm=room.get(roomid);
		rm.setChessboard(chessboard);
		rm.setChessman(man);
		ChessBoard ch=rm.getChessboard();
		ChessMan cm=rm.getChessman();
		Move move=new Move(cm,ch);
		Rule rule = new Rule(cm, ch);
	    move.����(i, oldChess, chessName, num);
	    System.out.println("serverman_isMin:"+ch.isWin()+"��ǰ��Ӫ"+man.getColor());
	    if(ch.isWin()){
	    	ServerRwin rw=new ServerRwin(cm.getColor());
	        Room r=room.get(roomid);
	        JDBC jbc=new JDBC();
	        user.setScore(user.getScore()+2);
	        jbc.addScore(user);
	    	sendRoomMsg(rw, roomid);
	    	cm.setTie();
	    	ch.resetAllBoolena();
//	        Move moves=new Move(cm, ch);
//	    	ServerEatChess ec=new ServerEatChess(ch, cm, num, rule, moves);
//	    	sendRoomMsg(ec, roomid);
	    }else{
		    cm.setSelect(null);
		    ch=move.getBoard();
		    cm=move.getMan();
		    Move moves=new Move(cm, ch);
		    move.changeCamp(cm.getColor());
		    rm.setChessboard(ch);
		    rm.setChessman(cm);	
		    rm.setMove(moves);
	    }
	    room.set(roomid, rm);
	}
	public void changeRoom(Room rm){
		room.set(rm.getId(), rm);
		//room.set(rm.getId(),)
	}
//	public Socket getRoomSocket(int id){
//	        Socket wanted=null;
//	        for(Room r:room){
//	        	if(r.getId()==id){
//	        		
//	        	}
//	        }
//	        return wanted;
//	}
    public List<String> getUserlist(){//���������û�
		List<String> list = new ArrayList<String>();
		for(ClientThread ct : pool){
			
			list.add(ct.getUsername());
		}
		return list;
	}
    private void resetRooms(){//��ʼ����������
		room.clear();
		for(int i=0;i<6;i++){
			Room r = new Room(i,null,null,0);//������ÿһ�����������
			room.add(r);
		}
	}
  public void removeThread(Socket socket){//�˳������Ƴ��ͻ�
	  for(ClientThread ct:pool){
		  if(ct.getClient().equals(socket)){
			  pool.remove(ct);
		  }
	  }
	  
  }
  public void removeWatch(Socket other){
	  for(CWathcThread c:watch){
		  System.out.println(other+"�Ƴ�����������������");
		  synchronized (Serverman.watch) {
			if (c.client.equals(other)) {
				c.iswatch = false;
				watch.remove(c);
			}
		}
	  }
	  
  }
  public boolean watchstarted(){
	  try{
		  watcher=new ServerSocket(1222);
		  return true;
	  }catch(Exception  e){
		  return false;
	  }
  }
  public ServerSocket getWatcher() {
	return watcher;
}
public void setWatcher(ServerSocket watcher) {
	this.watcher = watcher;
}
public boolean isstarted(int port){
	  try {
		server=new ServerSocket(port);
		setIsstarted(true);
		new WaitForConnectThread().start();
		return true;
	} catch (IOException e) {
		// TODO Auto-generated catch block
	    setIsstarted(false);
		return false;
	}
  }
  
  public void sendToClientMul(BasicMsg msg){//Ⱥ��
	  if(isstarted){
		  for(ClientThread ct:pool){
			  try {
				ObjectOutputStream ot=new ObjectOutputStream(ct.getClient().getOutputStream());
				ot.writeObject(msg);	
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//��¼�ĸ�����ʧ��
			    Log.log(seform.LogText,ct.getName()+"����ʧ��");
			}
			}
		  }else{
		  Log.log(seform.LogText,msg+"����ʧ�ܣ��뿪������");
		  }
	  
  }
   public void getroominfo(){
	   while(true){
			//ObjectOutputStream ot = new ObjectOutputStream(ct.getClient()
			//		.getOutputStream());
			//ServerOpenWatch broad = new ServerOpenWatch(message);
			//ot.writeObject(broad);
	   }
   }
  public void sendAll(){//�������㲥
	  String message=seform.BroadCast.getText();
	  if(isstarted){
	  for(ClientThread ct:pool){
		  try {
			ObjectOutputStream ot=new ObjectOutputStream(ct.getClient().getOutputStream());
			BroadMsg broad=new BroadMsg(message);
			ot.writeObject(broad);	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//��¼�ĸ�����ʧ��
		    Log.log(seform.LogText,ct.getName()+"����ʧ��");
		}
		}
	  }else{
	  Log.log(seform.LogText,message+"����ʧ�ܣ��뿪������");
	  }
  }
  public boolean isstop(){
	  
	  if (server == null) {
			return true;
		}
	     try {
			server.close();
			setIsstarted(false);
			 resetRooms();
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
	           return false;
		}
  }
  public void sendMsg(BasicMsg msg ,Socket other){//���͵�ָ���ͻ���
	  if(other.isConnected()){
	  try {
			ObjectOutputStream out=new ObjectOutputStream(other.getOutputStream());
			out.writeObject(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	  }else{
		  
		  //����ʧ�ܣ���־��¼
			Log.log(seform.LogText, "����ʧ�ܣ�" +other+"�Ͽ�����");
		  
	  }
		  
} 
  class CWriteThread extends Thread{//����������������Ŀͻ��˷������ݰ�ˢ��ҳ��
	  @Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
		for(CWathcThread c:watch){
			Room rm=room.get(c.roomid);
			if(c.iswatch){
			try {
				ObjectOutputStream ot=new ObjectOutputStream(c.client.getOutputStream());
				ServerRask ask=new ServerRask(rm.getChessboard(),rm.getChessman());
				ot.writeObject(ask);
				Thread.sleep(4000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
		}
	}
  }
  class CWathcThread extends Thread{
	  private int roomid;
	  private Socket client;
	  private boolean iswatch=true;
	
	  public boolean isIswatch() {
		return iswatch;
	}

	public void setIswatch(boolean iswatch) {
		this.iswatch = iswatch;
	}

	public CWathcThread(int roomid, Socket client) {
		super();
		this.roomid = roomid;
		this.client = client;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
			try {
				while(true){
				ObjectInputStream oi=new ObjectInputStream(client.getInputStream());
				BasicMsg msg=(BasicMsg)oi.readObject();
				Log.log(seform.LogText, "�ͻ�����ۿ���" + msg);
				System.out.println("����������"+msg);
				msg.setClient(client);//����ñ��Ķ�Ӧ�Ŀͻ���
				msg.doBiz();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
				Log.log(seform.LogText, "�ͻ������ӣ�" + client+"�Ͽ�����");
				synchronized (Serverman.pool) {
					Serverman.pool.remove(this);
					Log.log(seform.LogText, "��ǰ�ͻ�����������Ϊ��" + Serverman.pool.size());
				}

			}
	
	}
  }
  class ClientThread extends Thread{
	  private String username;
	  private Socket client;
	public ClientThread(Socket client) {
		super();
		this.client = client;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Socket getClient() {
		return client;
	}
	public void setClient(Socket client) {
		this.client = client;
	}
	@Override
	public void run() {//�����ӿͻ��˽��յ���Ϣ
		// TODO Auto-generated method stub
		try {
			while(true){
			ObjectInputStream oi=new ObjectInputStream(client.getInputStream());
			BasicMsg msg=(BasicMsg)oi.readObject();
			Log.log(seform.LogText, "�ͻ������ӣ�" + msg);
			System.out.println("f����������"+msg);
			msg.setClient(client);//����ñ��Ķ�Ӧ�Ŀͻ���
			msg.doBiz();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
			Log.log(seform.LogText, "�ͻ������ӣ�" + client+"�Ͽ�����");
			synchronized (Serverman.pool) {
				Serverman.pool.remove(this);
				Log.log(seform.LogText, "��ǰ�ͻ�����������Ϊ��" + Serverman.pool.size());
			}

		}
	}
	  
  }
//���û����󶨵��̳߳��еĶ�Ӧ�߳�
	public void lockUsername(String username,Socket client){
		//�����ͻ��˶�Ӧ���̳߳أ��ҵ���Ӧ�Ŀͻ���
		for(ClientThread ct:pool){
			if(ct.getClient()==client){
				ct.setUsername(username);
				return;
			}
		}
	}

  class WaitForConnectThread extends Thread{
	  @Override
	public void run() {
		// TODO Auto-generated method stub
		  
			  try {
				  while(true){
				Socket client=server.accept();
				String msg=client.getInetAddress()+"���ӷ�����";
				Log.log(seform.LogText, msg);
				ClientThread ct=new ClientThread(client);
				ct.start();
				pool.add(ct);
				  }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
		  }
		
	}
  }
  
  public JFrame getSeform() {
		return seform;
	}
	public void setSeform(ServerRoom seform) {
		this.seform =seform;
	}
	public boolean isIsstarted() {
		return isstarted;
	}
	public void setIsstarted(boolean isstarted) {
		this.isstarted = isstarted;
	}
	public ServerSocket getServer() {
		return server;
	}
	public void setServer(ServerSocket server) {
		this.server = server;
	}
	public ArrayList<ClientThread> getPool() {
		return pool;
	}
	public void setPool(ArrayList<ClientThread> pool) {
		this.pool = pool;
	}  
     
}
