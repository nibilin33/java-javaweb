function search(){
	 
//	var sqlmatch;
	
	var searchcondition={"StyleId":"","CatagoryId":"","BrandId":"","Sprice":-1, "Lprice":-1};
	var zho=document.getElementById(zh);//种类
	var index = zho.selectedIndex; // 选中索引
	var pai=document.getElementById(pai);//品牌
	var index1 = pai.selectedIndex; // 选中索引
	var st=document.getElementById(st);//风格
	var index2 = st.selectedIndex; // 选中索引
	var mo=document.getElementById(mo).value;//大
	var mo1=document.getElementById(mo1).value;//小
     
	if(index!=-1){
		var text = zho.options[index].text; // 选中文本
		searchcondition.StyleId=text;
		}
	if(index1!=-1){
	var text1 = pai.options[index].text; // 选中文本
	searchcondition.CatagoryId=text1;
	}
	if(index2!=-1){
		var text2 = st.options[index].text; // 选中文本
	searchcondition.BrandId=text2;
		}
   if(mo!=-1&&mo1!=-1){
	   if(mo<mo1){
		   var temp=mo;
		     mo=mo1;
		     mo1=temp;
	   }
	   searchcondition.Sprice=mo;
	   searchcondition.Lprice=mo1;
   }
   var strTem="";
   for(value in searchcondition){
	   strTem+=searchcondition[value]+',';
   }

	//sqlmatch="select * from light where ";
  
      alert(strTem);
		
		//return strTem;
}
