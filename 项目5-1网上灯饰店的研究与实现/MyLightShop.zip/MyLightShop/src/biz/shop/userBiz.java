package biz.shop;

import dao.shop.otherDao;
import dao.shop.userDao;
import entity.shop.User;

public class userBiz {
	public User Login(String loginId){
		User usr = null;
		userDao uu=new userDao();
		usr=uu.Login(loginId);
		return usr;
	}
	public int Register(User usr){
		userDao uu =new userDao();
		return uu.userAdd(usr);
	}
	public int changePsw(int id,String psw1,String psw2){
		userDao usr = new userDao();
		return usr.changePsw(id, psw1, psw2);
	}
	public int getTotable(String sql){
		userDao ot =new userDao();
		return ot.getTotalPage(sql);
	}
	
}
