package biz.shop;

import java.util.ArrayList;
import java.util.List;

import dao.shop.otherDao;
import entity.shop.Comments;
import entity.shop.MyShopCart;
import entity.shop.Orders;
import entity.shop.Statistics;
import entity.shop.WishList;

public class otherBiz {
public	int wishlistAdd(int lId,int uId,String data){
		otherDao ot =new otherDao();
		/*
		 * 1-->exist
		 * 0-->ok
		 * -1-->no
		 * 
		 * 
		 * */
		return ot.wishlistAdd(lId, uId, data);
	}
public	int wishlistDel(int wId){
		otherDao ot =new otherDao();
		/*
		 * 0-->ok
		 * -1-->no
		 * 
		 * 
		 * */
		return ot.wishlistDel(wId);
	}
public	List<WishList> queryWlistList(int id){
		otherDao ot =new otherDao();
		return ot.queryWish(id);
	}
	//���빺�ﳵ
	public int addCar(int lid,int uid,String data){
		otherDao ot =new otherDao();
		/*
		 * 1-->exist
		 * 0-->ok
		 * -1-->no
		 * */
		System.out.print("dwef");
		return ot.addCar(lid, uid, data);
	}
	//ɾ�����ﳵ
	public int carDel(int id){
		otherDao ot =new otherDao();
		/*
		 * 0-->ok
		 * -1-->no
		 * */
		return ot.carDel(id);
	}
	//��ѯ���ﳵ
	public List<MyShopCart> queryCar(int id){
		otherDao ot =new otherDao();
		return ot.queryCar(id);
	}
	public int deleteAllCar(int id){
		otherDao ot =new otherDao();
		/*
		 * 0-->ok
		 * -1-->no
		 * */
		return ot.deleteAllCar(id);
	}
//goumai
	public int addOrder(int lId, int uId, double price, int qua, String data){
		otherDao ot =new otherDao();
		/*
		 * 0-->ok
		 * -1-->no
		 * */
		return ot.addOrder(lId, uId, price, qua, data);
	}
	public int orderDelByoId(String id){
		otherDao ot =new otherDao();
		/*
		 * 1-->ok
		 * -1-->no
		 * */
		return ot.orderDelByoId(id);
	}
	public int orderDelByuId(int id){
		otherDao ot =new otherDao();
		/*
		 * 1-->ok
		 * -1-->no
		 * */
		return ot.orderDelByuId(id);
	}
	//�û���ѯ����δ�����˵�
	public List<Orders> queryOrderUu(int id){
		otherDao ot =new otherDao();
		return ot.querryOrdersUu(id);
	}
	public List<Orders> queryOrderUu(int id,int page){
		otherDao ot =new otherDao();
		return ot.querryOrdersUu(id,page);
	}
	//�û���ѯ�����Ѹ����˵�
	public List<Orders> queryOrderUo(int id){
		otherDao ot =new otherDao();
		return ot.querryOrdersUo(id);
	}
	//����Ա��ѯ���з�������
	public List<Orders> queryOrderMo(){
		otherDao ot =new otherDao();
		return ot.querryOrdersMo();
	}
	//����Ա��ѯ����δ��������
	public List<Orders> queryOrderMu(){
		otherDao ot =new otherDao();
		return ot.querryOrdersMu();
	}
	//���ﳵȥ����ǰ�ж������Ƿ����ı�
	public Orders updateOrder(String oId,int qua,String data){
		otherDao ot =new otherDao();
		return ot.updateOrder(oId, qua, data);
	}
	//�ύ����-->����
	public int changeOrdersStateU(Orders o){
		otherDao ot =new otherDao();
		/*
		 * 0-->ok
		 * -1-->failed
		 * 
		 * */
		return ot.changeOrdersStateU(o);
	}
	//����
	public int changeOrdersStateM(String id){
		otherDao ot =new otherDao();
		/*
		 * 0-->ok
		 * -1-->failed
		 * 
		 * */
		return ot.changeOrdersStateM(id);
	}
	//��õ���page
	public int getTotable(String sql){
		otherDao ot =new otherDao();
		return ot.getTotalPage(sql);
	}
	//��õ������������
		public Statistics getStatistics(int lId){
			otherDao ot =new otherDao();
			return ot.getStatistics(lId);
		}
	//lightId
	public List<Comments> queryComments(int id){
		otherDao ot =new otherDao();
		return ot.queryComment(id);
	}
	//�Ƿ����ʸ�����
	public int isBuy(int lId,int uId){
		otherDao ot =new otherDao();
		/*
		 * 0-->ok
		 * 1-->no
		 * 
		 * 
		 * */
		return ot.isBuy(lId, uId);
	}
}
