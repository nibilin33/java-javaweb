package biz.shop;
import java.util.ArrayList;
import java.util.List;

import dao.shop.lightDao;
import entity.shop.Brand;
import entity.shop.Catagory;
import entity.shop.Light;
import entity.shop.Style;

public class lightBiz {
	public  int getTotalPage(String sql){
		lightDao li = new lightDao();
		return li.getTotalPage(10, sql);
	}
	public Brand getBrand(int id){
		lightDao li = new lightDao();
		return li.getBrand(id);
	}
	public Style GetStyle(int id){
		lightDao li = new lightDao();
		return li.getStyle(id);
	}
	public Catagory getCatagory(int id){
		lightDao li = new lightDao();
		return li.getCatagory(id);
	}

	public List<Light> showAll(String sql, int page){
		lightDao li =new lightDao();
		//���С���ϡ��������������������sql�����Serlvet����
		//��û ����
		return li.quary(sql);
	}
     
	public List<Light>showsimple(int id,String type,int cupage){
		String sql="";
		int start=(cupage-1)*3;
		System.out.println(start);
		if("0".equals(type)){
			sql = "select * from light where CatagoryId ='"+id+"'limit "+start+",3";
		}else if("1".equals(type)){
			sql = "select * from light where BrandId = '"+id+"'limit "+start+",3";
		}else if("2".equals(type)){
			sql = "select * from light where StytleId = '"+id+"'limit "+start+",3";
		}
		lightDao lii=new lightDao();
		List<Light> light =new ArrayList<Light>();
		light = lii.quary(sql);
		return light;
			
		
	}
	public List<Brand> queryBrand(){
		List<Brand> brand = new ArrayList<Brand>();
		lightDao li = new lightDao();
		brand = li.queryBrand();
		return brand;
	}
	public int lightUpdate(Light light){
		lightDao li = new lightDao();
		return li.updateLight(light);
	}
	public Light getLightInfo(int id){
		lightDao li = new lightDao();
		return li.getLigntInfo(id);
	}
	public int delete(int id){
		lightDao li = new lightDao();
		return li.delete(id);
	}
	public int lightAdd(Light li){
		lightDao l = new lightDao();
		return l.lightAdd(li);
	}
}
