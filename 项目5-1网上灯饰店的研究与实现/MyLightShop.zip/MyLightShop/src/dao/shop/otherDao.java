package dao.shop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.shop.Comments;
import entity.shop.MyShopCart;
import entity.shop.Orders;
import entity.shop.Statistics;
import entity.shop.WishList;

public class otherDao {
	public static Connection conn;
	public void getconnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost/mylightshop", "root", "");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void addCount(int id,int flag){
		getconnection();
		String sql="";
		int countS=0,countC=0;
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement("select * from statistics where LightId='"+id+"'");
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				switch(flag){
				case 0:countC = rs.getInt(2)+1; 
						sql = "update statistics set Clicks = '"+countC+"' where LightId = '"+id+"'";
						break;
				case 1:countS = rs.getInt(3)+1;
						sql = "update statistics set StoreCount = '"+countS+"' where LightId = '"+id+"'";
						break;
				}
			}else{
				if(flag==0){
					countC = 1;
				}else
					countS = 1;
				sql = "insert into statistics (LightId,Clicks,StoreCount,SaleCount) values ('"+id+"',"
						+ "'"+countC+"','"+countS+"','"+0+"')";
			}
			PreparedStatement p = conn.prepareStatement(sql);
			p.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public List<WishList> queryWish(int uId){
		List wi = new ArrayList<WishList>();
		getconnection();
		String sql = "select * from wishlist where UserId = '"+uId+"';";
		try {
			PreparedStatement ps =conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next()){
				WishList l = new WishList();
				l.setWishListId(rs.getInt(1));
				l.setLightId(rs.getInt(2));
				l.setUserId(rs.getInt(3));
				l.setStoreDate(rs.getString(4));
				wi.add(l);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return wi;
	}
	public int IsWexit(int lId,int uId){
		getconnection();
		String sql = "select * from wishlist where UserId = '"+uId+"' and LightId = '"+lId+"'";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				return 1;
			}else
				return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	} 
	public int wishlistAdd(int lId ,int uId,String date){
		getconnection();
		addCount(lId,0);
		if(IsWexit(lId,uId)==1){
			return 1;
		}
		String sql = "insert into wishlist (LightId,UserId,StoreDate) values ('"+lId+"',"
				+ "'"+uId+"','"+date+"')";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				addCount(lId,1);
				return 0;
			}else{
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int wishlistDel(int id){
		getconnection();
		String sql = "delete from wishlist where WishListId = '"+id+"'";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}else{
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int isCexist(int lId,int uId){
		getconnection();
		String sql = "select * from myshopcart where LightId = '"+lId+"' and UserId = '"+uId+"'";
		try {
			PreparedStatement ps= conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			if(rs.next()){
				return 1;
			}else
				return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public int getTotalPage(String sql){
		getconnection();
		try {
			PreparedStatement statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			int count =0;
			if(rs.next()){
				count=rs.getInt(1);
				System.out.print(count);
			}
			if(count%3==0)
				return count/3;
			else
				return count/3+1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}

	public int addCar(int lId,int uId,String data){
		getconnection();
		addCount(lId, 0);
		if(isCexist(lId, uId)==1){
			return 1;
		}
		getconnection();
		String sql = "insert into myshopcart (LightId,UserId,AddDate) values("
				+ "'"+lId+"','"+uId+"','"+data+"')";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int carDel(int id){
		getconnection();
		String sql = "delete from myshopcart where ShopCardId = '"+id+"';";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public List<MyShopCart> queryCar(int id){
		List<MyShopCart> car = new ArrayList<MyShopCart>();
		String sql = "select * from myshopcart where UserId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				MyShopCart my = new MyShopCart();
				my.setShopCardId(rs.getInt(1));
				my.setLightId(rs.getInt(2));
				my.setUserId(rs.getInt(3));
				my.setAddDate(rs.getString(4));
				car.add(my);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return car;
	}
	public Orders isOrderExist(int uid, int lid){
		getconnection();
		Orders or =null;
		String sql = "select * from orders where LightId = '"+lid+"' and UserId = '"+uid+"' and OrderStateId = '"+0+"'";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				or = new Orders();
				or.setOrderId(rs.getString(1));
				or.setQuantity(rs.getInt(4));
				or.setTotaPrice(rs.getDouble(5));
				return or;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	public int deleteAllCar(int id){
		String sql = "delete from myshopcart where UserId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()>=1){
				return 0;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int addOrder(int lId, int uId, double price, int qua, String data){
		String sql;
		Orders or = isOrderExist(uId, lId);
		if(or!=null){
			int a = or.getQuantity()+qua;
			double b = or.getTotaPrice()+price*qua;
			sql = "update orders set Quantity = '"+a+"',TotaPrice = '"+b+"',Date = '"+data+"' where OrderId = '"+or.getOrderId()+"'";
		}else{
			double all = price*qua;
			String x = ""+System.currentTimeMillis();
			sql = "insert into orders (OrderId,UserId,LightId,Quantity,TotaPrice,Date,OrderStateId)"
					+ "values ('"+x+"','"+uId+"','"+lId+"','"+qua+"','"+all+"','"+data+"','"+0+"')";
		}
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int orderDelByoId(String id){
		String sql = "delete from orders where OrderId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 1;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int orderDelByuId(int id){
		String sql = "delete from orders where UserId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 1;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public List<Orders> querryOrdersUu(int id){
		List<Orders> or = new ArrayList<Orders>();
		String sql = "select * from orders where UserId = '"+id+"' and OrderStateId = '"+0+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Orders o = new Orders();
				o.setOrderId(rs.getString(1));
				o.setUserId(rs.getInt(2));
				o.setLightId(rs.getInt(3));
				o.setQuantity(rs.getInt(4));
				o.setTotaPrice(rs.getDouble(5));
				o.setDate(rs.getString(6));
				o.setReceiveName(rs.getString(9));
				o.setRecievePhone(rs.getString(10));
				o.setAddress(rs.getString(11));
				o.setEmail(rs.getString(12));
				o.setPostCode(rs.getString(13));
				o.setPostType(rs.getString(14));
				o.setPatmentType(rs.getString(15));
				o.setPostFree(rs.getInt(16));
				or.add(o);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	public List<Orders> querryOrdersUu(int id,int page){
		List<Orders> or = new ArrayList<Orders>();
		int start=(page-1)*3;
		String sql = "select * from orders where UserId = '"+id+"' and OrderStateId = '"+0+"' limit "+start+",3";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Orders o = new Orders();
				o.setOrderId(rs.getString(1));
				o.setUserId(rs.getInt(2));
				o.setLightId(rs.getInt(3));
				o.setQuantity(rs.getInt(4));
				o.setTotaPrice(rs.getDouble(5));
				o.setDate(rs.getString(6));
				o.setReceiveName(rs.getString(9));
				o.setRecievePhone(rs.getString(10));
				o.setAddress(rs.getString(11));
				o.setEmail(rs.getString(12));
				o.setPostCode(rs.getString(13));
				o.setPostType(rs.getString(14));
				o.setPatmentType(rs.getString(15));
				o.setPostFree(rs.getInt(16));
				or.add(o);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	public List<Orders> querryOrdersUo(int id){
		List<Orders> or = new ArrayList<Orders>();
		String sql = "select * from orders where UserId = '"+id+"' and OrderStateId = '"+1+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Orders o = new Orders();
				o.setOrderId(rs.getString(1));
				o.setUserId(rs.getInt(2));
				o.setLightId(rs.getInt(3));
				o.setQuantity(rs.getInt(4));
				o.setTotaPrice(rs.getDouble(5));
				o.setDate(rs.getString(6));
				o.setReceiveName(rs.getString(9));
				o.setRecievePhone(rs.getString(10));
				o.setAddress(rs.getString(11));
				o.setEmail(rs.getString(12));
				o.setPostCode(rs.getString(13));
				o.setPostType(rs.getString(14));
				o.setPatmentType(rs.getString(15));
				o.setPostFree(rs.getInt(16));
				or.add(o);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	public List<Orders> querryOrdersMu(){
		List<Orders> or = new ArrayList<Orders>();
		String sql = "select * from orders where OrderStateId = '"+1+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Orders o = new Orders();
				o.setOrderId(rs.getString(1));
				o.setUserId(rs.getInt(2));
				o.setLightId(rs.getInt(3));
				o.setQuantity(rs.getInt(4));
				o.setTotaPrice(rs.getDouble(5));
				o.setDate(rs.getString(6));
				o.setReceiveName(rs.getString(9));
				o.setRecievePhone(rs.getString(10));
				o.setAddress(rs.getString(11));
				o.setEmail(rs.getString(12));
				o.setPostCode(rs.getString(13));
				o.setPostType(rs.getString(14));
				o.setPatmentType(rs.getString(15));
				o.setPostFree(rs.getInt(16));
				or.add(o);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	public List<Orders> querryOrdersMu(String sql){
		List<Orders> or = new ArrayList<Orders>();
	
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Orders o = new Orders();
				o.setOrderId(rs.getString(1));
				o.setUserId(rs.getInt(2));
				o.setLightId(rs.getInt(3));
				o.setQuantity(rs.getInt(4));
				o.setTotaPrice(rs.getDouble(5));
				o.setDate(rs.getString(6));
				o.setReceiveName(rs.getString(9));
				o.setRecievePhone(rs.getString(10));
				o.setAddress(rs.getString(11));
				o.setEmail(rs.getString(12));
				o.setPostCode(rs.getString(13));
				o.setPostType(rs.getString(14));
				o.setPatmentType(rs.getString(15));
				o.setPostFree(rs.getInt(16));
				or.add(o);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	public List<Orders> querryOrdersMo(){
		List<Orders> or = new ArrayList<Orders>();
		String sql = "select * from orders where OrderStateId = '"+2+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Orders o = new Orders();
				o.setOrderId(rs.getString(1));
				o.setUserId(rs.getInt(2));
				o.setLightId(rs.getInt(3));
				o.setQuantity(rs.getInt(4));
				o.setTotaPrice(rs.getDouble(5));
				o.setDate(rs.getString(6));
				o.setReceiveName(rs.getString(9));
				o.setRecievePhone(rs.getString(10));
				o.setAddress(rs.getString(11));
				o.setEmail(rs.getString(12));
				o.setPostCode(rs.getString(13));
				o.setPostType(rs.getString(14));
				o.setPatmentType(rs.getString(15));
				o.setPostFree(rs.getInt(16));
				or.add(o);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	public Orders queryOrder(String id){
		Orders or = null;
		String sql = "select * from orders where OrderId ='"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				or = new Orders();
				or.setOrderId(rs.getString(1));
				or.setUserId(rs.getInt(2));
				or.setLightId(rs.getInt(3));
				or.setQuantity(rs.getInt(4));
				or.setTotaPrice(rs.getDouble(5));
				or.setDate(rs.getString(6));
				or.setReceiveName(rs.getString(9));
				or.setRecievePhone(rs.getString(10));
				or.setAddress(rs.getString(11));
				or.setEmail(rs.getString(12));
				or.setPostCode(rs.getString(13));
				or.setPostType(rs.getString(14));
				or.setPatmentType(rs.getString(15));
				or.setPostFree(rs.getInt(16));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return or;
	}
	//���ﳵȥ����ǰ�ж������Ƿ����ı�
	public Orders updateOrder(String oId,int qua,String data){
		Orders or = queryOrder(oId);
		if(or.getQuantity()==qua)
			return or;
		double all = (or.getTotaPrice()/or.getQuantity())*qua;
		String sql = "update orders set Quantity = '"+qua+"', TotaPrice = '"+all+"',Date = '"+data+"'"
				+ "where OrderId = '"+oId+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return  queryOrder(oId);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Statistics getStatistics(int id){
		Statistics s = null;
		String sql = "select * from statistics where LightId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				s = new Statistics();
				s.setLightId(rs.getInt(1));
				s.setClicks(rs.getInt(2));
				s.setStoreCount(rs.getInt(3));
				s.setSaleCount(rs.getInt(4));
				return s;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	public void addSale(int id,int count){
		Statistics s = getStatistics(id);
		int c = s.getSaleCount();
		int x = c +count;
		String sql = "update statistics set SaleCount = '"+x+"' where LightId = '"+id+"'";
		getconnection();
		try {
			System.out.print(x);
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//����
	public int changeOrdersStateU(Orders o){
		String sql = "update orders set OrderStateId = '"+1+"',"
				+ "ReceiveName = '"+o.getReceiveName()+"',ReceivePhone = '"+o.getRecievePhone()+"',"
						+ "Address = '"+o.getAddress()+"',Email='"+o.getEmail()+"',PostCode='"+o.getPostCode()+"'"
								+ ",PostType='"+o.getPostType()+"',PatmentType='"+o.getPatmentType()+"' where OrderId = '"+o.getOrderId()+"'";
		getconnection();
		try {
			PreparedStatement ps =conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				addSale(o.getLightId(), o.getQuantity());
				return 0;
			}
			else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	
	public int changeOrdersStateM(String id){
		String sql = "update orders set OrderStateId = '"+2+"' where OrderId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public List<Comments> queryComment(int id){
		List<Comments> co = new ArrayList<Comments>();
		String sql = "select * from comments where LightId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			while(rs.next()){
				Comments com = new Comments();
				com.setCommentId(rs.getInt(1));
				com.setLightId(rs.getInt(2));
				com.setUserId(rs.getInt(3));
				com.setComments(rs.getString(4));
				com.setDate(rs.getString(5));
				co.add(com);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return co;
	}
	public int isBuy(int lId,int uId){
		String sql = "select * from orders where LightId = '"+lId+"' and UserId = '"+uId+"' and OrderStateId = '"+3+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				return 0;
			}else
					return 1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public int addComments(Comments co){
		String sql = "insert into comments (LightId,UserId,Comments,Date) values("
				+ "'"+co.getLightId()+"','"+co.getUserId()+"','"+co.getComments()+"','"+co.getDate()+"')";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
}
