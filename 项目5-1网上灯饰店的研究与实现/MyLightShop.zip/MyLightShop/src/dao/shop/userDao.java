package dao.shop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import entity.shop.Orders;
import entity.shop.User;

public class userDao {
	public static Connection conn = null;
	public static void getconnection(){
		try {
			//	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			//	conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433; DatabaseName=mylightshop", "sa", "722668");
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost/mylightshop", "root", "");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*public void deletcUser(int id){
		String sql = "delete from user where UserId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}*/
	public List allId(){
		List usr = new ArrayList();
		getconnection();
		String sql = "select * from user;";
		Statement stmt;
		try {
			stmt = conn.createStatement();
			ResultSet rs =stmt.executeQuery(sql);
			while(rs.next()){
				int id = rs.getInt(1);
				usr.add(id);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return usr;
	}

	public User Login(String loginId){
		//public List<User> Login(String loginId){
		User usr=null;
		getconnection();
		String sql =  "select * from user where LoginId = "+loginId;
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()){
				usr= new User();
				usr.setUserId(rs.getInt(1)); 
				usr.setUserName(rs.getString(2));
				usr.setAddresss(rs.getString(3));
				usr.setPostalCode(rs.getString(4));
				usr.setPhone(rs.getString(5));
				usr.setEmail(rs.getString(6));
				usr.setGender(rs.getString(7));
				usr.setUserRoleId(rs.getInt(8));
				usr.setUserStateId(rs.getInt(9));
				usr.setLoginId(rs.getString(10));
				usr.setLoginPwd(rs.getString(11));
				usr.setLastLoginTime(rs.getString(12));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return usr;
	}
	
	public int userAdd(User usr){
		if(Login(usr.getLoginId())!=null){
			return 1;
		}
		List id = allId();
		Random rand = new Random();
		int new_id = rand.nextInt(10000),i;
		while(true){
			for(i= 0; i<id.size();i++){
				if(new_id==id.indexOf(i)){
					break;
				}
			}
			if(i==id.size())
				break;
			else{
				new_id = rand.nextInt(10000);
				i=0;
			}
		}
		getconnection();
		usr.setUserId(new_id);
		String sql = "insert into user values(?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, usr.getUserId());
			ps.setString(2, usr.getUserName());
			ps.setString(3, usr.getAddresss());
			ps.setString(4, usr.getPostalCode());
			ps.setString(5, usr.getPhone());
			ps.setString(6, usr.getEmail());
			ps.setString(7, usr.getGender());
			ps.setInt(8,usr.getUserRoleId());
			ps.setInt(9, usr.getUserStateId());
			ps.setString(10, usr.getLoginId());
			ps.setString(11, usr.getLoginPwd());
			ps.setString(12, usr.getLastLoginTime());
			if(ps.executeUpdate()==1){
				return 0;
			}else
				return -1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return -1;
	}
	
	public int updateUser(User usr){
		User u = Login(usr.getLoginId());
		if(u!=null&&u.getUserId()!=usr.getUserId())
			return 1;
		getconnection();
		String sql = "update user set UserName='"+usr.getUserName()+"', Address='"+usr.getAddresss()+"',PostalCode='"+usr.getPostalCode()+"',Phone='"+usr.getPhone()+"',Email='"+usr.getEmail()+"',LoginId='"+usr.getLoginId()+"' where UserId = '"+usr.getUserId()+"'";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return -1;
	}
	public int changePsw(int id,String psw,String Npsw){
		String sql = "select * from user where UserId = '"+id+"'and LoginPwd='"+psw+"';";
		getconnection();
		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(sql);
			ResultSet rs= stmt.executeQuery();
			if(rs.next()){
				String sql2 = "update user set LoginPwd = '+Npsw+' where UserId='"+id+"'";
				stmt=conn.prepareStatement(sql2);
				if(stmt.executeUpdate()==1){
					return 0;
				}else
					return -2;
			}else{
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return -1;
	}
	public int getTotalPage(String sql) {
		getconnection();
		try {
			PreparedStatement statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			int count =0;
			if(rs.next()){
				count=rs.getInt(1);
				System.out.print(count);
			}
			if(count%3==0)
				return count/3;
			else
				return count/3+1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	

	//�����ݿ�����ӡ��޸ĺ�ɾ���Ĳ���
	    public boolean executeUpdate(String sql) {

	        if (conn == null) {
	        	getconnection();
	        }
	        try {
	            Statement stmt = conn.createStatement();
	            int iCount = stmt.executeUpdate(sql);
	            
	            return true;
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	            return false;
	        }

	    }
	    public ResultSet executeQuery(String sql) {
	        ResultSet rs;
	        try {
	            if (conn == null) {
	            	getconnection();
	            }
	            Statement stmt = conn.createStatement();
	            try {
	                rs = stmt.executeQuery(sql);
	            } catch (SQLException e) {
	                System.out.println(e.getMessage());
	                return null;
	            }
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	          
	            return null;
	        }
	        return rs;
	    }
}
