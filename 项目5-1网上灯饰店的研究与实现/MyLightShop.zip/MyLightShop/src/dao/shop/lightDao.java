package dao.shop;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.shop.Brand;
import entity.shop.Catagory;
import entity.shop.Light;
import entity.shop.Style;


public class lightDao implements Serializable{
	public static Connection conn;
	public void getconnection(){
		try {
		//	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		//	conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433; DatabaseName=mylightshop", "sa", "722668");
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost/mylightshop", "root", "");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Brand getBrand(int id){
		getconnection();
		Brand bra = null;
		String sql = "select * from brand where BrandId = '"+id+"';";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			if(rs.next()){
				bra = new Brand();
				bra.setBrandId(rs.getInt(1));
				bra.setBrandName(rs.getString(2));
			}
			return bra;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bra;
	}
	
	public Style getStyle(int id){
		getconnection();
		Style sty = null;
		String sql = "select * from stytle where StytleId = '"+id+"';";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			if(rs.next()){
				sty = new Style();
				sty.setStyleId(rs.getInt(1));
				sty.setStyleName(rs.getString(2));
			}
			return sty;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sty;
	}
	public Catagory getCatagory(int id){
		getconnection();
		Catagory cat = null;
		String sql = "select * from catagory where CatagoryId = '"+id+"';";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			if(rs.next()){
				cat = new Catagory();
				cat.setCatagoryId(rs.getInt(1));
				cat.setCatagoryName(rs.getString(2));
			}
			return cat;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cat;
	}

	public int getTotalPage(int pageSize,String sql){
		getconnection();
		try {
			PreparedStatement statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			int count =0;
			if(rs.next()){
				count=rs.getInt(1);
			//	System.out.print(count);
			}
			if(count%pageSize==0)
				return count/pageSize;
			else
				return count/pageSize+1;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public List<Light> quary(String sql){
		List<Light> light =new ArrayList<Light>();
		getconnection();
		PreparedStatement statement;
		try {
			statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			while(rs.next()){
				Light li = new Light();
				li.setLightId(rs.getInt(1));
				//System.out.println(li.getLightId());
				li.setCatagoryId(rs.getInt(2));
				li.setBrandId(rs.getInt(3));
				li.setStytleId(rs.getInt(4));
				li.setStuff(rs.getString(5));
				li.setColor(rs.getString(6));
				li.setLocate(rs.getString(7));
				li.setPrice(rs.getFloat(8));
				li.setQuantity(rs.getInt(9));
				li.setDescription(rs.getString(10));
				li.setImage(rs.getString(11));
				light.add(li);
			}
			System.out.print(light.size());
			return light;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Brand> queryBrand(){
		List<Brand> brand = new ArrayList<Brand>();
		getconnection();
		String sql = "select * from brand;";
		PreparedStatement statement;
		try {
			statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			while(rs.next()){
				Brand b = new Brand();
				b.setBrandId(rs.getInt(1));
				b.setBrandName(rs.getString(2));
				brand.add(b);
			}
			return brand;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return brand;
	}
	public int updateLight(Light li){
		getconnection();
		try {
			String sql = "update light set CatagoryId = '"+li.getCatagoryId()+"',BrandId='"+li.getBrandId()+"',StytleId='"+li.getStytleId()+"',Stuff"
					+ "='"+li.getStuff()+"',Color='"+li.getColor()+"',Locate='"+li.getLocate()+"',Price='"+li.getPrice()+"',Quantity='"+li.getQuantity()+"'"
							+ ",Description='"+li.getDescription()+"',Images='"+li.getImage()+"'where LightId='"+li.getLightId()+"';";
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}
			else
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public Light getLigntInfo(int id){
		Light li=null;
		getconnection();
		String sql ="select * from light where LightId='"+id+"'";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				li = new Light();
				li.setLightId(rs.getInt(1));
				li.setCatagoryId(rs.getInt(2));
				li.setBrandId(rs.getInt(3));
				li.setStytleId(rs.getInt(4));
				li.setStuff(rs.getString(5));
				li.setColor(rs.getString(6));
				li.setLocate(rs.getString(7));
				li.setPrice(rs.getDouble(8));
				li.setQuantity(rs.getInt(9));
				li.setDescription(rs.getString(10));
				li.setImage(rs.getString(11));
			}
			return li;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return li;
	}
	public int delete(int id){
		String sql = "delete from light where LightId = '"+id+"'";
		getconnection();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			if(ps.executeUpdate()==1){
				return 0;
			}
			else 
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	public List<Light> less10(){
		List<Light>list=new ArrayList<Light>();
		getconnection();
		String sql = "select * from light where Quantity<=10";
		PreparedStatement statement;
		try {
			statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			while(rs.next()){
				Light li = new Light();
				li.setLightId(rs.getInt(1));
				li.setCatagoryId(rs.getInt(2));
				li.setBrandId(rs.getInt(3));
				li.setStytleId(rs.getInt(4));
				li.setStuff(rs.getString(5));
				li.setColor(rs.getString(6));
				li.setLocate(rs.getString(7));
				li.setPrice(rs.getDouble(8));
				li.setQuantity(rs.getInt(9));
				li.setDescription(rs.getString(10));
				li.setImage(rs.getString(11));
				list.add(li);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public List<Light> look(String sql){
		List<Light>list=new ArrayList<Light>();
		getconnection();
		PreparedStatement statement;
		try {
			statement = conn.prepareStatement(sql);
			ResultSet rs = statement.executeQuery();
			while(rs.next()){
				Light li = new Light();
				li.setLightId(rs.getInt(1));
				li.setCatagoryId(rs.getInt(2));
				li.setBrandId(rs.getInt(3));
				li.setStytleId(rs.getInt(4));
				li.setStuff(rs.getString(5));
				li.setColor(rs.getString(6));
				li.setLocate(rs.getString(7));
				li.setPrice(rs.getDouble(8));
				li.setQuantity(rs.getInt(9));
				li.setDescription(rs.getString(10));
				li.setImage(rs.getString(11));
				list.add(li);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public int lightAdd(Light li){
		getconnection();
		String sql = "insert into light (CatagoryId,BrandId,StytleId,Stuff,Color,Locate"
				+ ",Price,Quantity,Description,Images) values(?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, li.getCatagoryId());
			ps.setInt(2, li.getBrandId());
			ps.setInt(3, li.getStytleId());
			ps.setString(4, li.getStuff());
			ps.setString(5, li.getColor());
			ps.setString(6, li.getLocate());
			ps.setDouble(7, li.getPrice());
			ps.setInt(8, li.getQuantity());
			ps.setString(9,li.getDescription());
			ps.setString(10, li.getImage());
			if(ps.executeUpdate()==1){
				return 0;
			}else 
				return -1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	//�����ݿ�Ĳ�ѯ����
	   public ResultSet executeQuery(String sql) {
	       ResultSet rs;
	       try {
	           if (conn == null) {
	        	   getconnection();
	           }
	           Statement stmt = conn.createStatement();
	           try {
	               rs = stmt.executeQuery(sql);
	           } catch (SQLException e) {
	               System.out.println(e.getMessage());
	               return null;
	           }
	       } catch (SQLException e) {
	           System.out.println(e.getMessage());
	           return null;
	       }
	       return rs;
	   }
	   public boolean executeUpdate(String sql) {

	        if (conn == null) {
	        	getconnection();
	        }
	        try {
	            Statement stmt = conn.createStatement();
	            System.out.print(sql);
	            int iCount = stmt.executeUpdate(sql);
	            if(iCount>0)
	            return true;
	            else
	            	return false;
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	            return false;
	        }

	    }
	   
}
