package entity.shop;

public class Statistics {
	protected int lightId;
	protected int clicks;
	protected int storeCount;
	protected int saleCount;
	public Statistics() {
		super();
	}
	public Statistics(int lightId, int clicks, int storeCount, int saleCount) {
		super();
		this.lightId = lightId;
		this.clicks = clicks;
		this.storeCount = storeCount;
		this.saleCount = saleCount;
	}
	public int getLightId() {
		return lightId;
	}
	public void setLightId(int lightId) {
		this.lightId = lightId;
	}
	public int getClicks() {
		return clicks;
	}
	public void setClicks(int clicks) {
		this.clicks = clicks;
	}
	public int getStoreCount() {
		return storeCount;
	}
	public void setStoreCount(int storeCount) {
		this.storeCount = storeCount;
	}
	public int getSaleCount() {
		return saleCount;
	}
	public void setSaleCount(int saleCount) {
		this.saleCount = saleCount;
	}
	
}

