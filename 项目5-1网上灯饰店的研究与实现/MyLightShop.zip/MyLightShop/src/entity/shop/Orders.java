package entity.shop;

public class Orders {
	protected String orderId;
	protected int userId;
	protected int lightId;
	protected int quantity;
	protected double totaPrice;
	protected String date;
	protected int orderStateId;
	protected int showOrNot;
	protected String receiveName;
	protected String recievePhone;
	protected String address;
	protected String email;
	protected String postCode;
	protected String postType;
	protected String patmentType;
	protected int postFree;
	public Orders() {
		super();
	}
	public Orders(String orderId, int userId, int lightId, int quantity,
			double totaPrice, String date, int orderStateId, int showOrNot,
			String receiveName, String recievePhone, String address,
			String email, String postCode, String postType, String patmentType,
			int postFree) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.lightId = lightId;
		this.quantity = quantity;
		this.totaPrice = totaPrice;
		this.date = date;
		this.orderStateId = orderStateId;
		this.showOrNot = showOrNot;
		this.receiveName = receiveName;
		this.recievePhone = recievePhone;
		this.address = address;
		this.email = email;
		this.postCode = postCode;
		this.postType = postType;
		this.patmentType = patmentType;
		this.postFree = postFree;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getLightId() {
		return lightId;
	}
	public void setLightId(int lightId) {
		this.lightId = lightId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotaPrice() {
		return totaPrice;
	}
	public void setTotaPrice(double totaPrice) {
		this.totaPrice = totaPrice;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getOrderStateId() {
		return orderStateId;
	}
	public void setOrderStateId(int orderStateId) {
		this.orderStateId = orderStateId;
	}
	public int getShowOrNot() {
		return showOrNot;
	}
	public void setShowOrNot(int showOrNot) {
		this.showOrNot = showOrNot;
	}
	public String getReceiveName() {
		return receiveName;
	}
	public void setReceiveName(String receiveName) {
		this.receiveName = receiveName;
	}
	public String getRecievePhone() {
		return recievePhone;
	}
	public void setRecievePhone(String recievePhone) {
		this.recievePhone = recievePhone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getPostType() {
		return postType;
	}
	public void setPostType(String postType) {
		this.postType = postType;
	}
	public String getPatmentType() {
		return patmentType;
	}
	public void setPatmentType(String patmentType) {
		this.patmentType = patmentType;
	}
	public int getPostFree() {
		return postFree;
	}
	public void setPostFree(int postFree) {
		this.postFree = postFree;
	}
	
}
