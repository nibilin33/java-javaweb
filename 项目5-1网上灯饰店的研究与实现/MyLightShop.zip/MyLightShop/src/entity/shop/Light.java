package entity.shop;

public class Light {
	protected int lightId;
	protected int catagoryId;
	protected int brandId;
	protected int stytleId;
	protected String stuff;
	protected String color;
	protected String locate;
	protected double price;
	protected int quantity;
	protected String description;
	protected String image;
	public Light(){}
	public Light(int lightId, int catagoryId, int brandId, int stytleId,
			String stuff, String color, String locate, double price,
			int quantity, String description, String image) {
		super();
		this.lightId = lightId;
		this.catagoryId = catagoryId;
		this.brandId = brandId;
		this.stytleId = stytleId;
		this.stuff = stuff;
		this.color = color;
		this.locate = locate;
		this.price = price;
		this.quantity = quantity;
		this.description = description;
		this.image = image;
	}
	public int getLightId() {
		return lightId;
	}
	public void setLightId(int lightId) {
		this.lightId = lightId;
	}
	public int getCatagoryId() {
		return catagoryId;
	}
	public void setCatagoryId(int catagoryId) {
		this.catagoryId = catagoryId;
	}
	public int getBrandId() {
		return brandId;
	}
	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}
	public int getStytleId() {
		return stytleId;
	}
	public void setStytleId(int stytleId) {
		this.stytleId = stytleId;
	}
	public String getStuff() {
		return stuff;
	}
	public void setStuff(String stuff) {
		this.stuff = stuff;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getLocate() {
		return locate;
	}
	public void setLocate(String locate) {
		this.locate = locate;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "Light [lightId=" + lightId + ", catagoryId=" + catagoryId
				+ ", brandId=" + brandId + ", stytleId=" + stytleId
				+ ", stuff=" + stuff + ", color=" + color + ", locate="
				+ locate + ", price=" + price + ", quantity=" + quantity
				+ ", description=" + description + ", image=" + image + "]";
	}
	
}
