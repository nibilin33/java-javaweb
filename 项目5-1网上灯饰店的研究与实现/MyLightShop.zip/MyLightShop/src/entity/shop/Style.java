package entity.shop;

public class Style {
	public int styleId;
	public String styleName;
	public Style() {
		super();
	}
	public Style(int styleId, String styleName) {
		super();
		this.styleId = styleId;
		this.styleName = styleName;
	}
	public int getStyleId() {
		return styleId;
	}
	public void setStyleId(int styleId) {
		this.styleId = styleId;
	}
	public String getStyleName() {
		return styleName;
	}
	public void setStyleName(String styleName) {
		this.styleName = styleName;
	}
	
}
