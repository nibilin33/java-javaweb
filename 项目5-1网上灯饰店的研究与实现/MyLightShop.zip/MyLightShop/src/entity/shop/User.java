package entity.shop;

public class User{
	protected int userId;
	protected String userName;
	protected String addresss;
	protected String postalCode;
	protected String phone;
	protected String email;
	protected String gender;
	protected int userRoleId;
	protected int userStateId;
	protected String LoginId;
	protected String LoginPwd;
	protected String lastLoginTime;
	public User(){}
	public User(int userId,String userName,String addresss,String postalCode,String phone,String email
			,String gender,int userRoleId,int userStateId,String LoginId,String LoginPwd,String lastLoginTime){
		this.userId=userId;
		this.userName=userName;
		this.addresss=addresss;
		this.postalCode=postalCode;
		this.phone=phone;
		this.email=email;
		this.gender=gender;
		this.userRoleId=userRoleId;
		this.userStateId=userStateId;
		this.LoginId=LoginId;
		this.LoginPwd=LoginPwd;
		this.lastLoginTime=lastLoginTime;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddresss() {
		return addresss;
	}
	public void setAddresss(String addresss) {
		this.addresss = addresss;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}
	public int getUserStateId() {
		return userStateId;
	}
	public void setUserStateId(int userStateId) {
		this.userStateId = userStateId;
	}
	public String getLoginId() {
		return LoginId;
	}
	public void setLoginId(String loginId) {
		LoginId = loginId;
	}
	public String getLoginPwd() {
		return LoginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		LoginPwd = loginPwd;
	}
	public String getLastLoginTime() {
		return lastLoginTime;
	}
	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", addresss=" + addresss + ", postalCode=" + postalCode
				+ ", phone=" + phone + ", email=" + email + ", gender="
				+ gender + ", userRoleId=" + userRoleId + ", userStateId="
				+ userStateId + ", LoginId=" + LoginId + ", LoginPwd="
				+ LoginPwd + ", lastLoginTime=" + lastLoginTime + "]";
	}
}
