package entity.shop;

public class MyShopCart {
	protected int shopCardId;
	protected int lightId;
	protected int userId;
	protected String addDate;
	
	public MyShopCart() {
		super();
	}
	
	public MyShopCart(int shopCardId, int lightId, int userId, String addDate) {
		super();
		this.shopCardId = shopCardId;
		this.lightId = lightId;
		this.userId = userId;
		this.addDate = addDate;
	}

	public int getShopCardId() {
		return shopCardId;
	}

	public void setShopCardId(int shopCardId) {
		this.shopCardId = shopCardId;
	}

	public int getLightId() {
		return lightId;
	}

	public void setLightId(int lightId) {
		this.lightId = lightId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}
	
	
}
