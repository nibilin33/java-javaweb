package entity.shop;

public class WishList {
	protected int wishListId;
	protected int lightId;
	protected int userId;
	protected String storeDate;
	public WishList() {
		super();
	}
	public WishList(int wishListId, int lightId, int userId, String storeDate) {
		super();
		this.wishListId = wishListId;
		this.lightId = lightId;
		this.userId = userId;
		this.storeDate = storeDate;
	}
	public int getWishListId() {
		return wishListId;
	}
	public void setWishListId(int wishListId) {
		this.wishListId = wishListId;
	}
	public int getLightId() {
		return lightId;
	}
	public void setLightId(int lightId) {
		this.lightId = lightId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getStoreDate() {
		return storeDate;
	}
	public void setStoreDate(String storeDate) {
		this.storeDate = storeDate;
	}
	
}
