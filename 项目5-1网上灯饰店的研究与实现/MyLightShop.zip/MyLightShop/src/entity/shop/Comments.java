package entity.shop;

public class Comments {
	protected int commentId;
	protected int lightId;
	protected int userId;
	protected String comments;
	protected String date;
	public Comments(){}
	public Comments(int commentId, int lightId, int userId, String comments, String date){
		this.commentId=commentId;
		this.comments=comments;
		this.lightId=lightId;
		this.userId=userId;
		this.date=date;
	}
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public int getLightId() {
		return lightId;
	}
	public void setLightId(int lightId) {
		this.lightId = lightId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
