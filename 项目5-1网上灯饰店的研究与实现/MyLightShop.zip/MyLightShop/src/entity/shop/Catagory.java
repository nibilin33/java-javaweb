package entity.shop;

public class Catagory {
	protected int catagoryId;
	protected String catagoryName;
	public Catagory(){}
	public Catagory(int catagoryId, String catagoryName){
		this.catagoryId = catagoryId;
		this.catagoryName = catagoryName;
	}
	public int getCatagoryId() {
		return catagoryId;
	}
	public void setCatagoryId(int catagoryId) {
		this.catagoryId = catagoryId;
	}
	public String getCatagoryName() {
		return catagoryName;
	}
	public void setCatagoryName(String catagoryName) {
		this.catagoryName = catagoryName;
	}
	
}
