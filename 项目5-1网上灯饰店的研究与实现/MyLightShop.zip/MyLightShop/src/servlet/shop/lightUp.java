package servlet.shop;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.shop.Light;
import biz.shop.lightBiz;

public class lightUp extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public lightUp() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String lId = request.getParameter("lightId");
		int lightId = Integer.parseInt(lId);
		String caId = request.getParameter("catagoryId");
		int cId = Integer.parseInt(caId);
		String brId = request.getParameter("brandId");
		int bId = Integer.parseInt(brId);
		String stId = request.getParameter("stytleId");
		int sId = Integer.parseInt(stId);
		String stuff = request.getParameter("stuff");
		String color = request.getParameter("color");
		String locate = request.getParameter("locate");
		String price = request.getParameter("price");
		double pr = Double.parseDouble(price);
		String qa = request.getParameter("quantity");
		int qua = Integer.parseInt(qa);
		String de = request.getParameter("descirption");
		String image = request.getParameter("decription");
		
		Light light = new Light(lightId,cId,bId,sId,stuff,color,locate,pr,qua,de,image);
		
		lightBiz li =new lightBiz();
		li.lightUpdate(light);
		
		
		
		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
