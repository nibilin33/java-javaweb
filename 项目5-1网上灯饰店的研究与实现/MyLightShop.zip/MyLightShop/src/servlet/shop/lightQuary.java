package servlet.shop;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.shop.Light;
import biz.shop.lightBiz;

public class lightQuary extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public lightQuary() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String sql;
		String style = request.getParameter("style");
		String catagory = request.getParameter("zhonglei");
		String brand = request.getParameter("pinpai");
		String Sprice = request.getParameter("Sprice");
		String Lprice = request.getParameter("Lprice");
	   int style1=Integer.parseInt(style);
	   int catagory1=Integer.parseInt(catagory);
	   int brand1=Integer.parseInt(brand);
	  double Sprice1=Double.parseDouble(Sprice);
	   double Lprice1=Double.parseDouble(Lprice);
	  String page ="1";
		HttpSession sesion=request.getSession();
	//	lightBiz li = new lightBiz();
	//	int count = li.getTotalPage(sql);
		//int p = Integer.parseInt(page);
		int p=1;
	//	if(p<1)
	//		p=1;
		if("-1".equals(style)||style.trim().length()==0){
			sql = "select  * from light";
			} else {
				style1=Integer.parseInt(style);
		        
				sql = "select * from light where StytleId = '"+style1+"'";
			}
		if("-1".equals(catagory)||catagory.trim().length()==0);
		else{
			if(sql.indexOf("where")==-1){
			}else {
				sql = sql + " and CatagoryId = '"+catagory1+"'";
			}
		}
		if("-1".equals(brand)||brand.trim().length()==0);
		else {
			if(sql.indexOf("where")==-1){
				sql = sql + " where BrandId = '"+brand1+"'";
			}else{
				sql = sql + " and BrandId = '"+brand1+"'";
			}
		}
		if("-1".equals(Sprice)|| Sprice.trim().length()==0){
			if("-1".equals(Lprice)||Lprice.trim().length()==0);
			else{
				if(sql.indexOf("where")==-1)
					sql = sql + " where Price < '"+Lprice1+"'";
				else
					sql =sql + " and Price < '"+Lprice1+"'";
			}
		}else {
			if("-1".equals(Lprice)||Lprice.trim().length()==0){
				if(sql.indexOf("where")==-1)
					sql = sql + " where Price > '"+Sprice1+"'";
				else
					sql = sql + "and Price > '"+Sprice1+"'";
			}else {
				if(sql.indexOf("where")==-1)
					sql = sql + " where Price between '"+Sprice1+"' and '"+Lprice1+"'";
				else
					sql = sql + " and Price between '"+Sprice1+"' and '"+Lprice1+"'";
			}
		}
		
		
		
		
		lightBiz li = new lightBiz();
		int count = li.getTotalPage(sql);//��ҳ��
		
		
		
		
		
		if(p<1)
			p = 1;
		if(p>count)
			p = count;

		String sql1 ;
		int start = (p-1)*10;
		if("-1".equals(style)||style.trim().length()==0){
			sql1 = "select * from light";
			} else {
				sql1 = "select * from light where StytleId ='"+style1+"'";
				}
		if("-1".equals(catagory)||catagory.trim().length()==0);
		else{
			if(sql1.indexOf("where")==-1){
				sql1 = sql1 + " where CatagoryId ='"+catagory1+"'";
			}else {
				sql1 = sql1 + " and CatagoryId ='"+catagory1+"'";
			}
		}
		if("-1".equals(brand)||brand.trim().length()==0);
		else {
			if(sql1.indexOf("where")==-1){
				sql1 = sql1 + " where BrandId ='"+brand1+"'";
			}else{
				sql1 = sql1 + " and BrandId ='"+brand1+"'";
			}
		}
		if("-1".equals(Sprice)|| Sprice.trim().length()==0){
			if("-1".equals(Lprice)||Lprice.trim().length()==0);
			else{
				if(sql1.indexOf("where")==-1){
					sql1 = sql1 + " where Price <'"+Lprice1+"'";
				}
				else{
					sql1 =sql1 + " and Price <'"+Lprice1+"'";
				}
			}
		}else {
			if("-1".equals(Lprice)||Lprice.trim().length()==0){
				if(sql1.indexOf("where")==-1){
					sql1 = sql1 + " where Price >'"+Sprice1+"'";
				}
				else{
					sql1 = sql1 + " and Price >'"+Sprice1+"'";
				}
			}else {
				if(sql1.indexOf("where")==-1){
					sql1 = sql1 + " where Price between '"+Sprice1+"' and '"+Lprice1+"'";
					}
				else{
					sql1 = sql1 + " and Price between '"+Sprice1+"' and '"+Lprice1+"'";
				}
			}
		}
//		
		
		List<Light> light =new ArrayList<Light>();
	//	String sql2 = sql1+" "+"limit "+start+","+10+"";
		String sql2 = " limit "+start+","+10+"";
		String sql3 = sql1+sql2;
		light = li.showAll(sql3, p);	
		sesion.setAttribute("search2", light);
		
		response.sendRedirect("/MyLightShop/product/search.jsp?page="+count);
		
		
		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
