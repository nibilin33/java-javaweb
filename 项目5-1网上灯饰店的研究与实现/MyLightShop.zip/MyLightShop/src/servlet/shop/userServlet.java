package servlet.shop;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.shop.User;
import biz.shop.userBiz;

public class userServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public userServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession se=request.getSession();
		
		String loginId = request.getParameter("LoginId");
		String loginPsw =request.getParameter("loginPsw");
		userBiz usrbiz = new userBiz();
		User usr = usrbiz.Login(loginId);
	
		
		if(usr==null){
			/*
			 * 
			 * �û�������
			 * 
			 * */
            // request.getRequestDispatcher("/head.jsp").forward(request, response);
			//response.getWriter().write("mima");
			response.sendRedirect("http://localhost:8080/MyLightShop/correctjump.jsp?jump=0");
		}else if(loginPsw.equals(usr.getLoginPwd())==false){
			/*
			 * 
			 * �������
			 * 
			 * */
			//response.getWriter().write("mima");
			response.sendRedirect("http://localhost:8080/MyLightShop/correctjump.jsp?jump=1");
		}else if(usr.getUserRoleId()==0){
			/*
			 * 
			 * ����Ա
			 * 
			 * */
			se.setAttribute("loginid",loginId);
			response.sendRedirect("http://localhost:8080/MyLightShop/correctjump.jsp?jump=admin");
		}else{
			/*
			 * �ͻ�
			 * 
			 * */
			int uid=usr.getUserId();
			se.setAttribute("loginid",loginId);
			se.setAttribute("userid",uid);
		//	 request.getRequestDispatcher("../user/userindex.jsp").forward(request, response);
			response.sendRedirect("http://localhost:8080/MyLightShop/correctjump.jsp?jump=client");
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
