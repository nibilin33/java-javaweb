package servlet.shop;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import biz.shop.userBiz;

public class changPsw extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public changPsw() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          HttpSession sesson=request.getSession();
		String id =sesson.getAttribute("loginid").toString();
		String psw1 = request.getParameter("Opsw");
		String psw2 = request.getParameter("Npsw");
		String che=request.getParameter("check");
		if(psw2.equals(che)==false){
			//.sendRedirect("../user/modifypassword?error=fail");
			 request.getRequestDispatcher("../user/modifypassword.jsp?error=100").forward(request, response);
		}
		int Id = Integer.parseInt(id);
		userBiz ub = new userBiz();
		int flag = ub.changePsw(Id, psw1, psw2);
		if(flag==0){
			/*
			 * 
			 * �ɹ�
			 * 
			 * */
			 request.getRequestDispatcher("../user/modifypassword.jsp?error=200").forward(request, response);
		}else if(flag == -1){
			/*
			 * ���������
			 * 
			 * */
			 request.getRequestDispatcher("../user/modifypassword.jsp?error=300").forward(request, response);
		}else{
			/*
			 * ʧ��
			 * */
			 request.getRequestDispatcher("../user/modifypassword?error=400").forward(request, response);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
