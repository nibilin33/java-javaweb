package GUI.exam;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BeginTest extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
/*	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BeginTest frame = new BeginTest();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public BeginTest() {
		setTitle("\u5F00\u59CB\u8003\u8BD5\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.setBorder(BorderFactory.createTitledBorder("<html><b><i>"
				+ "<u><font face='SansSerif' size='8' color='red'>��ӭ��¼���߿���ϵͳ"
				+ "</font></u></i></b></html>"));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5F53\u524D\u7528\u6237");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		lblNewLabel.setBounds(68, 42, 92, 26);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u8EAB\u4EFD\u8BC1\u53F7");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(68, 98, 76, 26);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(170, 46, 162, 21);
		textField.setText(LoginFrame.stu.getName());
		textField.setEditable(false);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(170, 98, 162, 21);
		textField_1.setText(LoginFrame.stu.getCardNumber());
		textField_1.setEditable(false);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("\u5F00\u59CB\u8003\u8BD5\u5E76\u5F00\u59CB\u8BA1\u65F6");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "���ο���ʱ��Ϊ60��\n�����20����"
						+"��40��\nѡ����30������60��");
			setVisible(false);
			new StudentFrame().setVisible(true);;
			}
		});
		btnNewButton.setBounds(67, 153, 157, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u53D6\u6D88\u767B\u5F55");
		btnNewButton_1.setBounds(239, 153, 93, 23);
		panel.add(btnNewButton_1);
	}

}
