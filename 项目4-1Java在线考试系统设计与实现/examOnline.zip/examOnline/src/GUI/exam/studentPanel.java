package GUI.exam;

import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.JTabbedPane;
import javax.swing.BoxLayout;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import entity.exam.Student;
import DAO.exam.StudentDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class studentPanel extends JPanel {
	private JTextField textFieldID;
	private JTextField textFieldname;
	private JTextField textFieldsex;
	private JTextField textFieldcard;
	private JTextField textFieldpwd;
	private JTextField textFielddept;
	private JTextField textFieldphone;
	//private Student student=new Student();

	/**
	 * Create the panel.
	 */
	public studentPanel() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F ID\uFF1A");
		lblNewLabel.setBounds(10, 25, 54, 15);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5B66\u751F\u59D3\u540D\uFF1A");
		lblNewLabel_1.setBounds(10, 68, 66, 15);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u5B66\u751F\u6027\u522B\uFF1A");
		lblNewLabel_2.setBounds(10, 109, 66, 15);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u51C6\u8003\u8BC1\u53F7\uFF1A");
		lblNewLabel_3.setBounds(10, 148, 66, 15);
		add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u53E3   \u4EE4\uFF1A");
		lblNewLabel_4.setBounds(10, 188, 54, 15);
		add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\u6240\u5728\u9662\u7CFB\uFF1A");
		lblNewLabel_5.setBounds(10, 226, 66, 15);
		add(lblNewLabel_5);
		
		textFieldID = new JTextField();
		textFieldID.setBounds(106, 22, 97, 21);
		add(textFieldID);
		textFieldID.setColumns(10);
		
		textFieldname = new JTextField();
		textFieldname.setBounds(106, 65, 97, 21);
		add(textFieldname);
		textFieldname.setColumns(10);
		
		textFieldsex = new JTextField();
		textFieldsex.setBounds(106, 106, 97, 21);
		add(textFieldsex);
		textFieldsex.setColumns(10);
		
		textFieldcard = new JTextField();
		textFieldcard.setBounds(106, 145, 191, 21);
		add(textFieldcard);
		textFieldcard.setColumns(10);
		
		textFieldpwd = new JTextField();
		textFieldpwd.setBounds(106, 185, 191, 21);
		add(textFieldpwd);
		textFieldpwd.setColumns(10);
		
		textFielddept = new JTextField();
		textFielddept.setBounds(106, 223, 191, 21);
		add(textFielddept);
		textFielddept.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\u67E5\u8BE2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Student student=new Student();
			 student=StudentDAO.selectStudent(textFieldID.getText().trim());
				textFieldname.setText(student.getName());
				textFieldsex.setText(student.getSex());
				textFieldcard.setText(student.getCardNumber());
				textFieldpwd.setText(student.getPassword());
				textFielddept.setText(student.getDept());
				textFieldphone.setText(student.getPhone());
			}
		});
		btnNewButton_1.setBounds(331, 21, 93, 23);
		add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u589E\u52A0");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Student student=new Student();
				student.setSid(textFieldID.getText());
				student.setSex(textFieldsex.getText());
				student.setPassword(textFieldpwd.getText());
				student.setDept(textFielddept.getText());
				student.setName(textFieldname.getText());
				student.setPhone(textFieldphone.getText());
				student.setCardNumber(textFieldcard.getText());
				try {
					
				int a=StudentDAO.insertStudent(student);
				if(a==0){
					JOptionPane.showMessageDialog(null, "���ӳɹ���");
				}
				else{
					JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");
				}
				} catch (SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(331, 64, 93, 23);
		add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("\u4FEE\u6539");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Student student=new Student();
				student.setSid(textFieldID.getText());	
				student.setName(textFieldname.getText());
       student.setSex(textFieldsex.getText());	
        student.setCardNumber(textFieldcard.getText());	
           student.setPassword(textFieldpwd.getText());	
          student.setDept(textFielddept.getText());	
          student.setPhone(textFieldphone.getText());
               int a=StudentDAO.updateStudent(student);
               if(a==1){
            	   JOptionPane.showMessageDialog(null, "��ѧ�������ڣ�����ʧ�ܣ�");
               }else
            	   if(a==0){
            		   JOptionPane.showMessageDialog(null,"���³ɹ�");
            	   }else{
            		   JOptionPane.showMessageDialog(null,"����ʧ��");
            	   }
			}
		});
		btnNewButton_3.setBounds(331, 105, 93, 23);
		add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\u5220\u9664");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Student student=new Student();
				student.setSid(textFieldID.getText());	
				student.setName(textFieldname.getText());
             student.setSex(textFieldsex.getText());	
            student.setCardNumber(textFieldcard.getText());	
           student.setPassword(textFieldpwd.getText());	
          student.setDept(textFielddept.getText());	
          student.setPhone(textFieldphone.getText());
			int a=	StudentDAO.deleteStudent(student);
			 if(a==1){
          	   JOptionPane.showMessageDialog(null, "��ѧ�������ڣ�����ʧ�ܣ�");
             }else
          	   if(a==0){
          		   JOptionPane.showMessageDialog(null,"���³ɹ�");
          	   }else{
          		   JOptionPane.showMessageDialog(null,"����ʧ��");
          	   }
			}
		});
		btnNewButton_4.setBounds(331, 144, 93, 23);
		add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("\u9000\u51FA");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton_5.setBounds(331, 184, 93, 23);
		add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("\u6E05\u5C4F");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				textFieldID.setText("");
				textFieldname.setText("");
     textFieldsex.setText("");	
        textFieldcard.setText("");
          textFieldpwd.setText("");	
         textFielddept.setText("");
        textFieldphone.setText("");
			}
			
		});

		btnNewButton_6.setBounds(331, 222, 93, 23);
		add(btnNewButton_6);
		
		JLabel lblNewLabel_6 = new JLabel("\u8054\u7CFB\u7535\u8BDD\uFF1A");
		lblNewLabel_6.setBounds(10, 261, 66, 15);
		add(lblNewLabel_6);
		
		textFieldphone = new JTextField();
		textFieldphone.setBounds(106, 258, 191, 21);
		add(textFieldphone);
		textFieldphone.setColumns(10);
		
	}
}
