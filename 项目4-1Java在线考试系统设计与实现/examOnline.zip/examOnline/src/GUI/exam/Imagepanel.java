package GUI.exam;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Imagepanel extends JPanel{
		ImageIcon im;
		Dimension dimension ;
		public Imagepanel(ImageIcon im)
		{
			this.im=im;
		}
		//�����������Զ�����
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.drawImage(im.getImage(),0,0,getSize().width,getSize().height,this);
		}
	}

