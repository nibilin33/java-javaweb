package GUI.exam;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import DAO.exam.AdministratorDAO;
import DAO.exam.JDBCConnectionFactory;
import DAO.exam.TeacherDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class PersonInforPanel extends JPanel {
	private JTextField textFieldfirst;
	private JTextField textFieldsecond;
	private JTextField textFieldthird;

	/**
	 * Create the panel.
	 */
	public PersonInforPanel() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u4FEE\u6539\u767B\u5F55\u53E3\u4EE4");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 18));
		lblNewLabel.setBounds(118, 53, 124, 29);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u539F\u59CB\u53E3\u4EE4");
		lblNewLabel_1.setBounds(72, 116, 54, 15);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u65B0\u53E3\u4EE4");
		lblNewLabel_2.setBounds(72, 161, 54, 15);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u786E\u8BA4\u53E3\u4EE4");
		lblNewLabel_3.setBounds(72, 206, 54, 15);
		add(lblNewLabel_3);
		
		textFieldfirst = new JTextField();
		textFieldfirst.setBounds(149, 113, 124, 21);
		add(textFieldfirst);
		textFieldfirst.setColumns(10);
		
		textFieldsecond = new JTextField();
		textFieldsecond.setBounds(149, 158, 124, 21);
		add(textFieldsecond);
		textFieldsecond.setColumns(10);
		
		textFieldthird = new JTextField();
		textFieldthird.setBounds(149, 203, 124, 21);
		add(textFieldthird);
		textFieldthird.setColumns(10);
		
		JButton btnNewButton = new JButton("\u786E\u5B9A");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Connection conn=JDBCConnectionFactory.getConnection();
				if(textFieldsecond.getText()!=textFieldthird.getText()){
					JOptionPane.showMessageDialog(null,"ȷ���������");
			                          }else
			                          {
			                        	 if(LoginFrame.adm!=null){
			                        		 LoginFrame.adm.setPassword(textFieldthird.getText().trim());
			                        		 AdministratorDAO.updateAdministrator(LoginFrame.adm);
			                        	 }
			                        	 if(LoginFrame.teacher!=null){
			                        		 LoginFrame.teacher.setPassword(textFieldthird.getText().trim());
			                        		 TeacherDAO.updateTeacher(LoginFrame.teacher);
			                        	 }
			                          }
			}
		});
		btnNewButton.setBounds(319, 112, 93, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u6E05\u5C4F");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldfirst.setText("");
				textFieldsecond.setText("");
				textFieldthird.setText("");
			}
		});
		btnNewButton_1.setBounds(319, 157, 93, 23);
		add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u9000\u51FA");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				  System.exit(0);
			}
		});
		btnNewButton_2.setBounds(319, 202, 93, 23);
		add(btnNewButton_2);

	}

}
