package GUI.exam;

public class Common {
	    public static final String EXCEL_PATH = "lib/student.xls";
	     // sql
	     public static final String INSERT_STUDENT_SQL = "insert into student(sid,sname, sex, cardnumber,pwd,department,phone) values(?, ?, ?, ?,?,?,?)";
	     public static final String UPDATE_STUDENT_SQL = "update student set no = ?, name = ?, age= ?, score = ? where id = ? ";
	     public static final String SELECT_STUDENT_ALL_SQL = "select id,no,name,age,score from student";
	     public static final String SELECT_STUDENT_SQL = "select * from student where name like ";

}
