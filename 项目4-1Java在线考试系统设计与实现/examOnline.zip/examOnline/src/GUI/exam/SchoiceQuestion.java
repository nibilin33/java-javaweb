package GUI.exam;

import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.TextArea;

import javax.swing.ButtonGroup;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;

import entity.exam.ChoiceQuestion;
import DAO.exam.ChoiceQuestionDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.awt.GridLayout;

public class SchoiceQuestion extends JPanel {
   private ButtonGroup bg;
   JButton last,first,next,finaller;
   JTextArea textArea,textArea_1;
  public  List<ChoiceQuestion> list=new ArrayList<ChoiceQuestion>();
  private List<ChoiceQuestion>  save=ChoiceQuestionDAO.selectChoiceQuestion(3);
  public static String cresult[][]={{"",""},{"",""},{"",""}};
  JTextArea textArea1;
		  
  private int now=0;
  private JPanel panel;
  private JRadioButton A;
  private JRadioButton B;
  private JRadioButton C;
  private JRadioButton D;
	/**
	 * Create the panel.
	 */
	public SchoiceQuestion() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 105, 10, 80, 0};
		gridBagLayout.columnWeights = new double[]{1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		
		setLayout(gridBagLayout);
	  for(int i=0;i<3;i++){
		  cresult[i][0]=save.get(i).getC_answer();
	  }
		 first = new JButton("\u9996\u9898");
		first.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				now=0;
			A.setSelected(true);
	   	next.setEnabled(true);
		last.setEnabled(false);
		finaller.setEnabled(true);
	ChoiceQuestion c=save.get(now);
		textArea.setText(c.getC_question());	
			}
		});
		GridBagConstraints gbc_first = new GridBagConstraints();
		gbc_first.insets = new Insets(0, 0, 5, 5);
		gbc_first.gridx = 2;
		gbc_first.gridy = 0;
		add(first, gbc_first);
		
	 last = new JButton("\u4E0A\u4E00\u9898");
	 last.addActionListener(new ActionListener() {
	 	public void actionPerformed(ActionEvent e) {
	 		A.setSelected(true);
	 		last.setEnabled(true);
	 		if(now>0){
	 		now=now-1;
	 		ChoiceQuestion c=save.get(now);
			textArea.setText(c.getC_question());	
	 		}
	 		
	 	}
	 });
	
		GridBagConstraints gbc_last = new GridBagConstraints();
		gbc_last.insets = new Insets(0, 0, 5, 5);
		gbc_last.gridx = 3;
		gbc_last.gridy = 0;
		add(last, gbc_last);
		
		 next = new JButton("\u4E0B\u4E00\u9898");
		 next.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		last.setEnabled(true);
		 		A.setSelected(true);
		 		if(now<2){
		 		now=now+1;
		 		ChoiceQuestion c=save.get(now);
				textArea.setText(c.getC_question());
		 		}
		 	}
		 });
		
		GridBagConstraints gbc_next = new GridBagConstraints();
		gbc_next.insets = new Insets(0, 0, 5, 5);
		gbc_next.gridx = 4;
		gbc_next.gridy = 0;
		add(next, gbc_next);
		
		 finaller = new JButton("\u672B\u9898");
		 finaller.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		A.setSelected(true);
		 		now=2;
		 		ChoiceQuestion c=save.get(now);
				textArea.setText(c.getC_question());
		 	}
		 });
	
		GridBagConstraints gbc_finaller = new GridBagConstraints();
		gbc_finaller.insets = new Insets(0, 0, 5, 5);
		gbc_finaller.gridx = 5;
		gbc_finaller.gridy = 0;
		add(finaller, gbc_finaller);
		
		JButton btnNewButton_4 = new JButton("\u5386\u53F2\u8BB0\u5F55");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		GridBagConstraints gbc_btnNewButton_4 = new GridBagConstraints();
		gbc_btnNewButton_4.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton_4.gridx = 10;
		gbc_btnNewButton_4.gridy = 0;
		add(btnNewButton_4, gbc_btnNewButton_4);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 9;
		gbc_scrollPane.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 1;
		add(scrollPane, gbc_scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		GridBagConstraints gbc_scrollPane_2 = new GridBagConstraints();
		gbc_scrollPane_2.gridheight = 3;
		gbc_scrollPane_2.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_2.gridx = 10;
		gbc_scrollPane_2.gridy = 1;
		add(scrollPane_2, gbc_scrollPane_2);
		
		textArea_1 = new JTextArea();
		scrollPane_2.setViewportView(textArea_1);
		
		GridBagConstraints gbc_A = new GridBagConstraints();
		gbc_A.fill = GridBagConstraints.VERTICAL;
		gbc_A.insets = new Insets(0, 0, 5, 5);
		gbc_A.gridx = 1;
		gbc_A.gridy = 2;
		
		JButton btnNewButton_5 = new JButton("\u786E\u5B9A");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  if(A.isSelected()==true){
				  cresult[now][1]="A";
				  textArea1.setText("ѡ����Ĭ�ϴ�ΪA���뿼��ȷ����ѡ��һ��");
				  textArea1.append("��ѡ���˴�A");
			  }
			else
				if(B.isSelected()==true){
					  cresult[now][1]="B";
					  textArea1.setText("ѡ����Ĭ�ϴ�ΪA���뿼��ȷ����ѡ��һ��");
					  textArea1.append("��ѡ���˴�B");
				  }else
						if(C.isSelected()==true){
							  cresult[now][1]="C";
							  textArea1.setText("ѡ����Ĭ�ϴ�ΪA���뿼��ȷ����ѡ��һ��");
							  textArea1.append("��ѡ���˴�C");
						  }
						else
							if(B.isSelected()==true){
								  cresult[now][1]="D";
								  textArea1.setText("ѡ����Ĭ�ϴ�ΪA���뿼��ȷ����ѡ��һ��");
								  textArea1.append("��ѡ���˴�D");
							  }
			  int t=now+1;
			  textArea_1.append("��"+t+"����"+cresult[now][1]+'\n');
			  
			}
			
				
		});
		
		panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridwidth = 4;
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 2;
		add(panel, gbc_panel);
		panel.setLayout(new GridLayout(0, 4, 0, 0));
		
		A = new JRadioButton("A");
		panel.add(A);
		
		B = new JRadioButton("B");
		panel.add(B);
		
		C = new JRadioButton("C");
		panel.add(C);
		
		D = new JRadioButton("D");
		
		panel.add(D);
		bg=new ButtonGroup();
		bg.add(A);
		bg.add(B);
		bg.add(C);
		bg.add(D);
		
		GridBagConstraints gbc_btnNewButton_5 = new GridBagConstraints();
		gbc_btnNewButton_5.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_5.gridx = 6;
		gbc_btnNewButton_5.gridy = 2;
		add(btnNewButton_5, gbc_btnNewButton_5);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		GridBagConstraints gbc_scrollPane_1 = new GridBagConstraints();
		gbc_scrollPane_1.gridwidth = 9;
		gbc_scrollPane_1.insets = new Insets(0, 0, 0, 5);
		gbc_scrollPane_1.fill =GridBagConstraints.BOTH;
		gbc_scrollPane_1.gridx = 0;
		gbc_scrollPane_1.gridy = 3;
		add(scrollPane_1, gbc_scrollPane_1);
		textArea1 = new JTextArea();
		scrollPane_1.setViewportView(textArea1);
		

	}

}
