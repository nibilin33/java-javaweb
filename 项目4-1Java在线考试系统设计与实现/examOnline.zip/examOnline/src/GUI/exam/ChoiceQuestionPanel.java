package GUI.exam;

import javax.swing.Box;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.JScrollBar;

import entity.exam.ChoiceQuestion;
import DAO.exam.ChoiceQuestionDAO;

public class ChoiceQuestionPanel extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextArea textArea;

	/**
	 * Create the panel.
	 */
	public ChoiceQuestionPanel() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u9898\u76EE\u7F16\u53F7");
		lblNewLabel.setBounds(23, 39, 54, 15);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u9898\u76EE\u5185\u5BB9");
		lblNewLabel_1.setBounds(23, 83, 54, 15);
		add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u6E05\u5C4F");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				textArea.setText("");
			}
		});
		btnNewButton.setBounds(235, 35, 93, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u67E5\u8BE2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String cid=textField.getText().trim();
				if(cid.length()==0){
					JOptionPane.showMessageDialog(null, "��������Ŀ��ţ�","��ʾ��Ϣ",1);
				}else{
					try{
						ChoiceQuestion choice=ChoiceQuestionDAO.selectOneChoiceQuestion(Integer.parseInt(cid));
						if(choice!=null){
							textArea.setText(choice.getC_question());
							textField_1.setText(choice.getC_choiceA());
							textField_2.setText(choice.getC_choiceB());
							textField_3.setText(choice.getC_choiceC());
							textField_4.setText(choice.getC_choiceD());
							textField_5.setText(choice.getC_answer());
						}
					}catch(NumberFormatException E2){
						JOptionPane.showMessageDialog(null, "�������Ų����ڣ�����������");
						textField.setText("");
					}
				}
			}
		});
		btnNewButton_1.setBounds(347, 63, 93, 23);
		add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u589E\u52A0");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
				int cid=Integer.parseInt(textField.getText().trim());
				String cquestion=textArea.getText();
				String cchoiceA=textField_1.getText();
				String cchoiceB=textField_2.getText();
				String cchoiceC=textField_3.getText();
				String cchoiceD=textField_4.getText();
				String cresult=textField_5.getText();
				System.out.println(""+cid+cquestion);
				int i=ChoiceQuestionDAO.insertChoiceQuestion(new ChoiceQuestion(cid, cquestion, cchoiceA, cchoiceB, cchoiceC, cchoiceD, cresult));
				if(i==0){
					JOptionPane.showMessageDialog(null,"�ɹ���������");
				}else{
					JOptionPane.showMessageDialog(null, "����Ѿ����ڣ���ѡ��������ţ�","��ʾ��Ϣ",1);
				}
			}catch(NumberFormatException e1){
				JOptionPane.showMessageDialog(null, "�������Ŀ��Ŵ�������������");
			     textField.setText("");
			}
			}
		});
		btnNewButton_2.setBounds(347, 106, 93, 23);
		add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("\u4FEE\u6539");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ChoiceQuestion choice=new ChoiceQuestion();
				choice.setC_id(Integer.parseInt(textField.getText().trim()));
			   choice.setC_question(textArea.getText().trim());
			   choice.setC_choiceA(textField_1.getText().trim());
			   choice.setC_choiceB(textField_2.getText().trim());
			   choice.setC_choiceC(textField_3.getText().trim());
			   choice.setC_choiceD(textField_4.getText().trim());
			   choice.setC_answer(textField_5.getText().trim());
			   int a=ChoiceQuestionDAO.updateChoiceQuestion(choice);
			   if(a==0){
					JOptionPane.showMessageDialog(null,"�ɹ��޸�����");
				}else{
					JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�","��ʾ��Ϣ",1);
				}
			}
		});
		btnNewButton_3.setBounds(347, 150, 93, 23);
		add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\u5220\u9664");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
			   int a=ChoiceQuestionDAO.deleteChoiceQuestion(Integer.parseInt(textField.getText().trim()));
			   if(a==0){
				   JOptionPane.showMessageDialog(null,"�ɹ�ɾ������");
				}else{
					JOptionPane.showMessageDialog(null, "��Ų����ڣ���ѡ��������ţ�","��ʾ��Ϣ",1);
				}
			}catch(NumberFormatException ee){
				JOptionPane.showMessageDialog(null, "�������Ŀ��Ŵ�������������");
			     textField.setText("");
			}
				
			}
		});
		btnNewButton_4.setBounds(347, 194, 93, 23);
		add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("\u9000\u51FA");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton_5.setBounds(347, 236, 93, 23);
		add(btnNewButton_5);
		
		JLabel lblNewLabel_2 = new JLabel("\u9009\u9879 A");
		lblNewLabel_2.setBounds(23, 156, 54, 15);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u9009\u9879 B");
		lblNewLabel_3.setBounds(23, 189, 54, 15);
		add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u9009\u9879 C");
		lblNewLabel_4.setBounds(23, 219, 54, 15);
		add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\u9009\u9879 D");
		lblNewLabel_5.setBounds(23, 244, 54, 15);
		add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\u7B54\u6848\u4E3A");
		lblNewLabel_6.setBounds(23, 275, 54, 15);
		add(lblNewLabel_6);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(76, 68, 252, 78);
		add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		textField = new JTextField();
		textField.setBounds(83, 36, 84, 21);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(76, 151, 252, 21);
		add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(76, 186, 252, 21);
		add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(76, 216, 252, 21);
		add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(76, 241, 252, 21);
		add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(76, 269, 252, 21);
		add(textField_5);
		textField_5.setColumns(10);
		
	
		
		

	}
}
