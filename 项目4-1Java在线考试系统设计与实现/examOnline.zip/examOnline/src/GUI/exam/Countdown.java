package GUI.exam;

import javax.swing.JOptionPane;

public class Countdown extends Thread{
	int i=3600; 
 int hour,seconds;
	public Countdown() {
	super();
	// TODO �Զ����ɵĹ��캯�����
}

	public void run() //�߳��ڴ˿�ʼִ��
	{ 
	while(i!=0) 
	{ 
	try 
	{ 
	sleep(1000);	
	hour=i/60;
	seconds=i%60;
	StudentFrame.lblNewLabel_1.setText(hour+"�� "+": "+seconds+ "�� "); 
	i--; 
	} 
	catch(Exception eee) 
	{} 
	}	
	if(i==0) 
	{ 
	JOptionPane.showMessageDialog(null, " ʱ�䵽��");	
	} 
	}	
 

}
