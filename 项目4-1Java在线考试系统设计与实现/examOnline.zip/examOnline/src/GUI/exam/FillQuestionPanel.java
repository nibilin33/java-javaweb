package GUI.exam;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import DAO.exam.ChoiceQuestionDAO;
import DAO.exam.FillQuestionDAO;
import entity.exam.ChoiceQuestion;
import entity.exam.FillQuestion;

public class FillQuestionPanel extends JPanel {

	private JTextField textField;
	private JTextField textField_5;
	private JTextArea textArea;

	/**
	 * Create the panel.
	 */
	public FillQuestionPanel() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u9898\u76EE\u7F16\u53F7");
		lblNewLabel.setBounds(23, 39, 54, 15);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u9898\u76EE\u5185\u5BB9");
		lblNewLabel_1.setBounds(23, 83, 54, 15);
		add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u6E05\u5C4F");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_5.setText("");
				textArea.setText("");
			}
		});
		btnNewButton.setBounds(235, 35, 93, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u67E5\u8BE2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String fid=textField.getText().trim();
				if(fid.length()==0){
					JOptionPane.showMessageDialog(null, "��������Ŀ��ţ�","��ʾ��Ϣ",1);
				}else{
					try{
						FillQuestion choice=FillQuestionDAO.selectOneFillQuestion(Integer.parseInt(fid));
						if(choice!=null){
							textArea.setText(choice.getF_question());	
							textField_5.setText(choice.getF_answer());
						}
					}catch(NumberFormatException E2){
						JOptionPane.showMessageDialog(null, "�������Ų����ڣ�����������");
						textField.setText("");
					}
				}
			}
		
		});
		btnNewButton_1.setBounds(347, 63, 93, 23);
		add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u589E\u52A0");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					int fid=Integer.parseInt(textField.getText().trim());
					String fquestion=textArea.getText();
					String fanswer=textField_5.getText();
					int i=FillQuestionDAO.insertFillQuestion(new FillQuestion(fid,fquestion,fanswer));
					if(i==0){
						JOptionPane.showMessageDialog(null,"�ɹ���������");
					}else{
						JOptionPane.showMessageDialog(null, "����Ѿ����ڣ���ѡ��������ţ�","��ʾ��Ϣ",1);
					}
				}catch(NumberFormatException e1){
					JOptionPane.showMessageDialog(null, "�������Ŀ��Ŵ�������������");
				     textField.setText("");
				}
				}
		});
		btnNewButton_2.setBounds(347, 106, 93, 23);
		add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("\u4FEE\u6539");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FillQuestion fill=new FillQuestion();
				fill.setF_id(Integer.parseInt(textField.getText().trim()));
			  fill.setF_question(textArea.getText().trim());
			
			fill.setF_answer(textField_5.getText().trim());
			   int a=FillQuestionDAO.updateFillQuestion(fill);
			  if(a==0){
					JOptionPane.showMessageDialog(null,"�ɹ��޸�����");
				}else{
					JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ�","��ʾ��Ϣ",1);
			}
			}
		
		});
		btnNewButton_3.setBounds(347, 150, 93, 23);
		add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\u5220\u9664");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					   int a=FillQuestionDAO.deleteFillQuestion(Integer.parseInt(textField.getText().trim()));
					   if(a==0){
						   JOptionPane.showMessageDialog(null,"�ɹ�ɾ������");
						}else{
							JOptionPane.showMessageDialog(null, "��Ų����ڣ���ѡ��������ţ�","��ʾ��Ϣ",1);
						}
					}catch(NumberFormatException ee){
						JOptionPane.showMessageDialog(null, "�������Ŀ��Ŵ�������������");
					     textField.setText("");
					}
						
			}
		});
		btnNewButton_4.setBounds(347, 194, 93, 23);
		add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("\u9000\u51FA");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);			}
		});
		btnNewButton_5.setBounds(347, 236, 93, 23);
		add(btnNewButton_5);
		
		JLabel lblNewLabel_6 = new JLabel("\u9898\u76EE\u7B54\u6848");
		lblNewLabel_6.setBounds(23, 213, 54, 15);
		add(lblNewLabel_6);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(76, 68, 252, 105);
		add(scrollPane);
		
		 textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		textField = new JTextField();
		textField.setBounds(83, 36, 84, 21);
		add(textField);
		textField.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(76, 210, 252, 21);
		add(textField_5);
		textField_5.setColumns(10);
	}		

}
