package GUI.exam;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import entity.exam.Student;

public class UpLoadexcel {

	public List<Student> readXLS()throws IOException{
		InputStream is=new FileInputStream(Common.EXCEL_PATH);
	
		List<Student> list=new ArrayList<Student>();
		HSSFWorkbook hssfWorkbook = new HSSFWorkbook(is);

       Student student= null;

        // ѭ��������Sheet

        for (int numSheet = 0; numSheet < hssfWorkbook.getNumberOfSheets(); numSheet++) {

            HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(numSheet);

            if (hssfSheet == null) {

                continue;

            }

            // ѭ����Row

            for (int rowNum = 1; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {

                HSSFRow hssfRow = hssfSheet.getRow(rowNum);

                if (hssfRow != null) {
                	student = new Student();
                   HSSFCell sid = hssfRow.getCell(0);
                    HSSFCell sname = hssfRow.getCell(1);
                  HSSFCell sex = hssfRow.getCell(2);
                 HSSFCell cardnumber = hssfRow.getCell(3);
                 HSSFCell pwd = hssfRow.getCell(4);
                 HSSFCell department = hssfRow.getCell(5);
                 HSSFCell phone = hssfRow.getCell(6);
                 HSSFCell score=hssfRow.createCell(7);
                student.setSid(getValue(sid).substring(0,getValue(sid).length()-2));
                student.setName(getValue(sname));
                student.setSex(getValue(sex));
                student.setCardNumber(getValue(cardnumber).substring(0,getValue(cardnumber).length()-2));
                student.setDept(getValue(department));
                student.setPassword(getValue(pwd).substring(0,getValue(pwd).length()-2));
                student.setPhone(getValue(phone).substring(0,getValue(phone).length()-2));
                student.setScore(getValue(score).substring(0,getValue(score).length()-2));
                list.add(student);
               
                  
            }

        }
		
	}
        return list;
	}
        private String getValue(HSSFCell hssfCell) {
                  if (hssfCell.getCellType() == hssfCell.CELL_TYPE_BOOLEAN) {
                  // ���ز������͵�ֵ
                       return String.valueOf(hssfCell.getBooleanCellValue());
                   } else if (hssfCell.getCellType() == hssfCell.CELL_TYPE_NUMERIC) {
                        // ������ֵ���͵�ֵ
                         return String.valueOf(hssfCell.getNumericCellValue());
               } else {
                        // �����ַ������͵�ֵ
            	
                       return String.valueOf(hssfCell.getStringCellValue());
                    }
        	       }


}
