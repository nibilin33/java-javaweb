package GUI.exam;

import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;

import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import entity.exam.Student;
import DAO.exam.JDBCConnectionFactory;
import DAO.exam.StudentDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.beans.Statement;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ExcelPanel extends JPanel {
	private JTable table;
   private JPanel contentpane;
   public ResultSet rs;
   public DefaultTableModel tablemodel;
   public volatile boolean changed=false;
   private final ScheduledThreadPoolExecutor pool=new ScheduledThreadPoolExecutor(1);
	/**
	 * Create the panel.
	 */
	public ExcelPanel() {
		Connection con=JDBCConnectionFactory.getConnection();
		setLayout(new BorderLayout(0, 0));
		contentpane=new JPanel();
		
		JScrollPane scrollPane = new JScrollPane();
		 add(scrollPane, BorderLayout.CENTER);
		table = new JTable();
		scrollPane.setViewportView(table);
		tablemodel=(DefaultTableModel)table.getModel();//get tablemodel
		tablemodel.setRowCount(0);//��ձ���ģ���е�����
		tablemodel.setColumnIdentifiers(new Object[]{"ѧ��ID","ѧ������","ѧ���Ա�","׼��֤��","����","����Ժϵ","��ϵ�绰","�ɼ�"});
	   
		pool.scheduleAtFixedRate(new Runnable() {
			
			@Override
			public void run() {
				// TODO �Զ����ɵķ������
				if(changed){
				
					try {
						java.sql.Statement st=con.createStatement();
						rs=st.executeQuery("select * from student");
					} catch (SQLException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
					
					try {
						while(rs.next()){
							Vector<String> vc=new Vector<String>();
							vc.addElement(rs.getString(1));
							vc.addElement(rs.getString(2));
							vc.addElement(rs.getString(3));
							vc.addElement(rs.getString(4));
							vc.addElement(rs.getString(5));
							vc.addElement(rs.getString(6));
							vc.addElement(rs.getString(7));
							vc.addElement(rs.getString(8));
							tablemodel.addRow(vc);
							
						}
						changed=false;
					} catch (SQLException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
					}
               
				
					}
			}
		}, 1,5,TimeUnit.SECONDS);
				// TODO �Զ����ɵķ������
				
			
	
		
		
	    add(contentpane,BorderLayout.SOUTH);
	    contentpane.setLayout(new BorderLayout(0, 0));
	    JButton btnNewButton = new JButton("\u5BFC\u5165");
	    btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		JFileChooser chooser=new JFileChooser();
	    		FileNameExtensionFilter filter=new FileNameExtensionFilter("XLS�ļ�","xls");
	    		chooser.setFileFilter(filter);
	    		int option=chooser.showOpenDialog(contentpane);
	    		if(option==JFileChooser.APPROVE_OPTION){
	    	     File file=chooser.getSelectedFile();
				try {
					UpLoadexcel up=new UpLoadexcel();
	    		    List<Student> list;
					list = up.readXLS();
					StudentDAO.updatemuch(list);
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
	    		}
	    	    changed=true;
	    	}
	    	
	    });
	    contentpane.add(btnNewButton, BorderLayout.CENTER);
	    
	    JButton btnNewButton_1 = new JButton("\u5BFC\u51FA");
	    btnNewButton_1.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		               out();
	    	}
	    });
	    contentpane.add(btnNewButton_1, BorderLayout.NORTH);
	    

	}
	public void out(){
		
		    HSSFWorkbook wb = new HSSFWorkbook();   
		    HSSFSheet sheet = wb.createSheet("ѧ����һ");  
		   HSSFRow row = sheet.createRow((int) 0);  
		   HSSFCellStyle style = wb.createCellStyle();  
		   style.setAlignment(HSSFCellStyle.ALIGN_CENTER); 
		  HSSFCell cell = row.createCell((short) 0);  
		    cell.setCellValue("ѧ��");  
		    cell.setCellStyle(style);  
		    cell = row.createCell((short) 1);  
		    cell.setCellValue("����");  
		    cell.setCellStyle(style);  
		    cell = row.createCell((short) 2);  
		    cell.setCellValue("�Ա�");  
		     cell.setCellStyle(style);  
		    cell = row.createCell((short) 3);  
		      cell.setCellValue("����֤��");  
		      cell.setCellStyle(style);  
		      cell = row.createCell((short) 4);  
		      cell.setCellValue("����");  
		      cell.setCellStyle(style); 
		      cell = row.createCell((short) 5);  
		      cell.setCellValue("ϵ��");  
		      cell.setCellStyle(style); 
		      cell = row.createCell((short) 6);  
		      cell.setCellValue("�绰");  
		      cell.setCellStyle(style);  
		      cell = row.createCell((short) 7);  
		      cell.setCellValue("�ɼ�");  
		      cell.setCellStyle(style);     
		     List list =StudentDAO.getStudent() ;
		    for (int i = 0; i < list.size(); i++)  
		  {  
		    	row = sheet.createRow((int) i + 1);  
		             Student stu = (Student) list.get(i); 
		             row.createCell((short) 0).setCellValue(stu.getSid());  
		             row.createCell((short) 1).setCellValue(stu.getName());  
		             row.createCell((short) 2).setCellValue(stu.getSex());  
		             row.createCell((short) 3).setCellValue(stu.getCardNumber()); 
		             row.createCell((short) 4).setCellValue(stu.getPassword());  
		             row.createCell((short) 5).setCellValue(stu.getDept());  
		             row.createCell((short) 6).setCellValue(stu.getPhone()); 
		             row.createCell((short) 7).setCellValue(stu.getScore());  
		         }  
		       
		         try  
		        {  
		            FileOutputStream fout = new FileOutputStream("D:/students.xls");  
		            wb.write(fout);  
		           fout.close();  
		         }  
		         catch (Exception e)  
		         {  
		            e.printStackTrace();  
		       }  

	}
}
