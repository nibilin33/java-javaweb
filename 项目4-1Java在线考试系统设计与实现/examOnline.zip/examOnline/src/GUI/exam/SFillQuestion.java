package GUI.exam;

import javax.swing.JPanel;

import java.awt.GridBagLayout;

import javax.swing.JButton;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.TextField;

import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;

import DAO.exam.ChoiceQuestionDAO;
import DAO.exam.FillQuestionDAO;
import entity.exam.ChoiceQuestion;
import entity.exam.FillQuestion;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class SFillQuestion extends JPanel {
	    public int now=0;
	   JButton last,first,next,finaller,OK;
	   JTextArea textArea,textArea_1;
	  private List<FillQuestion>  save=FillQuestionDAO.selectFillQuestion(3);
	  public static String fresult[][]={{"",""},{"",""},{"",""}};
	
	/**
	 * Create the panel.
	 */
	public SFillQuestion() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		for(int i=0;i<3;i++){
			  fresult[i][0]=save.get(i).getF_answer();
		  }
		 first= new JButton("\u9996\u9898");
		first.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				now=0;
				first.setSelected(true);
		   	next.setEnabled(true);
			last.setEnabled(false);
			finaller.setEnabled(true);
		  FillQuestion c=save.get(now);
		  textArea.setText(c.getF_question());
				
			}
		});
		GridBagConstraints gbc_A = new GridBagConstraints();
		gbc_A.insets = new Insets(0, 0, 5, 5);
		gbc_A.gridx = 2;
		gbc_A.gridy = 0;
		add(first, gbc_A);
		
		 last = new JButton("\u4E0A\u4E00\u9898");
		last.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				last.setEnabled(true);
				if(now>0){
				now=now-1;
		 		FillQuestion c=save.get(now);
				textArea.setText(c.getF_question());
				}
			}
		});
		GridBagConstraints gbc_last = new GridBagConstraints();
		gbc_last.insets = new Insets(0, 0, 5, 5);
		gbc_last.gridx = 4;
		gbc_last.gridy = 0;
		add(last, gbc_last);
		
		 next = new JButton("\u4E0B\u4E00\u9898");
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(now<2){
				now=now+1;
		 		FillQuestion c=save.get(now);
				textArea.setText(c.getF_question());
				}
			}
		});
		GridBagConstraints gbc_next = new GridBagConstraints();
		gbc_next.insets = new Insets(0, 0, 5, 5);
		gbc_next.gridx = 6;
		gbc_next.gridy = 0;
		add(next, gbc_next);
		
	 finaller = new JButton("\u672B\u9898");
		finaller.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				now=2;
		 		FillQuestion c=save.get(now);
				textArea.setText(c.getF_question());
			}
		});
		GridBagConstraints gbc_finaller = new GridBagConstraints();
		gbc_finaller.insets = new Insets(0, 0, 5, 5);
		gbc_finaller.gridx = 8;
		gbc_finaller.gridy = 0;
		add(finaller, gbc_finaller);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPane.gridwidth = 12;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 1;
		add(scrollPane, gbc_scrollPane);
		
	 textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		JLabel lblNewLabel = new JLabel("\u586B\u5199\u7B54\u6848");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 2;
		add(lblNewLabel, gbc_lblNewLabel);
		
		OK = new JButton("\u786E\u5B9A");
		OK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String temp=textArea_1.getText().trim();
			fresult[now][1]=temp;
			textArea_1.setText("");
			}
		});
		GridBagConstraints gbc_OK = new GridBagConstraints();
		gbc_OK.insets = new Insets(0, 0, 5, 5);
		gbc_OK.gridx = 8;
		gbc_OK.gridy = 2;
		add(OK, gbc_OK);
		
		textArea_1 = new JTextArea();
		GridBagConstraints gbc_textArea_1 = new GridBagConstraints();
		gbc_textArea_1.gridwidth = 7;
		gbc_textArea_1.insets = new Insets(0, 0, 0, 5);
		gbc_textArea_1.fill = GridBagConstraints.BOTH;
		gbc_textArea_1.gridx = 0;
		gbc_textArea_1.gridy = 3;
		add(textArea_1, gbc_textArea_1);
  
	}

}
