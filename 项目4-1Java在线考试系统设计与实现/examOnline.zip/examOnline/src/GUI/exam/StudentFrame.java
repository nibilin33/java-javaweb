package GUI.exam;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;

import DAO.exam.StudentDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentFrame extends JFrame {

	private JPanel contentPane;
    public static JLabel lblNewLabel_1;
    public static Countdown count;
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentFrame frame = new StudentFrame();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public StudentFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 553, 387);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		SchoiceQuestion choice=new SchoiceQuestion();
		SFillQuestion fill=new SFillQuestion();
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.add(choice,"ѡ����Ŀ");
		tabbedPane.add(fill,"�����Ŀ");
		
		contentPane.add(tabbedPane, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("\u8003\u8BD5\u8FDB\u884C\u4E2D\uFF0C\u8DDD\u79BB\u8003\u8BD5\u7ED3\u675F\u7684\u65F6\u95F4\u4E3A\uFF1A");
		panel.add(lblNewLabel);
		
		 lblNewLabel_1 = new JLabel("");
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u4EA4\u5377");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int temp=JOptionPane.showConfirmDialog(null,"��ȷ��Ҫ������");
				if(temp==0){
					int score=0;
					for(int i=0;i<3;i++){
						if(SchoiceQuestion.cresult[i][1].equalsIgnoreCase(SchoiceQuestion.cresult[i][0])&&SchoiceQuestion.cresult[i][1].length()!=0)
							score+=2;
					}
					for(int i=0;i<3;i++){
						if(SFillQuestion.fresult[i][1].equalsIgnoreCase(SFillQuestion.fresult[i][0])&&SFillQuestion.fresult[i][1].length()!=0)
							score+=2;
					}
					int i=JOptionPane.showConfirmDialog(null, "��ĵ÷��ǣ�"+score+"\n�˳�������");
					if(i==0){
						LoginFrame.stu.setScore(score+"");
					 	StudentDAO.insertScore(LoginFrame.stu.getSid(), ""+score);
						System.exit(0);
					}
				}
			}
		});
		panel.add(btnNewButton);
	  count=new Countdown();
		count.start();
	}

}
