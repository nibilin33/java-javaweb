package GUI.exam;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;

import entity.exam.Administrator;
import entity.exam.Student;
import entity.exam.Teacher;
import DAO.exam.AdministratorDAO;
import DAO.exam.StudentDAO;
import DAO.exam.TeacherDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldID;
	private JTextField textFieldPWD;
	JComboBox<String> comboBox;
   public static Student stu;
   public static Teacher teacher;
   public static Administrator adm;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setTitle("\u7528\u6237\u767B\u5F55\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		JButton btnNewButton = new JButton("\u5173\u4E8E");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "���ߣ�С��\n"+"ָ����ʦ������ʦ\n"+"��ַ������\n");
			}
		});
		contentPane.add(btnNewButton, BorderLayout.SOUTH);
		contentPane.setBorder(BorderFactory.createTitledBorder("<html><b><i>"
				+ "<u><font face='SansSerif' size='8' color='red'>welcome"
				+ "</font></u></i></b></html>"));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u7C7B\u578B");
		lblNewLabel.setBounds(87, 26, 54, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u7528\u6237 ID");
		lblNewLabel_1.setBounds(87, 64, 54, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u7528\u6237\u53E3\u4EE4");
		lblNewLabel_2.setBounds(87, 100, 54, 15);
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("\u767B\u5F55");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			  if(textFieldID.getText()==""){
				  JOptionPane.showMessageDialog(null,"�������û�ID","�û�����",1);
				  textFieldPWD.setText("");
			  }
			  else
				  if(textFieldPWD.getText()==""){
					  JOptionPane.showMessageDialog(null, "�������û�����","�û�����",1);
				  }else
					  if(comboBox.getSelectedIndex()==0){
						  Student st=StudentDAO.selectStudent(textFieldID.getText().trim());
						  if(st==null){
							  JOptionPane.showMessageDialog(null,"��ѧ��������");
							  textFieldID.setText("");
							  textFieldPWD.setText("");
						  }else
							  if(!st.getPassword().equals(textFieldPWD.getText().trim())){
								  JOptionPane.showMessageDialog(null, "�������");
								  textFieldPWD.setText("");
							  }else
							  {
								  setVisible(false);
								  stu=st;
							new BeginTest().setVisible(true);;
							
							  }
					  }else
						  if(comboBox.getSelectedIndex()==1){
							 teacher=TeacherDAO.selectTeacher(textFieldID.getText().trim());
							  if(teacher==null){
								  JOptionPane.showMessageDialog(null,"�ý�ʦ������");
								  textFieldID.setText("");
								  textFieldPWD.setText("");
							  }else
								  if(!teacher.getPassword().equals(textFieldPWD.getText().trim())){
									  JOptionPane.showMessageDialog(null, "�������");
									  textFieldPWD.setText("");
								  }else
								  {
									 setVisible(false);
									  new TeacherFrame().setVisible(true);;
								  }
						  }else
							  if(comboBox.getSelectedIndex()==2){
								 adm=AdministratorDAO.selectAdministrator(textFieldID.getText().trim());
								  if(adm==null){
									  JOptionPane.showMessageDialog(null,"�ù���Ա������");
									  textFieldID.setText("");
									  textFieldPWD.setText("");
								  }else
									  if(!adm.getPassword().equals(textFieldPWD.getText().trim())){
										  JOptionPane.showMessageDialog(null, "�������");
										  textFieldPWD.setText("");
									  }else
									  {
										  setVisible(false);
										  new AdminFrame().setVisible(true);;
									  }
							  }
			}
		});
		btnNewButton_1.setBounds(85, 135, 66, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u6E05\u5C4F");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldID.setText("");
				textFieldPWD.setText("");
			}
		});
		btnNewButton_2.setBounds(179, 135, 73, 23);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("\u9000\u51FA");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton_3.setBounds(274, 135, 66, 23);
		panel.add(btnNewButton_3);
		
		comboBox = new JComboBox<String>();
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"\u5B66\u751F", "\u6559\u5E08", "\u7BA1\u7406\u5458"}));
		comboBox.setBounds(194, 23, 96, 21);
		panel.add(comboBox);
		
		textFieldID = new JTextField();
		textFieldID.setBounds(194, 61, 96, 21);
		panel.add(textFieldID);
		textFieldID.setColumns(10);
		
		textFieldPWD = new JTextField();
		textFieldPWD.setBounds(194, 97, 93, 21);
		panel.add(textFieldPWD);
		textFieldPWD.setColumns(10);
	}
}
