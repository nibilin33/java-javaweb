package entity.exam;

public class Student extends User{
	private String sid;
	private String dept;
	private String score;
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public Student(String sid, String name, String sex, String cardNumber,
			String password, String deparment, String phone) {
		super(name, sex, cardNumber, password, phone);
		this.sid = sid;
		this.dept = deparment;
	}
	public Student() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}
	public Student(String name, String sex, String cardNumber, String password,
			String phone) {
		super(name, sex, cardNumber, password, phone);
		// TODO �Զ����ɵĹ��캯�����
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	

}
