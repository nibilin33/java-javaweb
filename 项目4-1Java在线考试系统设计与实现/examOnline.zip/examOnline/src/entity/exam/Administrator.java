package entity.exam;

public class Administrator extends User{
	private String adid;

	public Administrator(String name, String sex, String cardNumber,
			String password, String phone, String adid) {
		super(name, sex, cardNumber, password, phone);
		this.adid = adid;
	}

	public Administrator() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}

	public Administrator(String name, String sex, String cardNumber,
			String password, String phone) {
		super(name, sex, cardNumber, password, phone);
		// TODO �Զ����ɵĹ��캯�����
	}

	public String getAdid() {
		return adid;
	}

	public void setAdid(String adid) {
		this.adid = adid;
	}
	

}
