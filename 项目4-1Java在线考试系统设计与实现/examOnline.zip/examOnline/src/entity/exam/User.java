package entity.exam;

public class User {
protected String name;
protected String sex;
protected String cardNumber;
protected String password;
protected String phone;
public User(String name, String sex, String cardNumber, String password,
		String phone) {
	super();
	this.name = name;
	this.sex = sex;
	this.cardNumber = cardNumber;
	this.password = password;
	this.phone = phone;
}
public User() {
	super();
	// TODO �Զ����ɵĹ��캯�����
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getCardNumber() {
	return cardNumber;
}
public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}

}
