package entity.exam;

public class Teacher extends User{
	private String tid;
	private String title;
	public Teacher(String name, String sex, String cardNumber, String password,
			String phone, String tid, String title) {
		super(name, sex, cardNumber, password, phone);
		this.tid = tid;
		this.title = title;
	}
	public Teacher() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}
	public Teacher(String name, String sex, String cardNumber, String password,
			String phone) {
		super(name, sex, cardNumber, password, phone);
		// TODO �Զ����ɵĹ��캯�����
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	

}
