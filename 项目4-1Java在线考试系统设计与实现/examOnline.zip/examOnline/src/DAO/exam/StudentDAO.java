package DAO.exam;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.exam.Student;

public class StudentDAO {
	public static Student selectStudent(String sid){
		Connection conn=JDBCConnectionFactory.getConnection();
		Student st=null;
		try{
			Statement stmt=conn.createStatement();
			String sql="select * from student where sid='"+sid+"'";
			ResultSet rs=stmt.executeQuery(sql);
			if(rs.next()){
				
				st=new Student(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			}
		}catch(SQLException ee){
			ee.printStackTrace();
			
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		return st;
		
	}
	public static int insertScore(String sid,String score)
	{
		Connection conn=JDBCConnectionFactory.getConnection();
		
		try{
			
			String str="update student set score='"+score+"'where sid='"+sid+"'";
			 PreparedStatement pstmt=conn.prepareStatement(str);
		if(pstmt.executeUpdate()==1){
		return 0;
      	}
   	else{
			return -1;
		}
		}catch(SQLException ee){
			return -1;
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		
	}
	public static List<Student> getStudent(){
		Connection conn=JDBCConnectionFactory.getConnection();
		 List list = new ArrayList();  
		 int i=0;
		Student[]st=new Student[100];
		try{
			Statement stmt=conn.createStatement();
			String sql="select * from student";
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				st[i]=new Student(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
				st[i].setScore(rs.getString(8));
				list.add(st[i]);
				i++;
				
			}
		}catch(SQLException ee){
			ee.printStackTrace();
			
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		return list;
		
	}
	public static int insertStudent(Student st) throws SQLException{
		if(selectStudent(st.getSid())!=null)
			return 1;
		Connection conn=JDBCConnectionFactory.getConnection();
		try{
			
			String str="insert into student values"+"('"+st.getSid()+"','"+st.getName()+
					"','"+st.getSex()+"','"+st.getCardNumber()+"','"+st.getPassword()+"','"+st.getDept()+"','"+st.getPhone()+"')";
			PreparedStatement pstmt=conn.prepareStatement(str);
		if(pstmt.executeUpdate()==1){
			return 0;
		}
		else{
			return -1;
		}
		}catch(SQLException ee){
			return -1;
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
	public  static int updateStudent(Student st){
		if(selectStudent(st.getSid())==null)
			        return 1;
		Connection conn=JDBCConnectionFactory.getConnection();
		try{
			
   String str="update student set sname='"+st.getName()+"',sex='"+st.getSex()+"',cardnumber='"+st.getCardNumber()
		   +"',pwd='"+st.getPassword()+"',department='"+st.getDept()+"',phone='"
		   +st.getPhone()+"'where sid='"+st.getSid()+"'";
   PreparedStatement pstmt=conn.prepareStatement(str);
   if(pstmt.executeUpdate()==1){
	   return 0;
   }else
   {
	   return -1;
   }
		}catch(SQLException ee){
			ee.printStackTrace();
			return -1;
					
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
	public static void updatemuch(List<Student> listExcel){
		 int t,t1;
		 Connection conn=JDBCConnectionFactory.getConnection();
		 for (Student stuEntity : listExcel) {
	            String id=stuEntity.getSid();
	           
	            String str="insert into student values"+"('"+stuEntity.getSid()+"','"+stuEntity.getName()+
						"','"+stuEntity.getSex()+"','"+stuEntity.getCardNumber()+"','"+stuEntity.getPassword()+"','"+stuEntity.getDept()+"','"+stuEntity.getPhone()+"')";
                          
	    		try {
	    			PreparedStatement pstmt=conn.prepareStatement(str);
	    		     t=pstmt.executeUpdate();
		    	
				} catch (SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
	    	
	            }
		
		
		
	}
	public static int deleteStudent(Student st){
		if(selectStudent(st.getSid())==null)
			return 1;
		Connection conn=JDBCConnectionFactory.getConnection();
		try{
   String str="delete from student where sid='"+st.getSid()+"'";
   PreparedStatement pstmt=conn.prepareStatement(str);
   if(pstmt.executeUpdate()==1){
	   return 0;
   }else
   {
	   return -1;
   }
		}catch(SQLException ee){
			ee.printStackTrace();
			return -1;
					
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}

}
