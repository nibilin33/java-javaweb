package DAO.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnectionFactory {
	public static Connection getConnection(){
	Connection conn=null;
	String url="jdbc:mysql://localhost:3306/exam?characterEncoding=utf8";
	String user="root";
	String pwd="";
	try{
		Class.forName("com.mysql.jdbc.Driver");
		conn=DriverManager.getConnection(url,user,pwd);
		
	}catch(ClassNotFoundException e){
		e.printStackTrace();
	}catch(SQLException e){
		e.printStackTrace();
	}
      return conn;
	}
}
