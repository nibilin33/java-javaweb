package DAO.exam;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import entity.exam.ChoiceQuestion;
import entity.exam.Student;

public class ChoiceQuestionDAO {

	private static int[]random_number(int max,int num){
		int [] number=new int[num];
		for(int i=0;i<num;i++){
			number[i]=(int)(Math.random()*max)+1;
			for(int j=1;j<=i;j++){
				if(number[j-1]==number[j]){
					i=i-1;
					break;
				}
			}
		}
		return number;
	}
	public static List<ChoiceQuestion> selectChoiceQuestion(int num){
		Connection conn=JDBCConnectionFactory.getConnection();
		ChoiceQuestion choice=null;
		List<ChoiceQuestion> list=new LinkedList<ChoiceQuestion>();
		try{
			Statement stmt=conn.createStatement();
			ResultSet rs1=stmt.executeQuery("select max(c_id) from choicequestion");
			int maxcid=30;
			if(rs1.next()){
				maxcid=rs1.getInt(1);
			}
			int []number=random_number(maxcid,num);
			String sql="select * from choicequestion";
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				for(int i=0;i<num;i++){
					if(rs.getInt(1)==number[i]){
					choice=new ChoiceQuestion(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
					list.add(choice);
				}
					
				}
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		return list;
	}
	public static ChoiceQuestion selectOneChoiceQuestion(int cid){
		Connection conn=JDBCConnectionFactory.getConnection();
		ChoiceQuestion choice=null;
		
		try{
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from choicequestion where c_id='"+cid+"'");
	
			if(rs.next()){
		choice=new ChoiceQuestion(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
				
			}
		
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		return choice;
	}
	public static int insertChoiceQuestion(ChoiceQuestion choice){
		Connection conn=JDBCConnectionFactory.getConnection();
		if(selectOneChoiceQuestion(choice.getC_id())!=null)
			return -1;
		try{
			String str="insert into choicequestion values('"+choice.getC_id()+"','"+choice.getC_question()+"','"+choice.getC_choiceA()+"','"+choice.getC_choiceB()+"','"+choice.getC_choiceC()+"','"+choice.getC_choiceD()+"','"+choice.getC_answer()+"')";
			PreparedStatement pstmt=conn.prepareStatement(str);
			if(pstmt.executeUpdate()==1){
				return 0;
			}else
				return -1;
		}catch(SQLException ee){
			ee.printStackTrace();
			return -1;
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
	}
	public  static int updateChoiceQuestion(ChoiceQuestion st){
		if(selectOneChoiceQuestion(st.getC_id())==null)
			        return 1;
		Connection conn=JDBCConnectionFactory.getConnection();
		try{
			
   String str="update choicequestion set c_id='"+st.getC_id()+"',c_question='"+st.getC_question()+"',c_choiceA='"+st.getC_choiceA()
		   +"',c_choiceB='"+st.getC_choiceB()+"',c_choiceC='"+st.getC_choiceC()+"',c_choiceD='"
		   +st.getC_choiceD()+"',c_answer='"+st.getC_answer()+"'where c_id='"+st.getC_id()+"'";
   PreparedStatement pstmt=conn.prepareStatement(str);
   if(pstmt.executeUpdate()==1){
	   return 0;
   }else
   {
	   return -1;
   }
		}catch(SQLException ee){
			ee.printStackTrace();
			return -1;
					
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
	public static int deleteChoiceQuestion(int cid){
		if(selectOneChoiceQuestion(cid)==null)
		     	return 1;
		Connection conn=JDBCConnectionFactory.getConnection();
		try{
			Statement stmt=conn.createStatement();
			String rs="delete from"+"choicequestion"+"where c_id='"+cid+"'";
	        
			PreparedStatement pstmt=conn.prepareStatement(rs);
			if(pstmt.executeUpdate()==1){
				return 0;
			}else
				return -1;
		
		}catch(SQLException e){
			e.printStackTrace();
			return -1;
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		
	}
}
