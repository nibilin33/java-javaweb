package DAO.exam;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import entity.exam.ChoiceQuestion;
import entity.exam.FillQuestion;

public class FillQuestionDAO {
	private static int[]random_number(int max,int num){
		int [] number=new int[num];
		for(int i=0;i<num;i++){
			number[i]=(int)(Math.random()*max)+1;
			for(int j=1;j<=i;j++){
				if(number[j-1]==number[j]){
					i=i-1;
					break;
				}
			}
		}
		return number;
	}
	public static List<FillQuestion> selectFillQuestion(int num){
		Connection conn=JDBCConnectionFactory.getConnection();
		FillQuestion choice=null;
		List<FillQuestion> list=new LinkedList<FillQuestion>();
		try{
			Statement stmt=conn.createStatement();
			ResultSet rs1=stmt.executeQuery("select max(f_id)from fillquestion");
			int maxcid=30;
			if(rs1.next()){
				maxcid=rs1.getInt(1);
			}
			int []number=random_number(maxcid,num);
			String sql="select * from fillquestion";
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				for(int i=0;i<num;i++){
					if(rs.getInt(1)==number[i]){
					choice=new FillQuestion(rs.getInt(1),rs.getString(2),rs.getString(3));
					list.add(choice);
				}
					
				}
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		return list;
	}
	public static FillQuestion selectOneFillQuestion(int fid){
		Connection conn=JDBCConnectionFactory.getConnection();
		FillQuestion choice=null;
		
		try{
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from fillquestion where f_id='"+fid+"'");
	
			if(rs.next()){
		choice=new FillQuestion(rs.getInt(1),rs.getString(2),rs.getString(3));
				
			}
		
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		return choice;
	}
	public  static int updateFillQuestion(FillQuestion st){
		if(selectOneFillQuestion(st.getF_id())==null)
			        return 1;
		Connection conn=JDBCConnectionFactory.getConnection();
		try{
			
   String str="update fillquestion set f_id='"+st.getF_id()+"',f_question='"+st.getF_question()+"',f_answer='"+st.getF_answer()+"'where f_id='"+st.getF_id()+"'";
   PreparedStatement pstmt=conn.prepareStatement(str);
   if(pstmt.executeUpdate()==1){
	   return 0;
   }else
   {
	   return -1;
   }
		}catch(SQLException ee){
			ee.printStackTrace();
			return -1;
					
		}finally{
			if(conn!=null){
				try{
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
	}
	public static int insertFillQuestion(FillQuestion choice){
		Connection conn=JDBCConnectionFactory.getConnection();
		if(selectOneFillQuestion(choice.getF_id())!=null)
			return -1;
		try{
			String str="insert into fillquestion values('"+choice.getF_id()+"','"+choice.getF_question()+"','"+choice.getF_answer()+"')";
			PreparedStatement pstmt=conn.prepareStatement(str);
			if(pstmt.executeUpdate()==1){
				return 0;
			}else
				return -1;
		}catch(SQLException ee){
			return -1;
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
	}
	public static int deleteFillQuestion(int cid){
		if(selectOneFillQuestion(cid)==null)
		     	return 1;
		Connection conn=JDBCConnectionFactory.getConnection();
		try{
			Statement stmt=conn.createStatement();
			String rs="delete from fillquestion where f_id='"+cid+"'";
	
			PreparedStatement pstmt=conn.prepareStatement(rs);
			if(pstmt.executeUpdate()==1){
				return 0;
			}else
				return -1;
		
		}catch(SQLException e){
			e.printStackTrace();
			return -1;
		}finally{
			if(conn!=null){
				try{
				conn.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		}
		
	}

}
